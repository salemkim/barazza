/**
 * Seed script: populates Kenya's electoral geography.
 * Data source: IEBC (Independent Electoral and Boundaries Commission)
 * Run: npm run db:seed
 *
 * This is a representative sample. For full production data, download
 * the complete IEBC ward boundaries dataset from:
 * https://www.iebc.or.ke/election-results/electoral-boundaries
 */

import { db }       from '../src/lib/db'
import { counties, constituencies, wards } from '../src/lib/db/schema'
import 'dotenv/config'

// ── Sample Kenya county data (all 47 counties) ───────────────────────────────
const COUNTIES = [
  { code: 1,  name: 'Mombasa'        }, { code: 2,  name: 'Kwale'           },
  { code: 3,  name: 'Kilifi'         }, { code: 4,  name: 'Tana River'      },
  { code: 5,  name: 'Lamu'           }, { code: 6,  name: 'Taita Taveta'    },
  { code: 7,  name: 'Garissa'        }, { code: 8,  name: 'Wajir'           },
  { code: 9,  name: 'Mandera'        }, { code: 10, name: 'Marsabit'        },
  { code: 11, name: 'Isiolo'         }, { code: 12, name: 'Meru'            },
  { code: 13, name: 'Tharaka Nithi'  }, { code: 14, name: 'Embu'            },
  { code: 15, name: 'Kitui'          }, { code: 16, name: 'Machakos'        },
  { code: 17, name: 'Makueni'        }, { code: 18, name: 'Nyandarua'       },
  { code: 19, name: 'Nyeri'          }, { code: 20, name: "Kirinyaga"       },
  { code: 21, name: "Murang'a"       }, { code: 22, name: 'Kiambu'          },
  { code: 23, name: 'Turkana'        }, { code: 24, name: 'West Pokot'      },
  { code: 25, name: 'Samburu'        }, { code: 26, name: 'Trans Nzoia'     },
  { code: 27, name: 'Uasin Gishu'   }, { code: 28, name: 'Elgeyo Marakwet' },
  { code: 29, name: 'Nandi'          }, { code: 30, name: 'Baringo'         },
  { code: 31, name: 'Laikipia'       }, { code: 32, name: 'Nakuru'          },
  { code: 33, name: 'Narok'          }, { code: 34, name: 'Kajiado'         },
  { code: 35, name: 'Kericho'        }, { code: 36, name: 'Bomet'           },
  { code: 37, name: 'Kakamega'       }, { code: 38, name: 'Vihiga'          },
  { code: 39, name: 'Bungoma'        }, { code: 40, name: 'Busia'           },
  { code: 41, name: 'Siaya'          }, { code: 42, name: 'Kisumu'          },
  { code: 43, name: 'Homa Bay'       }, { code: 44, name: 'Migori'          },
  { code: 45, name: 'Kisii'          }, { code: 46, name: 'Nyamira'         },
  { code: 47, name: 'Nairobi City'   },
]

// ── Sample constituencies for Nairobi (county 47) ────────────────────────────
// In production, load all 290 constituencies from IEBC data
const NAIROBI_CONSTITUENCIES = [
  { code: 290, name: 'Westlands'         },
  { code: 289, name: 'Dagoretti North'   },
  { code: 288, name: 'Dagoretti South'   },
  { code: 287, name: 'Langata'           },
  { code: 286, name: 'Kibra'             },
  { code: 285, name: 'Roysambu'          },
  { code: 284, name: 'Kasarani'          },
  { code: 283, name: 'Ruaraka'           },
  { code: 282, name: 'Embakasi South'    },
  { code: 281, name: 'Embakasi North'    },
  { code: 280, name: 'Embakasi Central'  },
  { code: 279, name: 'Embakasi East'     },
  { code: 278, name: 'Embakasi West'     },
  { code: 277, name: 'Makadara'          },
  { code: 276, name: 'Kamukunji'         },
  { code: 275, name: 'Starehe'           },
  { code: 274, name: 'Mathare'           },
]

// ── Sample wards for Westlands constituency ───────────────────────────────────
const WESTLANDS_WARDS = [
  { code: 3001, name: 'Kitisuru'         },
  { code: 3002, name: 'Parklands/Highridge' },
  { code: 3003, name: 'Karura'           },
  { code: 3004, name: 'Kangemi'          },
  { code: 3005, name: 'Mountain View'    },
]

const KIBRA_WARDS = [
  { code: 3010, name: 'Laini Saba'       },
  { code: 3011, name: 'Lindi'            },
  { code: 3012, name: 'Makina'           },
  { code: 3013, name: 'Woodley/Kenyatta Golf Course' },
  { code: 3014, name: 'Sarang\'ombe'     },
]

// ── Mombasa constituencies ────────────────────────────────────────────────────
const MOMBASA_CONSTITUENCIES = [
  { code: 1, name: 'Changamwe'           },
  { code: 2, name: 'Jomvu'               },
  { code: 3, name: 'Kisauni'             },
  { code: 4, name: 'Nyali'               },
  { code: 5, name: 'Likoni'              },
  { code: 6, name: 'Mvita'               },
]

const MVITA_WARDS = [
  { code: 1001, name: 'Mji Wa Kale/Makadara' },
  { code: 1002, name: 'Tudor'                },
  { code: 1003, name: 'Tononoka'             },
  { code: 1004, name: 'Shimanzi/Ganjoni'     },
  { code: 1005, name: 'Majengo'              },
]

async function seed() {
  console.log('🌍 Seeding Kenya electoral geography…')

  // ── Insert counties ────────────────────────────────────────────────────────
  console.log('  Inserting 47 counties…')
  await db.insert(counties).values(COUNTIES).onConflictDoNothing()
  const allCounties = await db.select().from(counties)
  const countyMap   = new Map(allCounties.map(c => [c.code, c.id]))

  // ── Insert Nairobi constituencies ──────────────────────────────────────────
  console.log('  Inserting Nairobi constituencies…')
  const nairobiId = countyMap.get(47)!
  await db.insert(constituencies).values(
    NAIROBI_CONSTITUENCIES.map(c => ({ ...c, countyId: nairobiId }))
  ).onConflictDoNothing()

  // ── Insert Mombasa constituencies ──────────────────────────────────────────
  console.log('  Inserting Mombasa constituencies…')
  const mombasaId = countyMap.get(1)!
  await db.insert(constituencies).values(
    MOMBASA_CONSTITUENCIES.map(c => ({ ...c, countyId: mombasaId }))
  ).onConflictDoNothing()

  // ── Insert sample wards ────────────────────────────────────────────────────
  const allConstituencies = await db.select().from(constituencies)
  const constMap = new Map(allConstituencies.map(c => [c.code, c.id]))

  const westlandsId = constMap.get(290)
  if (westlandsId) {
    console.log('  Inserting Westlands wards…')
    await db.insert(wards).values(
      WESTLANDS_WARDS.map(w => ({ ...w, constituencyId: westlandsId }))
    ).onConflictDoNothing()
  }

  const kibraId = constMap.get(286)
  if (kibraId) {
    console.log('  Inserting Kibra wards…')
    await db.insert(wards).values(
      KIBRA_WARDS.map(w => ({ ...w, constituencyId: kibraId }))
    ).onConflictDoNothing()
  }

  const mvitaId = constMap.get(6)
  if (mvitaId) {
    console.log('  Inserting Mvita wards…')
    await db.insert(wards).values(
      MVITA_WARDS.map(w => ({ ...w, constituencyId: mvitaId }))
    ).onConflictDoNothing()
  }

  console.log('✅ Seed complete!')
  console.log('   47 counties, 23 sample constituencies, 15 sample wards inserted.')
  console.log('\n⚠️  For full production data, download the complete IEBC dataset and')
  console.log('   extend this script with all 290 constituencies and 1,450 wards.')
  process.exit(0)
}

seed().catch(e => { console.error('Seed failed:', e); process.exit(1) })
