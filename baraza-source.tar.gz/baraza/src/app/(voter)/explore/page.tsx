'use client'

import { useState, useEffect } from 'react'
import { Search }      from 'lucide-react'
import LocationSelector from '@/components/auth/LocationSelector'
import PostCard        from '@/components/feed/PostCard'
import FeedSkeleton    from '@/components/feed/FeedSkeleton'
import type { FeedPost } from '@/types'
import { SEAT_TYPE_LABELS } from '@/lib/utils'

const SEAT_TYPES = ['president','governor','senator','women_rep','mp','mca'] as const

export default function ExplorePage() {
  const [location,  setLocation]  = useState<{ countyId: number | null; constituencyId: number | null; wardId: number | null }>({ countyId: null, constituencyId: null, wardId: null })
  const [seatType,  setSeatType]  = useState<string>('')
  const [posts,     setPosts]     = useState<FeedPost[]>([])
  const [loading,   setLoading]   = useState(false)
  const [searched,  setSearched]  = useState(false)

  const search = async () => {
    setLoading(true)
    setSearched(true)
    const params = new URLSearchParams()
    if (location.countyId)       params.set('countyId',       String(location.countyId))
    if (location.constituencyId) params.set('constituencyId', String(location.constituencyId))
    if (location.wardId)         params.set('wardId',          String(location.wardId))
    if (seatType)                params.set('seatType',        seatType)
    params.set('limit', '20')

    const res  = await fetch(`/api/feed?${params}`)
    const json = await res.json()
    setPosts(json.data?.posts ?? [])
    setLoading(false)
  }

  return (
    <div className="min-h-screen">
      <div className="sticky top-0 z-10 bg-white border-b border-gray-100 px-4 py-3">
        <h1 className="text-lg font-bold">Explore</h1>
        <p className="text-xs text-gray-500">Browse candidates across Kenya</p>
      </div>

      <div className="p-4 space-y-4">
        {/* Filters */}
        <div className="baraza-card p-4 space-y-4">
          <LocationSelector onChange={setLocation} required={false} />

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Position</label>
            <select className="baraza-input" value={seatType} onChange={e => setSeatType(e.target.value)}>
              <option value="">All positions</option>
              {SEAT_TYPES.map(t => <option key={t} value={t}>{SEAT_TYPE_LABELS[t]}</option>)}
            </select>
          </div>

          <button onClick={search} disabled={loading}
            className="baraza-btn-primary w-full flex items-center justify-center gap-2"
          >
            <Search size={16} />
            {loading ? 'Searching…' : 'Search'}
          </button>
        </div>

        {/* Results */}
        {loading && <FeedSkeleton count={3} />}

        {!loading && searched && posts.length === 0 && (
          <div className="text-center py-12 text-gray-400">
            <p className="font-semibold">No posts found</p>
            <p className="text-sm mt-1">Try adjusting your filters</p>
          </div>
        )}

        {!loading && posts.map(post => <PostCard key={post.id} post={post} />)}
      </div>
    </div>
  )
}
