'use client'

import { useEffect, useState, useCallback } from 'react'
import { toast }       from 'sonner'
import PostCard        from '@/components/feed/PostCard'
import FeedSkeleton    from '@/components/feed/FeedSkeleton'
import type { FeedPost } from '@/types'
import { useAuthStore } from '@/store/auth-store'
import { MapPin }      from 'lucide-react'
import Link            from 'next/link'

export default function FeedPage() {
  const { user }      = useAuthStore()
  const [posts,       setPosts]    = useState<FeedPost[]>([])
  const [loading,     setLoading]  = useState(true)
  const [page,        setPage]     = useState(1)
  const [hasMore,     setHasMore]  = useState(true)
  const [loadingMore, setLoadingMore] = useState(false)

  const fetchFeed = useCallback(async (p: number, append = false) => {
    if (!append) setLoading(true)
    else setLoadingMore(true)

    const res  = await fetch(`/api/feed?page=${p}&limit=10`)
    const json = await res.json()

    if (json.success) {
      const newPosts = json.data?.posts ?? []
      setPosts(prev => append ? [...prev, ...newPosts] : newPosts)
      setHasMore(json.data?.hasMore ?? false)
    } else {
      toast.error('Failed to load feed')
    }

    setLoading(false)
    setLoadingMore(false)
  }, [])

  useEffect(() => { fetchFeed(1) }, [fetchFeed])

  const loadMore = () => {
    const next = page + 1
    setPage(next)
    fetchFeed(next, true)
  }

  const noLocation = user && !user.countyId

  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-white border-b border-gray-100 px-4 py-3">
        <div className="flex items-center justify-between">
          <h1 className="text-xl font-bold text-baraza-green">Baraza</h1>
          {user && (
            <Link href="/voter/profile" className="text-xs text-gray-500 hover:text-baraza-green flex items-center gap-1">
              <MapPin size={12} />
              {user.countyId ? 'My feed' : 'Set location'}
            </Link>
          )}
        </div>
      </div>

      <div className="p-4">
        {/* Location prompt */}
        {noLocation && (
          <div className="baraza-card p-4 mb-4 border-l-4 border-baraza-green">
            <p className="text-sm font-medium text-gray-800">Set your location to personalise your feed</p>
            <p className="text-xs text-gray-500 mt-1">See candidates running in your ward, constituency and county.</p>
            <Link href="/voter/profile" className="inline-block mt-2 text-xs font-semibold text-baraza-green hover:underline">
              Update location →
            </Link>
          </div>
        )}

        {loading ? (
          <FeedSkeleton count={4} />
        ) : posts.length === 0 ? (
          <div className="text-center py-16 text-gray-400">
            <p className="text-lg font-semibold mb-1">No posts yet</p>
            <p className="text-sm">Candidates in your area haven't posted yet. Check back soon.</p>
          </div>
        ) : (
          <>
            {posts.map(post => (
              <PostCard key={post.id} post={post} onUpdate={updated =>
                setPosts(prev => prev.map(p => p.id === updated.id ? updated : p))
              } />
            ))}
            {hasMore && (
              <button onClick={loadMore} disabled={loadingMore}
                className="w-full py-3 text-sm text-baraza-green font-semibold hover:bg-baraza-green-muted rounded-xl transition-colors"
              >
                {loadingMore ? 'Loading…' : 'Load more'}
              </button>
            )}
          </>
        )}
      </div>
    </div>
  )
}
