'use client'

import { useState }    from 'react'
import { toast }       from 'sonner'
import { LogOut, MapPin } from 'lucide-react'
import { useAuth }     from '@/hooks/useAuth'
import LocationSelector from '@/components/auth/LocationSelector'

export default function VoterProfilePage() {
  const { user, logout } = useAuth()
  const [editing, setEditing] = useState(false)
  const [location, setLocation] = useState<{ countyId: number | null; constituencyId: number | null; wardId: number | null }>({
    countyId: user?.countyId ?? null, constituencyId: user?.constituencyId ?? null, wardId: user?.wardId ?? null,
  })
  const [saving, setSaving] = useState(false)

  const saveLocation = async () => {
    if (!location.countyId) { toast.error('Please select a county'); return }
    setSaving(true)
    const res  = await fetch('/api/user/location', {
      method: 'PATCH', headers: { 'Content-Type': 'application/json' },
      body:   JSON.stringify(location),
    })
    const json = await res.json()
    setSaving(false)
    if (json.success) { toast.success('Location updated!'); setEditing(false) }
    else toast.error(json.error)
  }

  if (!user) return null

  return (
    <div className="min-h-screen">
      <div className="sticky top-0 z-10 bg-white border-b px-4 py-3">
        <h1 className="text-lg font-bold">Profile</h1>
      </div>

      <div className="p-4 space-y-4">
        {/* Avatar + name */}
        <div className="baraza-card p-5 flex items-center gap-4">
          <div className="w-16 h-16 rounded-full bg-baraza-green flex items-center justify-center text-white text-2xl font-bold flex-shrink-0">
            {user.username[0].toUpperCase()}
          </div>
          <div>
            <p className="font-bold text-lg">{user.username}</p>
            <p className="text-sm text-gray-500">Voter</p>
            <p className="text-xs text-gray-400 mt-0.5">{user.phone}</p>
          </div>
        </div>

        {/* Location */}
        <div className="baraza-card p-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <MapPin size={16} className="text-baraza-green" />
              <h3 className="font-semibold text-sm">My Location</h3>
            </div>
            <button onClick={() => setEditing(v => !v)}
              className="text-xs text-baraza-green font-semibold hover:underline"
            >{editing ? 'Cancel' : 'Edit'}</button>
          </div>

          {editing ? (
            <div className="space-y-3">
              <LocationSelector onChange={setLocation} required />
              <button onClick={saveLocation} disabled={saving} className="baraza-btn-primary w-full text-sm">
                {saving ? 'Saving…' : 'Save Location'}
              </button>
            </div>
          ) : (
            <div className="text-sm text-gray-600">
              {user.countyId
                ? <p>County {user.countyId}{user.constituencyId ? ` · Constituency ${user.constituencyId}` : ''}{user.wardId ? ` · Ward ${user.wardId}` : ''}</p>
                : <p className="text-gray-400">No location set — <button onClick={() => setEditing(true)} className="text-baraza-green">set now</button></p>
              }
            </div>
          )}
        </div>

        {/* Logout */}
        <button onClick={logout}
          className="w-full flex items-center justify-center gap-2 p-3 text-sm font-medium text-baraza-red border border-baraza-red/30 rounded-xl hover:bg-baraza-red-light transition-colors"
        >
          <LogOut size={16} /> Sign Out
        </button>
      </div>
    </div>
  )
}
