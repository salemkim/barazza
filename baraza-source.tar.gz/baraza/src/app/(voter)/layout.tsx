import BottomNav from '@/components/layout/BottomNav'

export default function VoterLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-lg mx-auto bottom-nav-pad">
        {children}
      </div>
      <BottomNav />
    </div>
  )
}
