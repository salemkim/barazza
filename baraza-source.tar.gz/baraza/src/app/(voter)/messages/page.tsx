'use client'

import { useEffect, useState }  from 'react'
import { useSearchParams }      from 'next/navigation'
import Image                    from 'next/image'
import { toast }                from 'sonner'
import { ArrowLeft, Send }      from 'lucide-react'
import { timeAgo }              from '@/lib/utils'
import { useAuthStore }         from '@/store/auth-store'

interface Convo {
  partner_id:       string
  username:         string
  full_name:        string | null
  profile_image_url: string | null
  last_message:     string
  last_message_at:  string
  unread_count:     number
}

interface Message {
  id:         string
  senderId:   string
  receiverId: string
  text:       string
  isRead:     boolean
  createdAt:  string
}

export default function MessagesPage() {
  const { user }     = useAuthStore()
  const searchParams = useSearchParams()
  const withUserId   = searchParams.get('with')

  const [convos,   setConvos]   = useState<Convo[]>([])
  const [thread,   setThread]   = useState<Message[]>([])
  const [text,     setText]     = useState('')
  const [loading,  setLoading]  = useState(true)
  const [sending,  setSending]  = useState(false)
  const [partner,  setPartner]  = useState<Pick<Convo,'partner_id'|'username'|'full_name'|'profile_image_url'> | null>(null)

  // Load conversation list
  useEffect(() => {
    fetch('/api/messages').then(r => r.json()).then(j => {
      setConvos(j.data ?? [])
      setLoading(false)
    })
  }, [])

  // Load thread when withUserId changes
  useEffect(() => {
    if (!withUserId) { setThread([]); return }
    const found = convos.find(c => c.partner_id === withUserId)
    if (found) setPartner({ partner_id: found.partner_id, username: found.username, full_name: found.full_name, profile_image_url: found.profile_image_url })

    fetch(`/api/messages?withUserId=${withUserId}`).then(r => r.json()).then(j => {
      setThread(j.data ?? [])
    })
  }, [withUserId, convos])

  const send = async () => {
    if (!text.trim() || !withUserId) return
    setSending(true)
    const res  = await fetch('/api/messages', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body:   JSON.stringify({ receiverId: withUserId, text: text.trim() }),
    })
    const json = await res.json()
    if (json.success) { setThread(t => [...t, json.data]); setText('') }
    else toast.error(json.error)
    setSending(false)
  }

  // ── Thread view ────────────────────────────────────────────────────────────
  if (withUserId) {
    return (
      <div className="flex flex-col h-screen">
        {/* Header */}
        <div className="flex items-center gap-3 px-4 py-3 bg-white border-b sticky top-0 z-10">
          <button onClick={() => window.history.back()} className="text-gray-400 hover:text-gray-600">
            <ArrowLeft size={20} />
          </button>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-baraza-green-muted flex items-center justify-center text-baraza-green font-bold text-sm">
              {(partner?.full_name ?? partner?.username ?? '?')[0].toUpperCase()}
            </div>
            <div>
              <p className="font-semibold text-sm">{partner?.full_name ?? partner?.username ?? withUserId.slice(0, 8)}</p>
              <p className="text-xs text-gray-400">@{partner?.username}</p>
            </div>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {thread.map(msg => {
            const mine = msg.senderId === user?.id
            return (
              <div key={msg.id} className={`flex ${mine ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[75%] rounded-2xl px-4 py-2.5 text-sm ${
                  mine ? 'bg-baraza-green text-white rounded-br-sm' : 'bg-white border border-gray-100 text-gray-800 rounded-bl-sm'
                }`}>
                  <p>{msg.text}</p>
                  <p className={`text-[10px] mt-1 ${mine ? 'text-green-200' : 'text-gray-400'}`}>{timeAgo(msg.createdAt)}</p>
                </div>
              </div>
            )
          })}
          {thread.length === 0 && (
            <p className="text-center text-sm text-gray-400 py-8">No messages yet. Say hello!</p>
          )}
        </div>

        {/* Input */}
        <div className="flex gap-2 p-4 bg-white border-t">
          <input value={text} onChange={e => setText(e.target.value)}
            placeholder="Type a message…" className="baraza-input flex-1"
            onKeyDown={e => e.key === 'Enter' && !e.shiftKey && send()}
          />
          <button onClick={send} disabled={sending || !text.trim()} className="baraza-btn-primary px-3">
            <Send size={16} />
          </button>
        </div>
      </div>
    )
  }

  // ── Conversation list ──────────────────────────────────────────────────────
  return (
    <div className="min-h-screen">
      <div className="sticky top-0 z-10 bg-white border-b px-4 py-3">
        <h1 className="text-lg font-bold">Messages</h1>
      </div>

      {loading && (
        <div className="p-4 space-y-3">
          {[1,2,3].map(i => (
            <div key={i} className="flex gap-3 p-3 animate-pulse">
              <div className="w-10 h-10 rounded-full bg-gray-200" />
              <div className="flex-1 space-y-1.5">
                <div className="h-3.5 bg-gray-200 rounded w-1/3" />
                <div className="h-3 bg-gray-100 rounded w-2/3" />
              </div>
            </div>
          ))}
        </div>
      )}

      {!loading && convos.length === 0 && (
        <div className="text-center py-16 text-gray-400">
          <p className="font-semibold">No messages yet</p>
          <p className="text-sm mt-1">Find a candidate and send them a question</p>
        </div>
      )}

      <div className="divide-y divide-gray-50">
        {convos.map(c => (
          <a key={c.partner_id} href={`/voter/messages?with=${c.partner_id}`}
            className="flex items-center gap-3 px-4 py-3 hover:bg-gray-50 transition-colors"
          >
            <div className="relative w-10 h-10 rounded-full bg-baraza-green-muted flex-shrink-0 flex items-center justify-center text-baraza-green font-bold">
              {(c.full_name ?? c.username)[0].toUpperCase()}
              {c.unread_count > 0 && (
                <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-baraza-red text-white text-[9px] font-bold rounded-full flex items-center justify-center">
                  {c.unread_count}
                </span>
              )}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <p className={`text-sm ${c.unread_count > 0 ? 'font-bold' : 'font-medium'}`}>{c.full_name ?? c.username}</p>
                <p className="text-[10px] text-gray-400">{timeAgo(c.last_message_at)}</p>
              </div>
              <p className="text-xs text-gray-500 truncate">{c.last_message}</p>
            </div>
          </a>
        ))}
      </div>
    </div>
  )
}
