import { NextRequest } from 'next/server'
import { db }          from '@/lib/db'
import { directMessages, users } from '@/lib/db/schema'
import { eq, and, or, desc, sql, ne } from 'drizzle-orm'
import { getSession }  from '@/lib/auth/session'
import { apiSuccess, apiError, apiCreated, containsProfanity, sanitiseText } from '@/lib/utils'
import { z } from 'zod'

const sendSchema = z.object({
  receiverId: z.string().uuid(),
  text:       z.string().min(1).max(2000),
})

// GET /api/messages?withUserId=   → thread
// GET /api/messages               → conversation list
export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session) return apiError('Unauthorised', 401)

  const withUserId = req.nextUrl.searchParams.get('withUserId')

  try {
    if (withUserId) {
      // Fetch thread between current user and target user
      const thread = await db
        .select()
        .from(directMessages)
        .where(and(
          eq(directMessages.isDeleted, false),
          or(
            and(eq(directMessages.senderId, session.id),   eq(directMessages.receiverId, withUserId)),
            and(eq(directMessages.senderId, withUserId),   eq(directMessages.receiverId, session.id)),
          ),
        ))
        .orderBy(desc(directMessages.createdAt))
        .limit(50)

      // Mark received messages as read
      await db.update(directMessages)
        .set({ isRead: true })
        .where(and(
          eq(directMessages.senderId,   withUserId),
          eq(directMessages.receiverId, session.id),
          eq(directMessages.isRead,     false),
        ))

      return apiSuccess(thread.reverse())
    }

    // Conversation list — latest message per partner
    const convos = await db.execute(sql`
      SELECT DISTINCT ON (partner_id)
        partner_id,
        dm.text      AS last_message,
        dm.created_at AS last_message_at,
        dm.is_read,
        dm.sender_id,
        u.username,
        u.full_name,
        u.profile_image_url,
        (
          SELECT COUNT(*) FROM direct_messages unread
          WHERE unread.sender_id = partner_id
            AND unread.receiver_id = ${session.id}
            AND unread.is_read = false
            AND unread.is_deleted = false
        ) AS unread_count
      FROM (
        SELECT
          CASE WHEN sender_id = ${session.id} THEN receiver_id ELSE sender_id END AS partner_id,
          id, text, created_at, is_read, sender_id
        FROM direct_messages
        WHERE (sender_id = ${session.id} OR receiver_id = ${session.id})
          AND is_deleted = false
      ) dm
      JOIN users u ON u.id = dm.partner_id
      ORDER BY partner_id, dm.created_at DESC
    `)

    return apiSuccess(convos.rows)
  } catch (e) {
    console.error('[messages GET]', e)
    return apiError('Failed to fetch messages', 500)
  }
}

// POST /api/messages — send a message
export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return apiError('Unauthorised', 401)

  try {
    const body   = await req.json()
    const parsed = sendSchema.safeParse(body)
    if (!parsed.success) return apiError(parsed.error.errors[0]?.message ?? 'Invalid input')

    const { receiverId, text } = parsed.data

    if (receiverId === session.id) return apiError('Cannot message yourself')
    if (containsProfanity(text))   return apiError('Message contains inappropriate language')

    // Verify receiver exists
    const [receiver] = await db
      .select({ id: users.id, role: users.role, subscriptionTier: users.subscriptionTier })
      .from(users)
      .where(eq(users.id, receiverId))
      .limit(1)

    if (!receiver) return apiError('Recipient not found', 404)

    // Only allow DMs to verified candidates (Gold+ tier) or if candidate is messaging a voter
    if (receiver.role === 'candidate') {
      const allowedTiers = ['gold', 'platinum']
      if (!allowedTiers.includes(receiver.subscriptionTier)) {
        return apiError('This candidate does not have messaging enabled. They need a Gold or Platinum subscription.', 403)
      }
    }

    const [msg] = await db.insert(directMessages).values({
      senderId:   session.id,
      receiverId,
      text:       sanitiseText(text),
    }).returning()

    return apiCreated(msg)
  } catch (e) {
    console.error('[messages POST]', e)
    return apiError('Failed to send message', 500)
  }
}
