import { NextRequest } from 'next/server'
import { db }          from '@/lib/db'
import { users }       from '@/lib/db/schema'
import { eq }          from 'drizzle-orm'
import { getSession }  from '@/lib/auth/session'
import { apiSuccess, apiError } from '@/lib/utils'

export async function PATCH(req: NextRequest) {
  const session = await getSession()
  if (!session) return apiError('Unauthorised', 401)

  const { countyId, constituencyId, wardId } = await req.json()
  if (!countyId) return apiError('County required')

  await db.update(users).set({
    countyId, constituencyId: constituencyId ?? null, wardId: wardId ?? null, updatedAt: new Date(),
  }).where(eq(users.id, session.id))

  return apiSuccess(null, 'Location updated')
}
