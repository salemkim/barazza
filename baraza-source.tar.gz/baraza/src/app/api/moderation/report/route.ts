import { NextRequest } from 'next/server'
import { db }          from '@/lib/db'
import { reports }     from '@/lib/db/schema'
import { getSession }  from '@/lib/auth/session'
import { apiSuccess, apiError, apiCreated } from '@/lib/utils'
import { z } from 'zod'

const schema = z.object({
  contentType: z.enum(['post', 'comment', 'message']),
  contentId:   z.string().uuid(),
  reason:      z.string().min(5).max(500),
})

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return apiError('Unauthorised', 401)

  try {
    const body   = await req.json()
    const parsed = schema.safeParse(body)
    if (!parsed.success) return apiError(parsed.error.errors[0]?.message ?? 'Invalid input')

    const { contentType, contentId, reason } = parsed.data

    const [report] = await db.insert(reports).values({
      reportedBy:  session.id,
      contentType: contentType as any,
      contentId,
      reason,
    }).returning()

    return apiCreated({ reportId: report.id })
  } catch (e) {
    console.error('[report]', e)
    return apiError('Failed to submit report', 500)
  }
}
