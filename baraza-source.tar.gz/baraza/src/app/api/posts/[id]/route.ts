import { NextRequest } from 'next/server'
import { db }          from '@/lib/db'
import { posts, postLikes } from '@/lib/db/schema'
import { eq, and, sql } from 'drizzle-orm'
import { getSession }  from '@/lib/auth/session'
import { apiSuccess, apiError } from '@/lib/utils'

// POST /api/posts/[id]/like  — toggle like
export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getSession()
  if (!session) return apiError('Unauthorised', 401)

  const { id: postId } = params

  try {
    const [existing] = await db
      .select()
      .from(postLikes)
      .where(and(eq(postLikes.postId, postId), eq(postLikes.userId, session.id)))
      .limit(1)

    if (existing) {
      // Unlike
      await db.delete(postLikes).where(and(eq(postLikes.postId, postId), eq(postLikes.userId, session.id)))
      await db.update(posts)
        .set({ likesCount: sql`GREATEST(${posts.likesCount} - 1, 0)` })
        .where(eq(posts.id, postId))
      return apiSuccess({ liked: false })
    } else {
      // Like
      await db.insert(postLikes).values({ postId, userId: session.id })
      await db.update(posts)
        .set({ likesCount: sql`${posts.likesCount} + 1` })
        .where(eq(posts.id, postId))
      return apiSuccess({ liked: true })
    }
  } catch (e) {
    console.error('[like-post]', e)
    return apiError('Failed to toggle like', 500)
  }
}

// DELETE /api/posts/[id]  — soft delete (author or admin only)
export async function DELETE(req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getSession()
  if (!session) return apiError('Unauthorised', 401)

  const { id: postId } = params

  try {
    const [post] = await db.select().from(posts).where(eq(posts.id, postId)).limit(1)
    if (!post) return apiError('Post not found', 404)

    if (post.authorId !== session.id && session.role !== 'admin') {
      return apiError('Forbidden', 403)
    }

    await db.update(posts)
      .set({ isDeleted: true, deletedAt: new Date() })
      .where(eq(posts.id, postId))

    return apiSuccess(null, 'Post deleted')
  } catch (e) {
    return apiError('Failed to delete post', 500)
  }
}
