import { NextRequest }  from 'next/server'
import { db }           from '@/lib/db'
import { posts, users, candidateSeats, subscriptions } from '@/lib/db/schema'
import { eq, and, gte, sql } from 'drizzle-orm'
import { getSession }   from '@/lib/auth/session'
import { uploadFormFile } from '@/lib/storage/supabase-storage'
import { apiSuccess, apiError, apiCreated, containsProfanity, sanitiseText } from '@/lib/utils'
import { FREE_POST_LIMIT_PER_WEEK } from '@/types'
import { subWeeks } from 'date-fns'
import { z } from 'zod'

const postSchema = z.object({
  contentText: z.string().min(1).max(2000),
  hasPoll:     z.boolean().optional(),
  pollQuestion: z.string().max(300).optional(),
  pollOptions: z.array(z.string().max(100)).min(2).max(6).optional(),
  pollDuration: z.number().int().min(1).max(7).optional(), // days
})

// GET /api/posts?authorId=
export async function GET(req: NextRequest) {
  const authorId = req.nextUrl.searchParams.get('authorId')
  const page     = Math.max(1, Number(req.nextUrl.searchParams.get('page') ?? 1))
  const limit    = 10
  const offset   = (page - 1) * limit

  try {
    const query = db
      .select({ post: posts })
      .from(posts)
      .where(and(
        eq(posts.isDeleted, false),
        ...(authorId ? [eq(posts.authorId, authorId)] : []),
      ))
      .orderBy(sql`${posts.isBoosted} DESC, ${posts.createdAt} DESC`)
      .limit(limit).offset(offset)

    const rows = await query
    return apiSuccess({ posts: rows.map(r => r.post), hasMore: rows.length === limit, page })
  } catch (e) {
    return apiError('Failed to fetch posts', 500)
  }
}

// POST /api/posts — create a new post
export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return apiError('Unauthorised', 401)
  if (session.role !== 'candidate') return apiError('Only candidates can post', 403)
  if (!session.isVerifiedCandidate) return apiError('Your account must be verified to post', 403)

  try {
    const formData = await req.formData()

    const parsed = postSchema.safeParse({
      contentText:  formData.get('contentText'),
      hasPoll:      formData.get('hasPoll') === 'true',
      pollQuestion: formData.get('pollQuestion') ?? undefined,
      pollOptions:  formData.get('pollOptions') ? JSON.parse(formData.get('pollOptions') as string) : undefined,
      pollDuration: formData.get('pollDuration') ? Number(formData.get('pollDuration')) : undefined,
    })

    if (!parsed.success) return apiError(parsed.error.errors[0]?.message ?? 'Invalid input')
    const data = parsed.data

    // Profanity check
    if (containsProfanity(data.contentText)) {
      return apiError('Content contains inappropriate language')
    }

    // Free tier: max 3 posts/week
    if (session.subscriptionTier === 'free') {
      const weekAgo  = subWeeks(new Date(), 1)
      const [countRow] = await db
        .select({ count: sql<number>`count(*)` })
        .from(posts)
        .where(and(eq(posts.authorId, session.id), gte(posts.createdAt, weekAgo), eq(posts.isDeleted, false)))

      if ((countRow?.count ?? 0) >= FREE_POST_LIMIT_PER_WEEK) {
        return apiError(`Free tier allows ${FREE_POST_LIMIT_PER_WEEK} posts per week. Upgrade to post more.`, 403)
      }
    }

    // Get candidate's seat
    const [cSeat] = await db
      .select({ seatId: candidateSeats.seatId })
      .from(candidateSeats)
      .where(eq(candidateSeats.candidateId, session.id))
      .limit(1)

    // Handle image upload
    let imageUrl: string | null = null
    const imageFile = formData.get('image') as File | null
    if (imageFile && imageFile.size > 0) {
      if (imageFile.size > 5 * 1024 * 1024) return apiError('Image must be under 5 MB')
      const upload = await uploadFormFile(imageFile, 'posts')
      if (!upload.success) return apiError('Image upload failed')
      imageUrl = upload.url!
    }

    // Create post
    const [newPost] = await db.insert(posts).values({
      authorId:    session.id,
      seatId:      cSeat?.seatId ?? null,
      contentText: sanitiseText(data.contentText),
      imageUrl,
    }).returning()

    // Create poll if requested
    if (data.hasPoll && data.pollQuestion && data.pollOptions) {
      const { polls: pollsTable } = await import('@/lib/db/schema')
      const endsAt = new Date()
      endsAt.setDate(endsAt.getDate() + (data.pollDuration ?? 3))

      await db.insert(pollsTable).values({
        postId:   newPost.id,
        question: data.pollQuestion,
        options:  data.pollOptions.map(text => ({ text, votes: 0 })),
        endsAt,
      })
    }

    return apiCreated(newPost)
  } catch (e) {
    console.error('[create-post]', e)
    return apiError('Failed to create post', 500)
  }
}
