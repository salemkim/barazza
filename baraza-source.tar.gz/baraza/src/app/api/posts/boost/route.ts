import { NextRequest } from 'next/server'
import { db }          from '@/lib/db'
import { posts, payments, candidateSeats, seats } from '@/lib/db/schema'
import { eq }          from 'drizzle-orm'
import { getSession }  from '@/lib/auth/session'
import { initiateSTKPush } from '@/lib/mpesa/daraja'
import { apiSuccess, apiError, BOOST_PRICES } from '@/lib/utils'
import type { SeatType } from '@/types'

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session)                    return apiError('Unauthorised', 401)
  if (session.role !== 'candidate') return apiError('Only candidates can boost posts', 403)
  if (!session.isVerifiedCandidate) return apiError('Account must be verified', 403)

  try {
    const { postId, phone } = await req.json()
    if (!postId) return apiError('postId required')

    const [post] = await db.select().from(posts).where(eq(posts.id, postId)).limit(1)
    if (!post)                        return apiError('Post not found', 404)
    if (post.authorId !== session.id) return apiError('You can only boost your own posts', 403)
    if (post.isBoosted && post.boostExpiresAt && post.boostExpiresAt > new Date()) {
      return apiError('Post is already boosted')
    }

    // Get seat type to determine price
    const [cSeat] = await db
      .select({ seat: seats })
      .from(candidateSeats)
      .innerJoin(seats, eq(candidateSeats.seatId, seats.id))
      .where(eq(candidateSeats.candidateId, session.id))
      .limit(1)

    const seatType = (cSeat?.seat.type ?? 'mca') as SeatType
    const amount   = BOOST_PRICES[seatType]
    const payPhone = (phone ?? session.phone).replace(/^\+/, '')

    // Create pending payment record
    const [payment] = await db.insert(payments).values({
      userId:      session.id,
      amount:      String(amount),
      type:        'boost',
      phoneUsed:   payPhone,
      metadata:    { postId, seatType },
    }).returning()

    // Initiate STK Push
    const stk = await initiateSTKPush({
      phone:            payPhone,
      amount,
      accountReference: `BOOST-${postId.slice(0, 8).toUpperCase()}`,
      transactionDesc:  'PostBoost',
    })

    if (!stk.success) {
      await db.update(payments).set({ status: 'failed', failureReason: stk.error })
        .where(eq(payments.id, payment.id))
      return apiError(stk.error ?? 'Payment initiation failed')
    }

    // Save M-Pesa request IDs
    await db.update(payments).set({
      mpesaCheckoutRequestId: stk.checkoutRequestId,
      mpesaMerchantRequestId: stk.merchantRequestId,
    }).where(eq(payments.id, payment.id))

    return apiSuccess({
      paymentId:         payment.id,
      checkoutRequestId: stk.checkoutRequestId,
      customerMessage:   stk.customerMessage,
      amount,
    }, 'STK Push sent. Complete payment on your phone.')
  } catch (e) {
    console.error('[boost]', e)
    return apiError('Failed to initiate boost', 500)
  }
}
