import { NextRequest } from 'next/server'
import { db }          from '@/lib/db'
import { polls, pollVotes } from '@/lib/db/schema'
import { eq, sql }     from 'drizzle-orm'
import { getSession }  from '@/lib/auth/session'
import { apiSuccess, apiError } from '@/lib/utils'
import { z } from 'zod'

const schema = z.object({
  pollId:      z.string().uuid(),
  optionIndex: z.number().int().min(0),
})

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return apiError('Unauthorised', 401)

  try {
    const body   = await req.json()
    const parsed = schema.safeParse(body)
    if (!parsed.success) return apiError(parsed.error.errors[0]?.message ?? 'Invalid input')

    const { pollId, optionIndex } = parsed.data

    const [poll] = await db.select().from(polls).where(eq(polls.id, pollId)).limit(1)
    if (!poll)                          return apiError('Poll not found', 404)
    if (new Date() > poll.endsAt)       return apiError('Poll has ended')

    const opts = poll.options as { text: string; votes: number }[]
    if (optionIndex >= opts.length)     return apiError('Invalid option')

    // Check already voted
    const [existing] = await db
      .select()
      .from(pollVotes)
      .where(eq(pollVotes.pollId, pollId))
      .limit(1)

    if (existing) return apiError('You have already voted in this poll')

    // Record vote
    await db.insert(pollVotes).values({ pollId, userId: session.id, optionIndex })

    // Increment option vote count in JSONB
    await db.execute(sql`
      UPDATE polls
      SET options = jsonb_set(
        options,
        ARRAY[${String(optionIndex)}, 'votes'],
        to_jsonb((options->${String(optionIndex)}->>'votes')::int + 1)
      )
      WHERE id = ${pollId}
    `)

    const [updated] = await db.select().from(polls).where(eq(polls.id, pollId)).limit(1)
    return apiSuccess({ options: updated.options })
  } catch (e) {
    console.error('[poll-vote]', e)
    return apiError('Failed to record vote', 500)
  }
}
