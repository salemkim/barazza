import { NextRequest } from 'next/server'
import { getSession, clearSession } from '@/lib/auth/session'
import { apiSuccess, apiError } from '@/lib/utils'
import { db }  from '@/lib/db'
import { users } from '@/lib/db/schema'
import { eq }  from 'drizzle-orm'

// GET /api/auth/session — return current user
export async function GET() {
  try {
    const session = await getSession()
    if (!session) return apiError('Not authenticated', 401)

    // Refresh from DB to get latest data
    const [user] = await db.select().from(users).where(eq(users.id, session.id)).limit(1)
    if (!user) { await clearSession(); return apiError('User not found', 401) }
    if (user.isSuspended) return apiError('Account suspended', 403)

    return apiSuccess({
      id:                  user.id,
      phone:               user.phone,
      username:            user.username,
      fullName:            user.fullName,
      role:                user.role,
      isVerifiedCandidate: user.isVerifiedCandidate,
      verificationStatus:  user.verificationStatus,
      subscriptionTier:    user.subscriptionTier,
      profileImageUrl:     user.profileImageUrl,
      party:               user.party,
      bio:                 user.bio,
      countyId:            user.countyId,
      constituencyId:      user.constituencyId,
      wardId:              user.wardId,
      subscriptionExpiry:  user.subscriptionExpiry,
    })
  } catch (e) {
    return apiError('Internal server error', 500)
  }
}

// DELETE /api/auth/session — logout
export async function DELETE() {
  await clearSession()
  return apiSuccess(null, 'Logged out')
}
