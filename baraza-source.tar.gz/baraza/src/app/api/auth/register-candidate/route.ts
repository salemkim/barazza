import { NextRequest }    from 'next/server'
import { db }             from '@/lib/db'
import { users, otpStore, seats, candidateSeats } from '@/lib/db/schema'
import { eq, and, gt }   from 'drizzle-orm'
import { normalisePhone, apiError, apiCreated } from '@/lib/utils'
import { createSession, setSessionCookie } from '@/lib/auth/session'
import { uploadFormFile } from '@/lib/storage/supabase-storage'
import { z } from 'zod'

const schema = z.object({
  phone:          z.string().min(9),
  otp:            z.string().length(6),
  username:       z.string().min(3).max(30).regex(/^[a-zA-Z0-9_]+$/),
  fullName:       z.string().min(2).max(200),
  email:          z.string().email().optional(),
  party:          z.string().min(1).max(100),
  seatType:       z.enum(['president', 'governor', 'senator', 'women_rep', 'mp', 'mca']),
  countyId:       z.number().int().positive().optional(),
  constituencyId: z.number().int().positive().optional(),
  wardId:         z.number().int().positive().optional(),
  bio:            z.string().max(1000).optional(),
})

export async function POST(req: NextRequest) {
  try {
    const formData = await req.formData()

    // Parse JSON fields from formData
    const raw = {
      phone:          formData.get('phone') as string,
      otp:            formData.get('otp')   as string,
      username:       formData.get('username') as string,
      fullName:       formData.get('fullName') as string,
      email:          formData.get('email') as string | undefined,
      party:          formData.get('party') as string,
      seatType:       formData.get('seatType') as string,
      countyId:       formData.get('countyId')       ? Number(formData.get('countyId'))       : undefined,
      constituencyId: formData.get('constituencyId') ? Number(formData.get('constituencyId')) : undefined,
      wardId:         formData.get('wardId')          ? Number(formData.get('wardId'))          : undefined,
      bio:            formData.get('bio') as string | undefined,
    }

    const parsed = schema.safeParse(raw)
    if (!parsed.success) return apiError(parsed.error.errors[0]?.message ?? 'Invalid input')

    const data       = parsed.data
    const normalised = normalisePhone(data.phone)

    // Verify OTP
    const [otpRecord] = await db
      .select()
      .from(otpStore)
      .where(and(
        eq(otpStore.phone,    normalised),
        eq(otpStore.otp,      data.otp),
        eq(otpStore.verified, false),
        gt(otpStore.expiresAt, new Date()),
      ))
      .limit(1)

    if (!otpRecord) return apiError('Invalid or expired OTP')
    await db.update(otpStore).set({ verified: true }).where(eq(otpStore.id, otpRecord.id))

    // Uniqueness checks
    const [byPhone] = await db.select({ id: users.id }).from(users).where(eq(users.phone, normalised)).limit(1)
    if (byPhone) return apiError('Phone already registered')

    const [byUsername] = await db.select({ id: users.id }).from(users).where(eq(users.username, data.username)).limit(1)
    if (byUsername) return apiError('Username already taken')

    // Upload verification document (required)
    const docFile = formData.get('verificationDoc') as File | null
    if (!docFile) return apiError('Verification document is required')
    if (docFile.size > 10 * 1024 * 1024) return apiError('Document must be under 10 MB')

    const upload = await uploadFormFile(docFile, 'verifications')
    if (!upload.success) return apiError('Document upload failed. Please try again.')

    // Find or create the seat
    let seatRecord = await db
      .select()
      .from(seats)
      .where(and(
        eq(seats.type, data.seatType as any),
        ...(data.countyId       ? [eq(seats.countyId, data.countyId)]             : []),
        ...(data.constituencyId ? [eq(seats.constituencyId, data.constituencyId)] : []),
        ...(data.wardId         ? [eq(seats.wardId, data.wardId)]                  : []),
      ))
      .limit(1)

    if (!seatRecord.length) {
      const label = buildSeatLabel(data.seatType, data.countyId, data.constituencyId, data.wardId)
      const [ns]  = await db.insert(seats).values({
        type:          data.seatType as any,
        countyId:      data.countyId ?? null,
        constituencyId: data.constituencyId ?? null,
        wardId:        data.wardId ?? null,
        displayLabel:  label,
      }).returning()
      seatRecord = [ns]
    }

    // Create user
    const [newUser] = await db.insert(users).values({
      phone:              normalised,
      email:              data.email ?? null,
      username:           data.username,
      fullName:           data.fullName,
      role:               'candidate',
      party:              data.party,
      bio:                data.bio ?? null,
      countyId:           data.countyId ?? null,
      constituencyId:     data.constituencyId ?? null,
      wardId:             data.wardId ?? null,
      verificationStatus: 'pending',
      verificationDocUrl: upload.url,
    }).returning()

    // Link candidate → seat
    await db.insert(candidateSeats).values({ candidateId: newUser.id, seatId: seatRecord[0].id })

    // Create session
    const token = await createSession({
      id:                  newUser.id,
      phone:               newUser.phone,
      username:            newUser.username,
      fullName:            newUser.fullName,
      role:                newUser.role,
      isVerifiedCandidate: false,
      verificationStatus:  'pending',
      subscriptionTier:    'free',
      profileImageUrl:     null,
      countyId:            newUser.countyId,
      constituencyId:      newUser.constituencyId,
      wardId:              newUser.wardId,
      isSuspended:         false,
    })
    await setSessionCookie(token)

    return apiCreated({ userId: newUser.id, verificationStatus: 'pending' })
  } catch (e) {
    console.error('[register-candidate]', e)
    return apiError('Internal server error', 500)
  }
}

function buildSeatLabel(
  type: string,
  countyId?: number,
  constituencyId?: number,
  wardId?: number,
): string {
  const labels: Record<string, string> = {
    president: 'President of Kenya',
    governor:  `Governor — County ${countyId ?? ''}`,
    senator:   `Senator — County ${countyId ?? ''}`,
    women_rep: `Women Representative — County ${countyId ?? ''}`,
    mp:        `MP — Constituency ${constituencyId ?? ''}`,
    mca:       `MCA — Ward ${wardId ?? ''}`,
  }
  return labels[type] ?? type
}
