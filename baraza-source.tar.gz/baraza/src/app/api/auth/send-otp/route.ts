import { NextRequest }        from 'next/server'
import { db }                 from '@/lib/db'
import { otpStore }           from '@/lib/db/schema'
import { sendOTPSMS }         from '@/lib/sms/africastalking'
import { generateOTP, normalisePhone, isValidKenyanPhone, apiSuccess, apiError } from '@/lib/utils'
import { addMinutes }         from 'date-fns'
import { eq, and, gt }        from 'drizzle-orm'

export async function POST(req: NextRequest) {
  try {
    const { phone } = await req.json()
    if (!phone) return apiError('Phone number required')

    const normalised = normalisePhone(phone)
    if (!isValidKenyanPhone(normalised)) return apiError('Invalid Kenyan phone number')

    // Rate limit: max 3 OTPs per phone per 10 minutes
    const recentOTPs = await db
      .select()
      .from(otpStore)
      .where(and(
        eq(otpStore.phone, normalised),
        gt(otpStore.expiresAt, new Date()),
      ))

    if (recentOTPs.length >= 3) {
      return apiError('Too many OTP requests. Please wait a few minutes.', 429)
    }

    const otp = generateOTP(6)
    const expiresAt = addMinutes(new Date(), 10)

    await db.insert(otpStore).values({ phone: normalised, otp, expiresAt })

    const result = await sendOTPSMS(normalised, otp)
    if (!result.success) {
      // In development, log the OTP so you can test without SMS credits
      if (process.env.NODE_ENV !== 'production') {
        console.log(`[DEV] OTP for ${normalised}: ${otp}`)
        return apiSuccess({ dev_otp: otp }, 'OTP sent (dev mode)')
      }
      return apiError('Failed to send OTP. Please try again.')
    }

    return apiSuccess({ phone: normalised }, 'OTP sent successfully')
  } catch (e) {
    console.error('[send-otp]', e)
    return apiError('Internal server error', 500)
  }
}
