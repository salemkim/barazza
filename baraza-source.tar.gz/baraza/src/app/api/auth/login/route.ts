import { NextRequest }  from 'next/server'
import { db }           from '@/lib/db'
import { users, otpStore } from '@/lib/db/schema'
import { eq, and, gt } from 'drizzle-orm'
import { normalisePhone, apiSuccess, apiError } from '@/lib/utils'
import { createSession, setSessionCookie, getSession, clearSession } from '@/lib/auth/session'

// POST /api/auth/login — verify OTP and issue session
export async function POST(req: NextRequest) {
  try {
    const { phone, otp } = await req.json()
    if (!phone || !otp) return apiError('Phone and OTP required')

    const normalised = normalisePhone(phone)

    const [record] = await db
      .select()
      .from(otpStore)
      .where(and(
        eq(otpStore.phone,    normalised),
        eq(otpStore.otp,      String(otp)),
        eq(otpStore.verified, false),
        gt(otpStore.expiresAt, new Date()),
      ))
      .limit(1)

    if (!record) return apiError('Invalid or expired OTP', 401)

    // Mark used
    await db.update(otpStore).set({ verified: true }).where(eq(otpStore.id, record.id))

    // Find user
    const [user] = await db.select().from(users).where(eq(users.phone, normalised)).limit(1)
    if (!user) return apiError('Account not found. Please register first.', 404)

    if (user.isSuspended) return apiError('Your account has been suspended.', 403)

    const token = await createSession({
      id:                  user.id,
      phone:               user.phone,
      username:            user.username,
      fullName:            user.fullName,
      role:                user.role,
      isVerifiedCandidate: user.isVerifiedCandidate,
      verificationStatus:  user.verificationStatus,
      subscriptionTier:    user.subscriptionTier,
      profileImageUrl:     user.profileImageUrl,
      countyId:            user.countyId,
      constituencyId:      user.constituencyId,
      wardId:              user.wardId,
      isSuspended:         user.isSuspended,
    })
    await setSessionCookie(token)

    return apiSuccess({ role: user.role, userId: user.id }, 'Logged in successfully')
  } catch (e) {
    console.error('[login]', e)
    return apiError('Internal server error', 500)
  }
}
