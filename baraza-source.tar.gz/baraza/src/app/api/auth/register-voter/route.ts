import { NextRequest }  from 'next/server'
import { db }           from '@/lib/db'
import { users, otpStore } from '@/lib/db/schema'
import { eq, and, gt } from 'drizzle-orm'
import { normalisePhone, apiSuccess, apiError, apiCreated } from '@/lib/utils'
import { createSession, setSessionCookie } from '@/lib/auth/session'
import { z } from 'zod'

const schema = z.object({
  phone:          z.string().min(9),
  otp:            z.string().length(6),
  username:       z.string().min(3).max(30).regex(/^[a-zA-Z0-9_]+$/),
  countyId:       z.number().int().positive(),
  constituencyId: z.number().int().positive(),
  wardId:         z.number().int().positive().optional(),
})

export async function POST(req: NextRequest) {
  try {
    const body   = await req.json()
    const parsed = schema.safeParse(body)
    if (!parsed.success) return apiError(parsed.error.errors[0]?.message ?? 'Invalid input')

    const { phone, otp, username, countyId, constituencyId, wardId } = parsed.data
    const normalised = normalisePhone(phone)

    // Verify OTP
    const [record] = await db
      .select()
      .from(otpStore)
      .where(and(
        eq(otpStore.phone, normalised),
        eq(otpStore.otp,   otp),
        eq(otpStore.verified, false),
        gt(otpStore.expiresAt, new Date()),
      ))
      .limit(1)

    if (!record) return apiError('Invalid or expired OTP')

    // Mark OTP used
    await db.update(otpStore).set({ verified: true }).where(eq(otpStore.id, record.id))

    // Check username / phone uniqueness
    const [existing] = await db
      .select({ id: users.id })
      .from(users)
      .where(eq(users.phone, normalised))
      .limit(1)

    if (existing) return apiError('Phone number already registered')

    const [byUsername] = await db
      .select({ id: users.id })
      .from(users)
      .where(eq(users.username, username))
      .limit(1)

    if (byUsername) return apiError('Username already taken')

    // Create user
    const [newUser] = await db.insert(users).values({
      phone:          normalised,
      username,
      role:           'voter',
      countyId,
      constituencyId,
      wardId:         wardId ?? null,
    }).returning()

    // Create session
    const token = await createSession({
      id:                  newUser.id,
      phone:               newUser.phone,
      username:            newUser.username,
      fullName:            newUser.fullName,
      role:                newUser.role,
      isVerifiedCandidate: newUser.isVerifiedCandidate,
      verificationStatus:  newUser.verificationStatus,
      subscriptionTier:    newUser.subscriptionTier,
      profileImageUrl:     newUser.profileImageUrl,
      countyId:            newUser.countyId,
      constituencyId:      newUser.constituencyId,
      wardId:              newUser.wardId,
      isSuspended:         newUser.isSuspended,
    })
    await setSessionCookie(token)

    return apiCreated({ userId: newUser.id, username: newUser.username, role: 'voter' })
  } catch (e) {
    console.error('[register-voter]', e)
    return apiError('Internal server error', 500)
  }
}
