import { NextRequest } from 'next/server'
import { db }          from '@/lib/db'
import { payments, posts, boostPurchases, subscriptions, users } from '@/lib/db/schema'
import { eq } from 'drizzle-orm'
import { parseMpesaCallback, type MpesaCallbackBody } from '@/lib/mpesa/daraja'
import { addHours, addMonths } from 'date-fns'

export async function POST(req: NextRequest) {
  try {
    const body: MpesaCallbackBody = await req.json()
    const cb = parseMpesaCallback(body)

    console.log('[MPesa callback]', JSON.stringify(cb, null, 2))

    // Find the payment record
    const [payment] = await db
      .select()
      .from(payments)
      .where(eq(payments.mpesaCheckoutRequestId, cb.checkoutRequestId))
      .limit(1)

    if (!payment) {
      console.error('[MPesa] No payment found for checkoutRequestId:', cb.checkoutRequestId)
      return new Response('OK', { status: 200 }) // Always return 200 to M-Pesa
    }

    if (!cb.success) {
      await db.update(payments).set({
        status:        'failed',
        failureReason: cb.resultDesc,
      }).where(eq(payments.id, payment.id))
      return new Response('OK', { status: 200 })
    }

    // Mark payment completed
    await db.update(payments).set({
      status:              'completed',
      mpesaReceiptNumber:  cb.receiptNumber,
      completedAt:         new Date(),
    }).where(eq(payments.id, payment.id))

    const meta = payment.metadata as Record<string, unknown>

    // ── Subscription payment ──────────────────────────────────────────────────
    if (payment.type === 'subscription' && payment.packageTier) {
      const tier      = payment.packageTier as 'silver' | 'gold' | 'platinum'
      const endDate   = addMonths(new Date(), 1)

      // Upsert subscription
      await db.insert(subscriptions).values({
        userId:    payment.userId,
        tier,
        endDate,
        paymentId: payment.id,
      }).onConflictDoUpdate({
        target: subscriptions.userId,
        set:    { tier, endDate, paymentId: payment.id, startDate: new Date() },
      })

      // Update user's subscription tier and expiry
      await db.update(users).set({
        subscriptionTier:   tier,
        subscriptionExpiry: endDate,
        updatedAt:          new Date(),
      }).where(eq(users.id, payment.userId))
    }

    // ── Boost payment ─────────────────────────────────────────────────────────
    if (payment.type === 'boost' && meta?.postId) {
      const postId     = meta.postId as string
      const expiresAt  = addHours(new Date(), 24)

      await db.update(posts).set({
        isBoosted:      true,
        boostExpiresAt: expiresAt,
        updatedAt:      new Date(),
      }).where(eq(posts.id, postId))

      await db.insert(boostPurchases).values({
        userId:        payment.userId,
        postId,
        durationHours: 24,
        expiresAt,
        paymentId:     payment.id,
      })
    }

    return new Response('OK', { status: 200 })
  } catch (e) {
    console.error('[MPesa callback error]', e)
    return new Response('OK', { status: 200 }) // Always 200 to M-Pesa
  }
}
