import { NextRequest }  from 'next/server'
import { db }           from '@/lib/db'
import { posts, users, seats, postLikes, polls, pollVotes, candidateSeats } from '@/lib/db/schema'
import { eq, and, or, inArray, desc, gt, isNull } from 'drizzle-orm'
import { getSession }   from '@/lib/auth/session'
import { apiSuccess, apiError } from '@/lib/utils'
import type { FeedPost } from '@/types'

export async function GET(req: NextRequest) {
  try {
    const session = await getSession()
    const params  = req.nextUrl.searchParams
    const page    = Math.max(1, Number(params.get('page') ?? 1))
    const limit   = Math.min(20, Number(params.get('limit') ?? 10))
    const offset  = (page - 1) * limit

    // Determine which seats to show based on user location
    let seatIds: number[] = []

    if (session) {
      // All presidential seats (no county filter)
      const presidentialSeats = await db
        .select({ id: seats.id })
        .from(seats)
        .where(eq(seats.type, 'president'))

      seatIds.push(...presidentialSeats.map(s => s.id))

      // County-level seats if user has a county
      if (session.countyId) {
        const countySeats = await db
          .select({ id: seats.id })
          .from(seats)
          .where(and(
            inArray(seats.type, ['governor', 'senator', 'women_rep']),
            eq(seats.countyId, session.countyId),
          ))
        seatIds.push(...countySeats.map(s => s.id))
      }

      // Constituency-level seats
      if (session.constituencyId) {
        const constituencySeats = await db
          .select({ id: seats.id })
          .from(seats)
          .where(and(
            eq(seats.type, 'mp'),
            eq(seats.constituencyId, session.constituencyId),
          ))
        seatIds.push(...constituencySeats.map(s => s.id))
      }

      // Ward-level seats
      if (session.wardId) {
        const wardSeats = await db
          .select({ id: seats.id })
          .from(seats)
          .where(and(
            eq(seats.type, 'mca'),
            eq(seats.wardId, session.wardId),
          ))
        seatIds.push(...wardSeats.map(s => s.id))
      }
    } else {
      // Anonymous: show presidential posts only
      const presidentialSeats = await db.select({ id: seats.id }).from(seats).where(eq(seats.type, 'president'))
      seatIds = presidentialSeats.map(s => s.id)
    }

    if (seatIds.length === 0) return apiSuccess({ posts: [], hasMore: false, page })

    // Fetch posts for those seats, boosted first
    const now = new Date()
    const rawPosts = await db
      .select({
        post:   posts,
        author: users,
        seat:   seats,
      })
      .from(posts)
      .innerJoin(users, eq(posts.authorId, users.id))
      .leftJoin(seats, eq(posts.seatId,   seats.id))
      .where(and(
        eq(posts.isDeleted, false),
        inArray(posts.seatId, seatIds),
        eq(users.isSuspended, false),
      ))
      .orderBy(
        // Boosted posts bubble to top if still active
        desc(and(eq(posts.isBoosted, true), gt(posts.boostExpiresAt!, now))),
        desc(posts.createdAt),
      )
      .limit(limit)
      .offset(offset)

    // Get liked post IDs for this user
    const likedPostIds = new Set<string>()
    if (session) {
      const likes = await db
        .select({ postId: postLikes.postId })
        .from(postLikes)
        .where(and(
          eq(postLikes.userId, session.id),
          inArray(postLikes.postId, rawPosts.map(r => r.post.id)),
        ))
      likes.forEach(l => likedPostIds.add(l.postId))
    }

    // Fetch polls for these posts
    const postIds   = rawPosts.map(r => r.post.id)
    const pollsData = postIds.length > 0
      ? await db.select().from(polls).where(inArray(polls.postId, postIds))
      : []

    // Fetch user's poll votes
    const userVotes = new Map<string, number>()
    if (session && pollsData.length > 0) {
      const votes = await db
        .select()
        .from(pollVotes)
        .where(and(
          eq(pollVotes.userId, session.id),
          inArray(pollVotes.pollId, pollsData.map(p => p.id)),
        ))
      votes.forEach(v => userVotes.set(v.pollId, v.optionIndex))
    }

    const pollsByPostId = new Map(pollsData.map(p => [p.postId, p]))

    const feed: FeedPost[] = rawPosts.map(({ post, author, seat }) => {
      const poll = pollsByPostId.get(post.id)
      return {
        id:             post.id,
        contentText:    post.contentText,
        imageUrl:       post.imageUrl,
        videoUrl:       post.videoUrl,
        isBoosted:      post.isBoosted && !!(post.boostExpiresAt && post.boostExpiresAt > now),
        boostExpiresAt: post.boostExpiresAt?.toISOString() ?? null,
        likesCount:     post.likesCount,
        commentsCount:  post.commentsCount,
        createdAt:      post.createdAt.toISOString(),
        hasLiked:       likedPostIds.has(post.id),
        author: {
          id:                  author.id,
          username:            author.username,
          fullName:            author.fullName,
          profileImageUrl:     author.profileImageUrl,
          party:               author.party,
          isVerifiedCandidate: author.isVerifiedCandidate,
          subscriptionTier:    author.subscriptionTier,
        },
        seat: seat ? { id: seat.id, type: seat.type, displayLabel: seat.displayLabel } : null,
        poll: poll ? {
          id:       poll.id,
          question: poll.question,
          options:  poll.options as { text: string; votes: number }[],
          endsAt:   poll.endsAt.toISOString(),
          hasVoted: userVotes.has(poll.id),
          userVote: userVotes.get(poll.id) ?? null,
        } : null,
      }
    })

    return apiSuccess({ posts: feed, hasMore: rawPosts.length === limit, page })
  } catch (e) {
    console.error('[feed]', e)
    return apiError('Failed to fetch feed', 500)
  }
}
