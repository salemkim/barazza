import { NextRequest } from 'next/server'
import { db }          from '@/lib/db'
import { payments }    from '@/lib/db/schema'
import { eq, and }     from 'drizzle-orm'
import { getSession }  from '@/lib/auth/session'
import { apiSuccess, apiError } from '@/lib/utils'

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getSession()
  if (!session) return apiError('Unauthorised', 401)

  const [payment] = await db
    .select({ id: payments.id, status: payments.status, amount: payments.amount, type: payments.type })
    .from(payments)
    .where(and(eq(payments.id, params.id), eq(payments.userId, session.id)))
    .limit(1)

  if (!payment) return apiError('Payment not found', 404)
  return apiSuccess(payment)
}
