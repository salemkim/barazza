import { NextRequest } from 'next/server'
import { db }          from '@/lib/db'
import { payments }    from '@/lib/db/schema'
import { eq, desc }    from 'drizzle-orm'
import { getSession }  from '@/lib/auth/session'
import { apiSuccess, apiError } from '@/lib/utils'

export async function GET() {
  const session = await getSession()
  if (!session) return apiError('Unauthorised', 401)

  const rows = await db
    .select()
    .from(payments)
    .where(eq(payments.userId, session.id))
    .orderBy(desc(payments.createdAt))
    .limit(20)

  return apiSuccess(rows)
}
