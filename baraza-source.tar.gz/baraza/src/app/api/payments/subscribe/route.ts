import { NextRequest } from 'next/server'
import { db }          from '@/lib/db'
import { payments, candidateSeats, seats } from '@/lib/db/schema'
import { eq }          from 'drizzle-orm'
import { getSession }  from '@/lib/auth/session'
import { initiateSTKPush } from '@/lib/mpesa/daraja'
import { apiSuccess, apiError, SUBSCRIPTION_PRICES } from '@/lib/utils'
import type { SeatType, SubscriptionTier } from '@/types'
import { z } from 'zod'

const schema = z.object({
  tier:  z.enum(['silver', 'gold', 'platinum']),
  phone: z.string().optional(),
})

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session)                    return apiError('Unauthorised', 401)
  if (session.role !== 'candidate') return apiError('Only candidates can subscribe', 403)
  if (!session.isVerifiedCandidate) return apiError('Account must be verified first', 403)

  try {
    const body   = await req.json()
    const parsed = schema.safeParse(body)
    if (!parsed.success) return apiError(parsed.error.errors[0]?.message ?? 'Invalid input')

    const { tier, phone } = parsed.data

    // Get candidate seat type for pricing
    const [cSeat] = await db
      .select({ seat: seats })
      .from(candidateSeats)
      .innerJoin(seats, eq(candidateSeats.seatId, seats.id))
      .where(eq(candidateSeats.candidateId, session.id))
      .limit(1)

    const seatType = (cSeat?.seat.type ?? 'mca') as SeatType
    const amount   = SUBSCRIPTION_PRICES[seatType][tier]
    const payPhone = (phone ?? session.phone).replace(/^\+/, '')

    // Create pending payment
    const [payment] = await db.insert(payments).values({
      userId:      session.id,
      amount:      String(amount),
      type:        'subscription',
      packageTier: tier,
      phoneUsed:   payPhone,
      metadata:    { seatType, tier },
    }).returning()

    const stk = await initiateSTKPush({
      phone:            payPhone,
      amount,
      accountReference: `SUB-${session.id.slice(0, 8).toUpperCase()}`,
      transactionDesc:  `${tier}Sub`,
    })

    if (!stk.success) {
      await db.update(payments).set({ status: 'failed', failureReason: stk.error })
        .where(eq(payments.id, payment.id))
      return apiError(stk.error ?? 'Payment initiation failed')
    }

    await db.update(payments).set({
      mpesaCheckoutRequestId: stk.checkoutRequestId,
      mpesaMerchantRequestId: stk.merchantRequestId,
    }).where(eq(payments.id, payment.id))

    return apiSuccess({
      paymentId:         payment.id,
      checkoutRequestId: stk.checkoutRequestId,
      customerMessage:   stk.customerMessage,
      amount,
      tier,
    }, 'STK Push sent. Complete payment on your phone.')
  } catch (e) {
    console.error('[subscribe]', e)
    return apiError('Failed to initiate subscription', 500)
  }
}
