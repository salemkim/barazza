// /api/candidate/stats
import { NextRequest } from 'next/server'
import { db }          from '@/lib/db'
import { posts, postLikes, comments } from '@/lib/db/schema'
import { eq, and, sql } from 'drizzle-orm'
import { getSession }  from '@/lib/auth/session'
import { apiSuccess, apiError } from '@/lib/utils'

export async function GET() {
  const session = await getSession()
  if (!session) return apiError('Unauthorised', 401)

  try {
    const [postStats] = await db
      .select({
        totalPosts:    sql<number>`count(*)`,
        totalLikes:    sql<number>`sum(${posts.likesCount})`,
        totalComments: sql<number>`sum(${posts.commentsCount})`,
      })
      .from(posts)
      .where(and(eq(posts.authorId, session.id), eq(posts.isDeleted, false)))

    return apiSuccess({
      totalPosts:    Number(postStats?.totalPosts    ?? 0),
      totalLikes:    Number(postStats?.totalLikes    ?? 0),
      totalComments: Number(postStats?.totalComments ?? 0),
      followerCount: 0, // future feature
    })
  } catch (e) {
    return apiError('Failed to fetch stats', 500)
  }
}
