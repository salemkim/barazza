import { db }        from '@/lib/db'
import { posts }      from '@/lib/db/schema'
import { eq, and, desc, sql } from 'drizzle-orm'
import { getSession } from '@/lib/auth/session'
import { apiSuccess, apiError } from '@/lib/utils'

export async function GET() {
  const session = await getSession()
  if (!session) return apiError('Unauthorised', 401)

  const top = await db
    .select({
      id:           posts.id,
      contentText:  posts.contentText,
      likesCount:   posts.likesCount,
      commentsCount: posts.commentsCount,
      isBoosted:    posts.isBoosted,
      createdAt:    posts.createdAt,
    })
    .from(posts)
    .where(and(eq(posts.authorId, session.id), eq(posts.isDeleted, false)))
    .orderBy(desc(sql`${posts.likesCount} + ${posts.commentsCount}`))
    .limit(5)

  return apiSuccess(top)
}
