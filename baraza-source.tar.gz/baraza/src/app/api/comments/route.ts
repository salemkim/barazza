import { NextRequest } from 'next/server'
import { db }          from '@/lib/db'
import { comments, posts } from '@/lib/db/schema'
import { eq, and, isNull, asc, sql } from 'drizzle-orm'
import { getSession }  from '@/lib/auth/session'
import { apiSuccess, apiError, apiCreated, containsProfanity, sanitiseText } from '@/lib/utils'
import { z } from 'zod'

const schema = z.object({
  postId:          z.string().uuid(),
  text:            z.string().min(1).max(1000),
  parentCommentId: z.string().uuid().optional(),
})

// GET /api/comments?postId=
export async function GET(req: NextRequest) {
  const postId = req.nextUrl.searchParams.get('postId')
  if (!postId) return apiError('postId required')

  try {
    const rows = await db
      .select({
        id:              comments.id,
        text:            comments.text,
        parentCommentId: comments.parentCommentId,
        createdAt:       comments.createdAt,
        authorId:        comments.authorId,
      })
      .from(comments)
      .where(and(eq(comments.postId, postId), eq(comments.isDeleted, false)))
      .orderBy(asc(comments.createdAt))

    return apiSuccess(rows)
  } catch (e) {
    return apiError('Failed to fetch comments', 500)
  }
}

// POST /api/comments
export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session) return apiError('Unauthorised', 401)

  try {
    const body   = await req.json()
    const parsed = schema.safeParse(body)
    if (!parsed.success) return apiError(parsed.error.errors[0]?.message ?? 'Invalid input')

    const { postId, text, parentCommentId } = parsed.data

    if (containsProfanity(text)) return apiError('Comment contains inappropriate language')

    // Verify post exists
    const [post] = await db.select({ id: posts.id }).from(posts).where(eq(posts.id, postId)).limit(1)
    if (!post) return apiError('Post not found', 404)

    const [newComment] = await db.insert(comments).values({
      postId,
      authorId:        session.id,
      text:            sanitiseText(text),
      parentCommentId: parentCommentId ?? null,
    }).returning()

    // Increment counter
    await db.update(posts)
      .set({ commentsCount: sql`${posts.commentsCount} + 1` })
      .where(eq(posts.id, postId))

    return apiCreated(newComment)
  } catch (e) {
    console.error('[create-comment]', e)
    return apiError('Failed to create comment', 500)
  }
}

// DELETE /api/comments?id=
export async function DELETE(req: NextRequest) {
  const session = await getSession()
  if (!session) return apiError('Unauthorised', 401)

  const id = req.nextUrl.searchParams.get('id')
  if (!id) return apiError('id required')

  try {
    const [comment] = await db.select().from(comments).where(eq(comments.id, id)).limit(1)
    if (!comment) return apiError('Comment not found', 404)
    if (comment.authorId !== session.id && session.role !== 'admin') return apiError('Forbidden', 403)

    await db.update(comments).set({ isDeleted: true }).where(eq(comments.id, id))

    // Decrement counter
    await db.update(posts)
      .set({ commentsCount: sql`GREATEST(${posts.commentsCount} - 1, 0)` })
      .where(eq(posts.id, comment.postId))

    return apiSuccess(null, 'Comment deleted')
  } catch (e) {
    return apiError('Failed to delete comment', 500)
  }
}
