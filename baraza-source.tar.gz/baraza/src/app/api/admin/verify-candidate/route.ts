import { NextRequest } from 'next/server'
import { db }          from '@/lib/db'
import { users }       from '@/lib/db/schema'
import { eq }          from 'drizzle-orm'
import { getSession }  from '@/lib/auth/session'
import { apiSuccess, apiError } from '@/lib/utils'
import { sendSMS }     from '@/lib/sms/africastalking'
import { z } from 'zod'

const schema = z.object({
  candidateId: z.string().uuid(),
  action:      z.enum(['approve', 'reject']),
  notes:       z.string().max(500).optional(),
})

export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session || session.role !== 'admin') return apiError('Forbidden', 403)

  try {
    const body   = await req.json()
    const parsed = schema.safeParse(body)
    if (!parsed.success) return apiError(parsed.error.errors[0]?.message ?? 'Invalid input')

    const { candidateId, action, notes } = parsed.data

    const [candidate] = await db.select().from(users).where(eq(users.id, candidateId)).limit(1)
    if (!candidate)                    return apiError('Candidate not found', 404)
    if (candidate.role !== 'candidate') return apiError('User is not a candidate')

    const approved = action === 'approve'

    await db.update(users).set({
      isVerifiedCandidate: approved,
      verificationStatus:  approved ? 'approved' : 'rejected',
      verificationNotes:   notes ?? null,
      verifiedAt:          approved ? new Date() : null,
      verifiedBy:          approved ? session.id : null,
      updatedAt:           new Date(),
    }).where(eq(users.id, candidateId))

    // Notify candidate by SMS
    const smsText = approved
      ? `Baraza: Congratulations ${candidate.fullName ?? candidate.username}! Your candidate account has been verified. You can now post and use premium features.`
      : `Baraza: Your candidate verification was not approved. ${notes ? `Reason: ${notes}` : 'Please contact support for more information.'}`

    await sendSMS(candidate.phone, smsText)

    return apiSuccess({ candidateId, status: approved ? 'approved' : 'rejected' },
      `Candidate ${approved ? 'approved' : 'rejected'} successfully`)
  } catch (e) {
    console.error('[verify-candidate]', e)
    return apiError('Failed to update verification status', 500)
  }
}
