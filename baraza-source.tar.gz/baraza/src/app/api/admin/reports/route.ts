import { NextRequest } from 'next/server'
import { db }          from '@/lib/db'
import { reports, posts, comments, directMessages, users } from '@/lib/db/schema'
import { eq, and, desc } from 'drizzle-orm'
import { getSession }  from '@/lib/auth/session'
import { apiSuccess, apiError } from '@/lib/utils'
import { z } from 'zod'

// GET /api/admin/reports?resolved=false
export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session || session.role !== 'admin') return apiError('Forbidden', 403)

  const resolved = req.nextUrl.searchParams.get('resolved') === 'true'
  const page     = Math.max(1, Number(req.nextUrl.searchParams.get('page') ?? 1))
  const limit    = 20
  const offset   = (page - 1) * limit

  try {
    const rows = await db
      .select({
        report:     reports,
        reporterUsername: users.username,
      })
      .from(reports)
      .innerJoin(users, eq(reports.reportedBy, users.id))
      .where(eq(reports.resolved, resolved))
      .orderBy(desc(reports.createdAt))
      .limit(limit).offset(offset)

    return apiSuccess({ reports: rows, page, hasMore: rows.length === limit })
  } catch (e) {
    return apiError('Failed to fetch reports', 500)
  }
}

const resolveSchema = z.object({
  reportId:    z.string().uuid(),
  action:      z.enum(['dismiss', 'delete_content', 'suspend_user']),
  actionNotes: z.string().max(500).optional(),
  suspendDays: z.number().int().min(1).max(365).optional(),
})

// POST /api/admin/reports — resolve a report
export async function POST(req: NextRequest) {
  const session = await getSession()
  if (!session || session.role !== 'admin') return apiError('Forbidden', 403)

  try {
    const body   = await req.json()
    const parsed = resolveSchema.safeParse(body)
    if (!parsed.success) return apiError(parsed.error.errors[0]?.message ?? 'Invalid input')

    const { reportId, action, actionNotes, suspendDays } = parsed.data

    const [report] = await db.select().from(reports).where(eq(reports.id, reportId)).limit(1)
    if (!report)            return apiError('Report not found', 404)
    if (report.resolved)    return apiError('Report already resolved')

    if (action === 'delete_content') {
      if (report.contentType === 'post') {
        await db.update(posts).set({ isDeleted: true, deletedAt: new Date() })
          .where(eq(posts.id, report.contentId))
      } else if (report.contentType === 'comment') {
        await db.update(comments).set({ isDeleted: true })
          .where(eq(comments.id, report.contentId))
      } else if (report.contentType === 'message') {
        await db.update(directMessages).set({ isDeleted: true })
          .where(eq(directMessages.id, report.contentId))
      }
    }

    if (action === 'suspend_user' && suspendDays) {
      // Find user from content
      let userId: string | null = null
      if (report.contentType === 'post') {
        const [p] = await db.select({ authorId: posts.authorId }).from(posts).where(eq(posts.id, report.contentId)).limit(1)
        userId = p?.authorId ?? null
      } else if (report.contentType === 'comment') {
        const [c] = await db.select({ authorId: comments.authorId }).from(comments).where(eq(comments.id, report.contentId)).limit(1)
        userId = c?.authorId ?? null
      }

      if (userId) {
        const suspendUntil = new Date()
        suspendUntil.setDate(suspendUntil.getDate() + suspendDays)
        await db.update(users).set({
          isSuspended:   true,
          suspendedUntil: suspendUntil,
          suspendReason: actionNotes ?? 'Policy violation',
        }).where(eq(users.id, userId))
      }
    }

    await db.update(reports).set({
      resolved:    true,
      resolvedBy:  session.id,
      resolvedAt:  new Date(),
      actionTaken: `${action}${actionNotes ? ': ' + actionNotes : ''}`,
    }).where(eq(reports.id, reportId))

    return apiSuccess(null, 'Report resolved')
  } catch (e) {
    console.error('[resolve-report]', e)
    return apiError('Failed to resolve report', 500)
  }
}
