import { NextRequest } from 'next/server'
import { db }          from '@/lib/db'
import { users, candidateSeats, seats } from '@/lib/db/schema'
import { eq, desc }    from 'drizzle-orm'
import { getSession }  from '@/lib/auth/session'
import { apiSuccess, apiError } from '@/lib/utils'

export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session || session.role !== 'admin') return apiError('Forbidden', 403)

  const status = (req.nextUrl.searchParams.get('status') ?? 'pending') as 'pending' | 'approved' | 'rejected'
  const page   = Math.max(1, Number(req.nextUrl.searchParams.get('page') ?? 1))
  const limit  = 20
  const offset = (page - 1) * limit

  try {
    const rows = await db
      .select({
        id:                 users.id,
        username:           users.username,
        fullName:           users.fullName,
        phone:              users.phone,
        email:              users.email,
        party:              users.party,
        bio:                users.bio,
        verificationStatus: users.verificationStatus,
        verificationDocUrl: users.verificationDocUrl,
        verificationNotes:  users.verificationNotes,
        verifiedAt:         users.verifiedAt,
        createdAt:          users.createdAt,
        seatType:           seats.type,
        seatLabel:          seats.displayLabel,
      })
      .from(users)
      .leftJoin(candidateSeats, eq(candidateSeats.candidateId, users.id))
      .leftJoin(seats, eq(seats.id, candidateSeats.seatId))
      .where(eq(users.verificationStatus, status as any))
      .orderBy(desc(users.createdAt))
      .limit(limit).offset(offset)

    return apiSuccess({ candidates: rows, page, hasMore: rows.length === limit })
  } catch (e) {
    console.error('[admin-candidates]', e)
    return apiError('Failed to fetch candidates', 500)
  }
}
