import { db }         from '@/lib/db'
import { users, posts, payments, subscriptions, reports } from '@/lib/db/schema'
import { eq, and, gt, sql } from 'drizzle-orm'
import { getSession } from '@/lib/auth/session'
import { apiSuccess, apiError } from '@/lib/utils'

export async function GET() {
  const session = await getSession()
  if (!session || session.role !== 'admin') return apiError('Forbidden', 403)

  const [
    [userCount], [candidateCount], [verifiedCount], [pendingCount],
    [postCount], [reportCount], [revenueRow], [subCount],
  ] = await Promise.all([
    db.select({ c: sql<number>`count(*)` }).from(users),
    db.select({ c: sql<number>`count(*)` }).from(users).where(eq(users.role, 'candidate')),
    db.select({ c: sql<number>`count(*)` }).from(users).where(eq(users.isVerifiedCandidate, true)),
    db.select({ c: sql<number>`count(*)` }).from(users).where(eq(users.verificationStatus, 'pending')),
    db.select({ c: sql<number>`count(*)` }).from(posts).where(eq(posts.isDeleted, false)),
    db.select({ c: sql<number>`count(*)` }).from(reports).where(eq(reports.resolved, false)),
    db.select({ total: sql<number>`coalesce(sum(amount),0)` }).from(payments).where(eq(payments.status, 'completed')),
    db.select({ c: sql<number>`count(*)` }).from(subscriptions).where(gt(subscriptions.endDate, new Date())),
  ])

  return apiSuccess({
    totalUsers:           Number(userCount.c),
    totalCandidates:      Number(candidateCount.c),
    verifiedCandidates:   Number(verifiedCount.c),
    pendingVerifications: Number(pendingCount.c),
    totalPosts:           Number(postCount.c),
    openReports:          Number(reportCount.c),
    totalRevenue:         Number(revenueRow.total),
    activeSubscriptions:  Number(subCount.c),
  })
}
