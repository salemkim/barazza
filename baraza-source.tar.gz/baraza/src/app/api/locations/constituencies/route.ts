import { NextRequest }    from 'next/server'
import { db }             from '@/lib/db'
import { constituencies } from '@/lib/db/schema'
import { eq, asc }        from 'drizzle-orm'
import { apiSuccess, apiError } from '@/lib/utils'

export async function GET(req: NextRequest) {
  const countyId = Number(req.nextUrl.searchParams.get('county'))
  if (!countyId) return apiError('county param required')

  try {
    const rows = await db
      .select({ id: constituencies.id, name: constituencies.name, code: constituencies.code })
      .from(constituencies)
      .where(eq(constituencies.countyId, countyId))
      .orderBy(asc(constituencies.name))
    return apiSuccess(rows)
  } catch (e) {
    return apiError('Failed to fetch constituencies', 500)
  }
}
