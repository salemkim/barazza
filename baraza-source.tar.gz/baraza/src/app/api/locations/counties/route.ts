// /api/locations/counties
import { db }            from '@/lib/db'
import { counties }      from '@/lib/db/schema'
import { asc }           from 'drizzle-orm'
import { apiSuccess, apiError } from '@/lib/utils'

export async function GET() {
  try {
    const rows = await db.select({ id: counties.id, name: counties.name, code: counties.code })
      .from(counties).orderBy(asc(counties.name))
    return apiSuccess(rows)
  } catch (e) {
    return apiError('Failed to fetch counties', 500)
  }
}
