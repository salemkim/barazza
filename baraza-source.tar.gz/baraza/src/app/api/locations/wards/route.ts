import { NextRequest } from 'next/server'
import { db }          from '@/lib/db'
import { wards }       from '@/lib/db/schema'
import { eq, asc }     from 'drizzle-orm'
import { apiSuccess, apiError } from '@/lib/utils'

export async function GET(req: NextRequest) {
  const constituencyId = Number(req.nextUrl.searchParams.get('constituency'))
  if (!constituencyId) return apiError('constituency param required')

  try {
    const rows = await db
      .select({ id: wards.id, name: wards.name, code: wards.code })
      .from(wards)
      .where(eq(wards.constituencyId, constituencyId))
      .orderBy(asc(wards.name))
    return apiSuccess(rows)
  } catch (e) {
    return apiError('Failed to fetch wards', 500)
  }
}
