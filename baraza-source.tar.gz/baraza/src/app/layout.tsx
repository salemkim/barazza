import type { Metadata } from 'next'
import { Inter }         from 'next/font/google'
import './globals.css'
import { Toaster }       from 'sonner'
import Providers         from '@/components/Providers'

const inter = Inter({ subsets: ['latin'], variable: '--font-sans' })

export const metadata: Metadata = {
  title:       'Baraza — Kenya Civic Platform',
  description: 'Connect with verified political candidates in your area. Follow manifestos, ask questions and hold leaders accountable.',
  keywords:    ['Kenya elections', '2027', 'candidates', 'voters', 'civic'],
  openGraph: {
    title:       'Baraza — Kenya Civic Platform',
    description: 'Kenya\'s democratic voice — connecting candidates and voters.',
    type:        'website',
  },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`${inter.variable} font-sans bg-baraza-white text-baraza-black antialiased`}>
        <Providers>
          {children}
          <Toaster richColors position="top-center" />
        </Providers>
      </body>
    </html>
  )
}
