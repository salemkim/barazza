'use client'

import { useState }    from 'react'
import Link            from 'next/link'
import { useRouter }   from 'next/navigation'
import { toast }       from 'sonner'
import { normalisePhone } from '@/lib/utils'
import OTPInput        from '@/components/auth/OTPInput'
import { useAuth }     from '@/hooks/useAuth'

export default function LoginPage() {
  const router     = useRouter()
  const { refetch } = useAuth()
  const [step,     setStep]     = useState<'phone' | 'otp'>('phone')
  const [phone,    setPhone]    = useState('')
  const [otp,      setOtp]      = useState('')
  const [loading,  setLoading]  = useState(false)
  const [countdown, setCountdown] = useState(0)

  const sendOTP = async () => {
    const normalised = normalisePhone(phone)
    setLoading(true)
    const res  = await fetch('/api/auth/send-otp', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body:   JSON.stringify({ phone: normalised }),
    })
    const json = await res.json()
    setLoading(false)
    if (json.success) {
      setStep('otp')
      toast.success('OTP sent to your phone')
      // Countdown 60s
      let t = 60
      setCountdown(t)
      const interval = setInterval(() => { t--; setCountdown(t); if (t <= 0) clearInterval(interval) }, 1000)
    } else {
      toast.error(json.error)
    }
  }

  const verifyOTP = async () => {
    setLoading(true)
    const res  = await fetch('/api/auth/login', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body:   JSON.stringify({ phone: normalisePhone(phone), otp }),
    })
    const json = await res.json()
    setLoading(false)
    if (json.success) {
      await refetch()
      const role = json.data?.role
      if (role === 'admin')     router.push('/admin/dashboard')
      else if (role === 'candidate') router.push('/candidate/dashboard')
      else                      router.push('/voter/feed')
    } else {
      toast.error(json.error)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-baraza-green to-baraza-green-light flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-sm">
        {/* Logo */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-white tracking-tight">Baraza</h1>
          <p className="text-green-100 text-sm mt-1">Kenya's Democratic Voice</p>
        </div>

        <div className="bg-white rounded-2xl shadow-xl p-6">
          {step === 'phone' ? (
            <>
              <h2 className="text-lg font-semibold mb-1">Sign in</h2>
              <p className="text-sm text-gray-500 mb-5">Enter your Kenyan phone number</p>

              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">Phone number</label>
                <input
                  type="tel" value={phone} onChange={e => setPhone(e.target.value)}
                  placeholder="0712 345 678"
                  className="baraza-input"
                  onKeyDown={e => e.key === 'Enter' && sendOTP()}
                />
              </div>

              <button onClick={sendOTP} disabled={loading || phone.length < 9} className="baraza-btn-primary w-full">
                {loading ? 'Sending…' : 'Send OTP'}
              </button>

              <p className="text-center text-sm text-gray-500 mt-4">
                No account?{' '}
                <Link href="/register/voter" className="text-baraza-green font-semibold hover:underline">Register as Voter</Link>
                {' or '}
                <Link href="/register/candidate" className="text-baraza-green font-semibold hover:underline">Run for Office</Link>
              </p>
            </>
          ) : (
            <>
              <h2 className="text-lg font-semibold mb-1">Enter OTP</h2>
              <p className="text-sm text-gray-500 mb-5">
                We sent a 6-digit code to <strong>{normalisePhone(phone)}</strong>
              </p>

              <div className="mb-6">
                <OTPInput value={otp} onChange={setOtp} />
              </div>

              <button onClick={verifyOTP} disabled={loading || otp.length < 6} className="baraza-btn-primary w-full mb-3">
                {loading ? 'Verifying…' : 'Verify & Sign In'}
              </button>

              <button onClick={() => { setStep('phone'); setOtp('') }}
                className="w-full text-sm text-gray-400 hover:text-gray-600 transition-colors"
              >
                ← Change number
              </button>

              {countdown > 0 ? (
                <p className="text-center text-xs text-gray-400 mt-3">Resend in {countdown}s</p>
              ) : (
                <button onClick={sendOTP} className="w-full text-center text-sm text-baraza-green hover:underline mt-3">
                  Resend OTP
                </button>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  )
}
