'use client'

import { useState }    from 'react'
import Link            from 'next/link'
import { useRouter }   from 'next/navigation'
import { toast }       from 'sonner'
import { normalisePhone } from '@/lib/utils'
import OTPInput        from '@/components/auth/OTPInput'
import LocationSelector from '@/components/auth/LocationSelector'
import { useAuth }     from '@/hooks/useAuth'

type Step = 'phone' | 'otp' | 'details'

export default function RegisterVoterPage() {
  const router      = useRouter()
  const { refetch } = useAuth()
  const [step,      setStep]     = useState<Step>('phone')
  const [phone,     setPhone]    = useState('')
  const [otp,       setOtp]      = useState('')
  const [username,  setUsername] = useState('')
  const [location,  setLocation] = useState<{ countyId: number | null; constituencyId: number | null; wardId: number | null }>({ countyId: null, constituencyId: null, wardId: null })
  const [loading,   setLoading]  = useState(false)

  const sendOTP = async () => {
    setLoading(true)
    const res  = await fetch('/api/auth/send-otp', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body:   JSON.stringify({ phone: normalisePhone(phone) }),
    })
    const json = await res.json()
    setLoading(false)
    if (json.success) { setStep('otp'); toast.success('OTP sent!') }
    else toast.error(json.error)
  }

  const verifyOTP = async () => {
    setLoading(true)
    // For registration we just move to details after OTP is shown valid
    // The actual OTP verification happens at registration submit
    setLoading(false)
    setStep('details')
  }

  const register = async () => {
    if (!location.countyId || !location.constituencyId) { toast.error('Please select county and constituency'); return }
    setLoading(true)
    const res  = await fetch('/api/auth/register-voter', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body:   JSON.stringify({
        phone:          normalisePhone(phone),
        otp,
        username:       username.trim(),
        countyId:       location.countyId,
        constituencyId: location.constituencyId,
        wardId:         location.wardId ?? undefined,
      }),
    })
    const json = await res.json()
    setLoading(false)
    if (json.success) {
      toast.success('Welcome to Baraza!')
      await refetch()
      router.push('/voter/feed')
    } else {
      toast.error(json.error)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-baraza-green to-baraza-green-light flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-sm">
        <div className="text-center mb-6">
          <h1 className="text-3xl font-bold text-white">Baraza</h1>
          <p className="text-green-100 text-sm mt-1">Register as a Voter</p>
        </div>

        <div className="bg-white rounded-2xl shadow-xl p-6">

          {/* Progress */}
          <div className="flex gap-2 mb-5">
            {(['phone', 'otp', 'details'] as Step[]).map((s, i) => (
              <div key={s} className={`h-1 flex-1 rounded-full transition-colors ${
                step === s || (['otp','details'].includes(step) && i === 0) || (step === 'details' && i === 1)
                  ? 'bg-baraza-green' : 'bg-gray-200'
              }`} />
            ))}
          </div>

          {step === 'phone' && (
            <>
              <h2 className="font-semibold mb-4">Phone number</h2>
              <input type="tel" value={phone} onChange={e => setPhone(e.target.value)}
                placeholder="0712 345 678" className="baraza-input mb-4"
                onKeyDown={e => e.key === 'Enter' && sendOTP()}
              />
              <button onClick={sendOTP} disabled={loading || phone.length < 9} className="baraza-btn-primary w-full">
                {loading ? 'Sending…' : 'Send OTP'}
              </button>
            </>
          )}

          {step === 'otp' && (
            <>
              <h2 className="font-semibold mb-1">Verify phone</h2>
              <p className="text-sm text-gray-500 mb-5">Code sent to {normalisePhone(phone)}</p>
              <OTPInput value={otp} onChange={setOtp} />
              <button onClick={verifyOTP} disabled={otp.length < 6} className="baraza-btn-primary w-full mt-5">
                Continue
              </button>
            </>
          )}

          {step === 'details' && (
            <>
              <h2 className="font-semibold mb-4">Your details</h2>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Username</label>
                  <input value={username} onChange={e => setUsername(e.target.value)}
                    placeholder="e.g. nairobi_voter" className="baraza-input"
                  />
                  <p className="text-xs text-gray-400 mt-1">Can be anonymous. Letters, numbers and _ only.</p>
                </div>
                <LocationSelector onChange={setLocation} />
              </div>
              <button onClick={register} disabled={loading || !username.trim()} className="baraza-btn-primary w-full mt-5">
                {loading ? 'Creating account…' : 'Create Account'}
              </button>
            </>
          )}

          <p className="text-center text-sm text-gray-500 mt-4">
            Already have an account?{' '}
            <Link href="/login" className="text-baraza-green font-semibold hover:underline">Sign in</Link>
          </p>
        </div>
      </div>
    </div>
  )
}
