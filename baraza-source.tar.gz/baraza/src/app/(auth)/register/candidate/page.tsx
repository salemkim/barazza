'use client'

import { useState, useRef }   from 'react'
import Link                    from 'next/link'
import { useRouter }           from 'next/navigation'
import { toast }               from 'sonner'
import { Upload, X }           from 'lucide-react'
import { normalisePhone }      from '@/lib/utils'
import OTPInput                from '@/components/auth/OTPInput'
import LocationSelector        from '@/components/auth/LocationSelector'
import { useAuth }             from '@/hooks/useAuth'

type Step = 'phone' | 'otp' | 'personal' | 'seat' | 'document'

const SEAT_TYPES = [
  { value: 'president', label: 'President', needsCounty: false, needsConst: false, needsWard: false },
  { value: 'governor',  label: 'Governor',  needsCounty: true,  needsConst: false, needsWard: false },
  { value: 'senator',   label: 'Senator',   needsCounty: true,  needsConst: false, needsWard: false },
  { value: 'women_rep', label: 'Women Representative', needsCounty: true, needsConst: false, needsWard: false },
  { value: 'mp',        label: 'Member of Parliament', needsCounty: true, needsConst: true, needsWard: false },
  { value: 'mca',       label: 'MCA',       needsCounty: true,  needsConst: true,  needsWard: true  },
]

const PARTIES = ['Jubilee','UDA','ODM','Wiper','ANC','Ford Kenya','DAP-K','Independent','Other']

export default function RegisterCandidatePage() {
  const router      = useRouter()
  const { refetch } = useAuth()
  const fileRef     = useRef<HTMLInputElement>(null)
  const [step,      setStep]    = useState<Step>('phone')
  const [loading,   setLoading] = useState(false)

  const [phone,     setPhone]    = useState('')
  const [otp,       setOtp]      = useState('')
  const [fullName,  setFullName] = useState('')
  const [username,  setUsername] = useState('')
  const [email,     setEmail]    = useState('')
  const [party,     setParty]    = useState('')
  const [bio,       setBio]      = useState('')
  const [seatType,  setSeatType] = useState('')
  const [location,  setLocation] = useState<{ countyId: number | null; constituencyId: number | null; wardId: number | null }>({ countyId: null, constituencyId: null, wardId: null })
  const [doc,       setDoc]      = useState<File | null>(null)

  const selectedSeat = SEAT_TYPES.find(s => s.value === seatType)

  const sendOTP = async () => {
    setLoading(true)
    const res  = await fetch('/api/auth/send-otp', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body:   JSON.stringify({ phone: normalisePhone(phone) }),
    })
    const json = await res.json()
    setLoading(false)
    if (json.success) { setStep('otp'); toast.success('OTP sent!') }
    else toast.error(json.error)
  }

  const submit = async () => {
    if (!doc) { toast.error('IEBC document required'); return }
    setLoading(true)

    const fd = new FormData()
    fd.append('phone',             normalisePhone(phone))
    fd.append('otp',               otp)
    fd.append('fullName',          fullName)
    fd.append('username',          username)
    fd.append('email',             email)
    fd.append('party',             party)
    fd.append('bio',               bio)
    fd.append('seatType',          seatType)
    fd.append('verificationDoc',   doc)
    if (location.countyId)       fd.append('countyId',       String(location.countyId))
    if (location.constituencyId) fd.append('constituencyId', String(location.constituencyId))
    if (location.wardId)         fd.append('wardId',          String(location.wardId))

    const res  = await fetch('/api/auth/register-candidate', { method: 'POST', body: fd })
    const json = await res.json()
    setLoading(false)

    if (json.success) {
      toast.success('Application submitted! We\'ll review and SMS you within 24 hours.')
      await refetch()
      router.push('/candidate/dashboard')
    } else {
      toast.error(json.error)
    }
  }

  const STEPS: Step[] = ['phone','otp','personal','seat','document']
  const stepIdx = STEPS.indexOf(step)

  return (
    <div className="min-h-screen bg-gradient-to-b from-baraza-black to-gray-900 flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-sm">
        <div className="text-center mb-6">
          <h1 className="text-3xl font-bold text-baraza-green-light">Baraza</h1>
          <p className="text-gray-400 text-sm mt-1">Run for Office</p>
        </div>

        <div className="bg-white rounded-2xl shadow-xl p-6">
          {/* Progress */}
          <div className="flex gap-1 mb-5">
            {STEPS.map((s, i) => (
              <div key={s} className={`h-1 flex-1 rounded-full ${i <= stepIdx ? 'bg-baraza-green' : 'bg-gray-200'}`} />
            ))}
          </div>

          {step === 'phone' && (
            <>
              <h2 className="font-semibold mb-4">Your phone number</h2>
              <input type="tel" value={phone} onChange={e => setPhone(e.target.value)}
                placeholder="0712 345 678" className="baraza-input mb-4"
              />
              <button onClick={sendOTP} disabled={loading || phone.length < 9} className="baraza-btn-primary w-full">
                {loading ? 'Sending…' : 'Send OTP'}
              </button>
            </>
          )}

          {step === 'otp' && (
            <>
              <h2 className="font-semibold mb-4">Verify phone</h2>
              <OTPInput value={otp} onChange={setOtp} />
              <button onClick={() => setStep('personal')} disabled={otp.length < 6} className="baraza-btn-primary w-full mt-5">
                Continue
              </button>
            </>
          )}

          {step === 'personal' && (
            <>
              <h2 className="font-semibold mb-4">Personal details</h2>
              <div className="space-y-3">
                <input value={fullName} onChange={e => setFullName(e.target.value)} placeholder="Full legal name" className="baraza-input" />
                <input value={username} onChange={e => setUsername(e.target.value)} placeholder="Username (can be your name)" className="baraza-input" />
                <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="Email (optional)" className="baraza-input" />
                <select value={party} onChange={e => setParty(e.target.value)} className="baraza-input">
                  <option value="">Select party</option>
                  {PARTIES.map(p => <option key={p} value={p}>{p}</option>)}
                </select>
                <textarea value={bio} onChange={e => setBio(e.target.value)} placeholder="Short bio (optional)" rows={3} className="baraza-input resize-none" />
              </div>
              <button onClick={() => setStep('seat')} disabled={!fullName || !username || !party}
                className="baraza-btn-primary w-full mt-4">Continue</button>
            </>
          )}

          {step === 'seat' && (
            <>
              <h2 className="font-semibold mb-4">Seat & Location</h2>
              <div className="space-y-3">
                <select value={seatType} onChange={e => setSeatType(e.target.value)} className="baraza-input">
                  <option value="">Select position</option>
                  {SEAT_TYPES.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
                </select>
                {seatType && selectedSeat && (
                  <LocationSelector
                    onChange={setLocation}
                    required={selectedSeat.needsCounty}
                    showWard={selectedSeat.needsWard}
                  />
                )}
              </div>
              <button onClick={() => setStep('document')}
                disabled={!seatType || (selectedSeat?.needsCounty && !location.countyId) || (selectedSeat?.needsConst && !location.constituencyId)}
                className="baraza-btn-primary w-full mt-4">Continue</button>
            </>
          )}

          {step === 'document' && (
            <>
              <h2 className="font-semibold mb-1">IEBC Document</h2>
              <p className="text-xs text-gray-500 mb-4">Upload your nomination certificate or IEBC clearance. JPG, PNG or PDF, max 10MB.</p>

              <input ref={fileRef} type="file" accept=".jpg,.jpeg,.png,.pdf" className="hidden"
                onChange={e => setDoc(e.target.files?.[0] ?? null)} />

              {doc ? (
                <div className="flex items-center justify-between p-3 border border-baraza-green bg-baraza-green-muted rounded-xl mb-4">
                  <span className="text-sm font-medium text-baraza-green truncate">{doc.name}</span>
                  <button onClick={() => setDoc(null)} className="text-gray-400 hover:text-baraza-red ml-2 flex-shrink-0"><X size={16} /></button>
                </div>
              ) : (
                <button onClick={() => fileRef.current?.click()}
                  className="w-full border-2 border-dashed border-gray-300 rounded-xl p-8 flex flex-col items-center gap-2 text-gray-500 hover:border-baraza-green hover:text-baraza-green transition-colors mb-4"
                >
                  <Upload size={24} />
                  <span className="text-sm font-medium">Upload document</span>
                </button>
              )}

              <button onClick={submit} disabled={loading || !doc} className="baraza-btn-primary w-full">
                {loading ? 'Submitting…' : 'Submit Application'}
              </button>
            </>
          )}

          <p className="text-center text-sm text-gray-500 mt-4">
            Already registered?{' '}
            <Link href="/login" className="text-baraza-green font-semibold hover:underline">Sign in</Link>
          </p>
        </div>
      </div>
    </div>
  )
}
