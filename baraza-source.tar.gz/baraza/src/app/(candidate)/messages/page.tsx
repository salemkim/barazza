'use client'

import { useEffect, useState } from 'react'
import { toast }               from 'sonner'
import { Send }                from 'lucide-react'
import { timeAgo }             from '@/lib/utils'
import { useAuthStore }        from '@/store/auth-store'

interface Convo { partner_id: string; username: string; full_name: string | null; last_message: string; last_message_at: string; unread_count: number }
interface Message { id: string; senderId: string; text: string; isRead: boolean; createdAt: string }

export default function CandidateMessagesPage() {
  const { user }     = useAuthStore()
  const [convos,     setConvos]      = useState<Convo[]>([])
  const [active,     setActive]      = useState<string | null>(null)
  const [thread,     setThread]      = useState<Message[]>([])
  const [text,       setText]        = useState('')
  const [loading,    setLoading]     = useState(true)
  const [sending,    setSending]     = useState(false)
  const [loadingThread, setLoadingThread] = useState(false)

  useEffect(() => {
    fetch('/api/messages').then(r => r.json()).then(j => { setConvos(j.data ?? []); setLoading(false) })
  }, [])

  const openThread = async (partnerId: string) => {
    setActive(partnerId)
    setLoadingThread(true)
    const res  = await fetch(`/api/messages?withUserId=${partnerId}`)
    const json = await res.json()
    setThread(json.data ?? [])
    setLoadingThread(false)
    setConvos(c => c.map(x => x.partner_id === partnerId ? { ...x, unread_count: 0 } : x))
  }

  const send = async () => {
    if (!text.trim() || !active) return
    setSending(true)
    const res  = await fetch('/api/messages', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body:   JSON.stringify({ receiverId: active, text: text.trim() }),
    })
    const json = await res.json()
    if (json.success) { setThread(t => [...t, json.data]); setText('') }
    else toast.error(json.error)
    setSending(false)
  }

  const canMessage = user?.subscriptionTier === 'gold' || user?.subscriptionTier === 'platinum'

  if (!canMessage) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="text-center max-w-sm">
          <div className="text-4xl mb-4">💬</div>
          <h2 className="text-xl font-bold mb-2">Messaging requires Gold or Platinum</h2>
          <p className="text-sm text-gray-500 mb-4">Upgrade your subscription to receive and reply to voter messages directly.</p>
          <a href="/candidate/subscription" className="baraza-btn-primary inline-block">Upgrade Now</a>
        </div>
      </div>
    )
  }

  return (
    <div className="h-[calc(100vh-8rem)] flex gap-4">
      {/* Conversation list */}
      <div className="w-72 baraza-card overflow-y-auto flex-shrink-0">
        <div className="p-3 border-b border-gray-100">
          <h2 className="font-semibold text-sm">Messages from voters</h2>
        </div>
        {loading && <div className="p-4 text-xs text-gray-400">Loading…</div>}
        {!loading && convos.length === 0 && (
          <div className="p-4 text-xs text-gray-400 text-center">No messages yet. Voters can message you from your posts.</div>
        )}
        {convos.map(c => (
          <button key={c.partner_id} onClick={() => openThread(c.partner_id)}
            className={`w-full text-left flex gap-3 p-3 hover:bg-gray-50 transition-colors border-b border-gray-50 ${active === c.partner_id ? 'bg-baraza-green-muted' : ''}`}
          >
            <div className="w-8 h-8 rounded-full bg-baraza-green flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
              {(c.full_name ?? c.username)[0].toUpperCase()}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <p className={`text-xs ${c.unread_count > 0 ? 'font-bold' : 'font-medium'} truncate`}>{c.full_name ?? c.username}</p>
                {c.unread_count > 0 && <span className="w-4 h-4 bg-baraza-green text-white text-[9px] rounded-full flex items-center justify-center flex-shrink-0">{c.unread_count}</span>}
              </div>
              <p className="text-[11px] text-gray-500 truncate">{c.last_message}</p>
            </div>
          </button>
        ))}
      </div>

      {/* Thread */}
      <div className="flex-1 baraza-card flex flex-col overflow-hidden">
        {!active ? (
          <div className="flex-1 flex items-center justify-center text-gray-400">
            <div className="text-center">
              <div className="text-3xl mb-2">💬</div>
              <p className="text-sm">Select a conversation</p>
            </div>
          </div>
        ) : (
          <>
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {loadingThread && <p className="text-xs text-gray-400">Loading…</p>}
              {thread.map(msg => {
                const mine = msg.senderId === user?.id
                return (
                  <div key={msg.id} className={`flex ${mine ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[70%] rounded-2xl px-4 py-2.5 text-sm ${mine ? 'bg-baraza-green text-white rounded-br-sm' : 'bg-gray-100 text-gray-800 rounded-bl-sm'}`}>
                      <p>{msg.text}</p>
                      <p className={`text-[10px] mt-0.5 ${mine ? 'text-green-200' : 'text-gray-400'}`}>{timeAgo(msg.createdAt)}</p>
                    </div>
                  </div>
                )
              })}
            </div>
            <div className="flex gap-2 p-3 border-t border-gray-100">
              <input value={text} onChange={e => setText(e.target.value)} placeholder="Reply to voter…"
                className="baraza-input flex-1 text-sm" onKeyDown={e => e.key === 'Enter' && send()} />
              <button onClick={send} disabled={sending || !text.trim()} className="baraza-btn-primary px-3">
                <Send size={15} />
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  )
}
