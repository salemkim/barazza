'use client'

import { useEffect, useState } from 'react'
import { Heart, MessageCircle, FileText, TrendingUp } from 'lucide-react'
import { formatKES } from '@/lib/utils'

interface PostStat {
  id: string; contentText: string; likesCount: number
  commentsCount: number; isBoosted: boolean; createdAt: string
}

interface Analytics {
  totalPosts: number; totalLikes: number; totalComments: number
  avgLikesPerPost: number; topPosts: PostStat[]
  recentPayments: { amount: string; type: string; status: string; createdAt: string }[]
}

export default function AnalyticsPage() {
  const [data,    setData]    = useState<Analytics | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    Promise.all([
      fetch('/api/candidate/stats').then(r => r.json()),
      fetch('/api/candidate/top-posts').then(r => r.json()),
      fetch('/api/payments/history').then(r => r.json()),
    ]).then(([stats, topPosts, payments]) => {
      setData({
        totalPosts:      stats.data?.totalPosts    ?? 0,
        totalLikes:      stats.data?.totalLikes    ?? 0,
        totalComments:   stats.data?.totalComments ?? 0,
        avgLikesPerPost: stats.data?.totalPosts > 0 ? (stats.data.totalLikes / stats.data.totalPosts).toFixed(1) as any : 0,
        topPosts:        topPosts.data ?? [],
        recentPayments:  payments.data?.slice(0, 5) ?? [],
      })
      setLoading(false)
    })
  }, [])

  const stats = [
    { label: 'Total Posts',    value: data?.totalPosts,      icon: FileText,         color: 'text-blue-500'    },
    { label: 'Total Likes',    value: data?.totalLikes,      icon: Heart,            color: 'text-baraza-red'  },
    { label: 'Total Comments', value: data?.totalComments,   icon: MessageCircle,    color: 'text-baraza-green'},
    { label: 'Avg Likes/Post', value: data?.avgLikesPerPost, icon: TrendingUp,       color: 'text-purple-500'  },
  ]

  return (
    <div className="space-y-5">
      <h1 className="text-2xl font-bold">Analytics</h1>

      {/* Summary cards */}
      <div className="grid grid-cols-2 gap-3">
        {stats.map(({ label, value, icon: Icon, color }) => (
          <div key={label} className="baraza-card p-4">
            <div className="flex items-center justify-between mb-2">
              <p className="text-xs text-gray-500">{label}</p>
              <Icon size={15} className={color} />
            </div>
            {loading
              ? <div className="h-7 w-12 bg-gray-200 rounded animate-pulse" />
              : <p className="text-2xl font-bold">{value ?? 0}</p>
            }
          </div>
        ))}
      </div>

      {/* Top posts */}
      <div className="baraza-card p-4">
        <h3 className="font-semibold mb-3">Top Performing Posts</h3>
        {loading ? (
          <div className="space-y-2">
            {[1,2,3].map(i => <div key={i} className="h-12 bg-gray-100 rounded-lg animate-pulse" />)}
          </div>
        ) : data?.topPosts.length === 0 ? (
          <p className="text-sm text-gray-400">No posts yet</p>
        ) : (
          <div className="space-y-2">
            {data?.topPosts.map((post, i) => (
              <div key={post.id} className="flex items-start gap-3 p-2.5 rounded-lg hover:bg-gray-50">
                <span className="text-lg font-bold text-gray-200 w-6 flex-shrink-0">#{i + 1}</span>
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-gray-800 line-clamp-1">{post.contentText}</p>
                  <div className="flex items-center gap-3 mt-0.5 text-xs text-gray-400">
                    <span className="flex items-center gap-0.5"><Heart size={10} />{post.likesCount}</span>
                    <span className="flex items-center gap-0.5"><MessageCircle size={10} />{post.commentsCount}</span>
                    {post.isBoosted && <span className="text-baraza-gold font-semibold">⚡ Boosted</span>}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Payment history */}
      <div className="baraza-card p-4">
        <h3 className="font-semibold mb-3">Recent Payments</h3>
        {loading ? (
          <div className="space-y-2">
            {[1,2].map(i => <div key={i} className="h-10 bg-gray-100 rounded-lg animate-pulse" />)}
          </div>
        ) : data?.recentPayments.length === 0 ? (
          <p className="text-sm text-gray-400">No payments yet</p>
        ) : (
          <div className="divide-y divide-gray-50">
            {data?.recentPayments.map((p, i) => (
              <div key={i} className="flex items-center justify-between py-2.5">
                <div>
                  <p className="text-sm font-medium capitalize">{p.type}</p>
                  <p className="text-xs text-gray-400">{new Date(p.createdAt).toLocaleDateString()}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-semibold">{formatKES(Number(p.amount))}</p>
                  <span className={`text-xs ${p.status === 'completed' ? 'text-green-600' : p.status === 'failed' ? 'text-baraza-red' : 'text-amber-600'}`}>
                    {p.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
