'use client'

import { useState, useRef }   from 'react'
import { useRouter }           from 'next/navigation'
import { toast }               from 'sonner'
import { Image as ImageIcon, BarChart2, X, Plus } from 'lucide-react'
import { useAuthStore }        from '@/store/auth-store'

export default function NewPostPage() {
  const router         = useRouter()
  const { user }       = useAuthStore()
  const fileRef        = useRef<HTMLInputElement>(null)
  const [text,         setText]        = useState('')
  const [image,        setImage]       = useState<File | null>(null)
  const [imagePreview, setImagePreview]= useState<string | null>(null)
  const [hasPoll,      setHasPoll]     = useState(false)
  const [pollQuestion, setPollQuestion]= useState('')
  const [pollOptions,  setPollOptions] = useState(['', ''])
  const [pollDays,     setPollDays]    = useState(3)
  const [submitting,   setSubmitting]  = useState(false)

  const addOption    = () => setPollOptions(o => [...o, ''])
  const removeOption = (i: number) => setPollOptions(o => o.filter((_, idx) => idx !== i))
  const updateOption = (i: number, val: string) => setPollOptions(o => o.map((v, idx) => idx === i ? val : v))

  const handleImage = (file: File) => {
    setImage(file)
    const reader = new FileReader()
    reader.onload = e => setImagePreview(e.target?.result as string)
    reader.readAsDataURL(file)
  }

  const submit = async () => {
    if (!text.trim()) { toast.error('Post content is required'); return }
    if (hasPoll && !pollQuestion.trim()) { toast.error('Poll question is required'); return }
    if (hasPoll && pollOptions.filter(o => o.trim()).length < 2) { toast.error('At least 2 poll options required'); return }

    setSubmitting(true)
    const fd = new FormData()
    fd.append('contentText', text.trim())
    if (image)   fd.append('image', image)
    if (hasPoll) {
      fd.append('hasPoll',      'true')
      fd.append('pollQuestion', pollQuestion.trim())
      fd.append('pollOptions',  JSON.stringify(pollOptions.filter(o => o.trim())))
      fd.append('pollDuration', String(pollDays))
    }

    const res  = await fetch('/api/posts', { method: 'POST', body: fd })
    const json = await res.json()
    setSubmitting(false)

    if (json.success) {
      toast.success('Post published!')
      router.push('/candidate/posts')
    } else {
      toast.error(json.error)
    }
  }

  const isFree   = user?.subscriptionTier === 'free'
  const charLeft = 2000 - text.length

  return (
    <div className="max-w-2xl mx-auto space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold">New Post</h1>
        {isFree && (
          <span className="text-xs text-amber-600 bg-amber-50 border border-amber-200 px-2.5 py-1 rounded-full font-medium">
            Free tier: 3 posts/week
          </span>
        )}
      </div>

      <div className="baraza-card p-4 space-y-4">
        {/* Text area */}
        <div>
          <textarea
            value={text} onChange={e => setText(e.target.value)}
            placeholder="Share your manifesto, policy ideas or updates with voters in your area…"
            rows={6}
            className="baraza-input resize-none text-sm"
            maxLength={2000}
          />
          <p className={`text-xs mt-1 text-right ${charLeft < 100 ? 'text-baraza-red' : 'text-gray-400'}`}>
            {charLeft} characters remaining
          </p>
        </div>

        {/* Image preview */}
        {imagePreview && (
          <div className="relative rounded-xl overflow-hidden aspect-video bg-gray-100">
            <img src={imagePreview} alt="Preview" className="w-full h-full object-cover" />
            <button onClick={() => { setImage(null); setImagePreview(null) }}
              className="absolute top-2 right-2 w-7 h-7 bg-black/50 text-white rounded-full flex items-center justify-center hover:bg-black/70"
            >
              <X size={14} />
            </button>
          </div>
        )}

        {/* Poll builder */}
        {hasPoll && (
          <div className="border border-baraza-green/30 bg-baraza-green-muted rounded-xl p-3 space-y-3">
            <div className="flex items-center justify-between">
              <p className="text-sm font-semibold text-baraza-green">Poll</p>
              <button onClick={() => setHasPoll(false)} className="text-gray-400 hover:text-baraza-red">
                <X size={16} />
              </button>
            </div>
            <input value={pollQuestion} onChange={e => setPollQuestion(e.target.value)}
              placeholder="Ask voters a question…" className="baraza-input text-sm" />
            {pollOptions.map((opt, i) => (
              <div key={i} className="flex gap-2">
                <input value={opt} onChange={e => updateOption(i, e.target.value)}
                  placeholder={`Option ${i + 1}`} className="baraza-input text-sm flex-1" />
                {pollOptions.length > 2 && (
                  <button onClick={() => removeOption(i)} className="text-gray-400 hover:text-baraza-red flex-shrink-0">
                    <X size={16} />
                  </button>
                )}
              </div>
            ))}
            {pollOptions.length < 6 && (
              <button onClick={addOption} className="flex items-center gap-1.5 text-sm text-baraza-green hover:underline">
                <Plus size={14} /> Add option
              </button>
            )}
            <div className="flex items-center gap-2">
              <label className="text-xs text-gray-600">Duration:</label>
              <select value={pollDays} onChange={e => setPollDays(Number(e.target.value))}
                className="text-xs border border-gray-200 rounded px-2 py-1">
                {[1,2,3,5,7].map(d => <option key={d} value={d}>{d} day{d > 1 ? 's' : ''}</option>)}
              </select>
            </div>
          </div>
        )}

        {/* Action bar */}
        <div className="flex items-center justify-between pt-1">
          <div className="flex gap-3">
            <button onClick={() => fileRef.current?.click()}
              className="flex items-center gap-1.5 text-sm text-gray-500 hover:text-baraza-green transition-colors"
            >
              <ImageIcon size={18} /> Photo
            </button>
            <button onClick={() => setHasPoll(v => !v)}
              className={`flex items-center gap-1.5 text-sm transition-colors ${hasPoll ? 'text-baraza-green' : 'text-gray-500 hover:text-baraza-green'}`}
            >
              <BarChart2 size={18} /> Poll
            </button>
            <input ref={fileRef} type="file" accept="image/*" className="hidden"
              onChange={e => e.target.files?.[0] && handleImage(e.target.files[0])} />
          </div>

          <button onClick={submit} disabled={submitting || !text.trim()}
            className="baraza-btn-primary px-6 py-2 text-sm"
          >
            {submitting ? 'Publishing…' : 'Publish'}
          </button>
        </div>
      </div>
    </div>
  )
}
