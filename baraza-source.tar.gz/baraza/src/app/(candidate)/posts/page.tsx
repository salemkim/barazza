'use client'

import { useEffect, useState } from 'react'
import Link                    from 'next/link'
import { toast }               from 'sonner'
import { Plus, Trash2, Zap, Heart, MessageCircle } from 'lucide-react'
import { timeAgo, formatKES }  from '@/lib/utils'
import { useAuthStore }        from '@/store/auth-store'

interface Post {
  id: string; contentText: string; imageUrl: string | null
  isBoosted: boolean; boostExpiresAt: string | null
  likesCount: number; commentsCount: number; createdAt: string; isDeleted: boolean
}

export default function CandidatePostsPage() {
  const { user }    = useAuthStore()
  const [posts,     setPosts]    = useState<Post[]>([])
  const [loading,   setLoading]  = useState(true)
  const [boosting,  setBoosting] = useState<string | null>(null)
  const [deleting,  setDeleting] = useState<string | null>(null)

  useEffect(() => {
    fetch(`/api/posts?authorId=${user?.id}`)
      .then(r => r.json())
      .then(j => { setPosts(j.data?.posts ?? []); setLoading(false) })
  }, [user?.id])

  const deletePost = async (id: string) => {
    if (!confirm('Delete this post?')) return
    setDeleting(id)
    const res  = await fetch(`/api/posts/${id}`, { method: 'DELETE' })
    const json = await res.json()
    if (json.success) { setPosts(p => p.filter(x => x.id !== id)); toast.success('Post deleted') }
    else toast.error(json.error)
    setDeleting(null)
  }

  const boostPost = async (id: string) => {
    setBoosting(id)
    const res  = await fetch('/api/posts/boost', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body:   JSON.stringify({ postId: id, phone: user?.phone }),
    })
    const json = await res.json()
    setBoosting(null)
    if (json.success) toast.success(json.message)
    else toast.error(json.error)
  }

  const canBoost = user?.subscriptionTier === 'gold' || user?.subscriptionTier === 'platinum'

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">My Posts</h1>
          {user?.subscriptionTier === 'free' && (
            <p className="text-xs text-amber-600 mt-0.5">Free tier: 3 posts/week ·
              <Link href="/candidate/subscription" className="underline ml-1">Upgrade for unlimited</Link>
            </p>
          )}
        </div>
        <Link href="/candidate/posts/new" className="baraza-btn-primary flex items-center gap-1.5 text-sm px-4 py-2">
          <Plus size={16} /> New Post
        </Link>
      </div>

      {loading && (
        <div className="space-y-3">
          {[1,2,3].map(i => (
            <div key={i} className="baraza-card p-4 animate-pulse">
              <div className="h-3 bg-gray-200 rounded w-3/4 mb-2" />
              <div className="h-3 bg-gray-100 rounded w-1/2" />
            </div>
          ))}
        </div>
      )}

      {!loading && posts.length === 0 && (
        <div className="text-center py-16 text-gray-400">
          <p className="font-semibold">No posts yet</p>
          <p className="text-sm mt-1">Share your manifesto with voters</p>
          <Link href="/candidate/posts/new" className="baraza-btn-primary inline-block mt-4 text-sm px-6">
            Write your first post
          </Link>
        </div>
      )}

      <div className="space-y-3">
        {posts.map(post => (
          <div key={post.id} className="baraza-card p-4">
            {post.isBoosted && (
              <div className="flex items-center gap-1 text-xs text-baraza-gold font-semibold mb-2">
                <Zap size={11} fill="currentColor" />
                Boosted{post.boostExpiresAt ? ` until ${new Date(post.boostExpiresAt).toLocaleTimeString()}` : ''}
              </div>
            )}

            <p className="text-sm text-gray-800 line-clamp-3 mb-3">{post.contentText}</p>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4 text-xs text-gray-400">
                <span className="flex items-center gap-1"><Heart size={12} />{post.likesCount}</span>
                <span className="flex items-center gap-1"><MessageCircle size={12} />{post.commentsCount}</span>
                <span>{timeAgo(post.createdAt)}</span>
              </div>

              <div className="flex items-center gap-2">
                {canBoost && !post.isBoosted && (
                  <button onClick={() => boostPost(post.id)} disabled={boosting === post.id}
                    className="flex items-center gap-1 text-xs font-medium text-baraza-gold border border-baraza-gold/30 px-2.5 py-1 rounded-lg hover:bg-yellow-50 transition-colors"
                  >
                    <Zap size={12} fill="currentColor" />
                    {boosting === post.id ? 'Boosting…' : 'Boost'}
                  </button>
                )}
                <button onClick={() => deletePost(post.id)} disabled={deleting === post.id}
                  className="text-gray-300 hover:text-baraza-red transition-colors p-1.5 rounded-lg hover:bg-red-50"
                >
                  <Trash2 size={15} />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
