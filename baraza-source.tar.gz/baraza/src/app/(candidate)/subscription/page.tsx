'use client'

import { useState }    from 'react'
import { toast }       from 'sonner'
import { Check, Zap }  from 'lucide-react'
import { useAuthStore } from '@/store/auth-store'
import { SUBSCRIPTION_PRICES, SEAT_TYPE_LABELS, formatKES } from '@/lib/utils'
import type { SeatType, SubscriptionTier } from '@/types'

const FEATURES: Record<Exclude<SubscriptionTier,'free'>, string[]> = {
  silver:   ['Unlimited posts','Basic analytics','Verified badge'],
  gold:     ['All Silver features','Direct messaging from voters','2 post boosts/month','Detailed analytics'],
  platinum: ['All Gold features','5 post boosts/month','Bulk message voters in area','Priority support'],
}

const TIER_COLORS: Record<string,string> = {
  silver:   'border-gray-300 bg-gray-50',
  gold:     'border-yellow-400 bg-yellow-50',
  platinum: 'border-purple-400 bg-purple-50',
}

const TIER_BADGE: Record<string,string> = {
  silver:   'bg-gray-200 text-gray-700',
  gold:     'bg-yellow-400 text-yellow-900',
  platinum: 'bg-purple-500 text-white',
}

export default function SubscriptionPage() {
  const { user }     = useAuthStore()
  const [phone,      setPhone]      = useState(user?.phone ?? '')
  const [loading,    setLoading]    = useState<string | null>(null)
  const [pollStatus, setPollStatus] = useState<Record<string, string>>({})

  const subscribe = async (tier: Exclude<SubscriptionTier,'free'>) => {
    setLoading(tier)
    const res  = await fetch('/api/payments/subscribe', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body:   JSON.stringify({ tier, phone }),
    })
    const json = await res.json()
    setLoading(null)

    if (json.success) {
      toast.success(json.message ?? 'Check your phone and complete M-Pesa payment')
      // Poll for payment status
      pollPaymentStatus(json.data?.paymentId, tier)
    } else {
      toast.error(json.error)
    }
  }

  const pollPaymentStatus = (paymentId: string, tier: string) => {
    if (!paymentId) return
    setPollStatus(s => ({ ...s, [tier]: 'pending' }))
    let attempts = 0
    const interval = setInterval(async () => {
      attempts++
      const res  = await fetch(`/api/payments/${paymentId}/status`)
      const json = await res.json()
      if (json.data?.status === 'completed') {
        clearInterval(interval)
        setPollStatus(s => ({ ...s, [tier]: 'completed' }))
        toast.success(`${tier} subscription activated! Refresh to see your new features.`)
      } else if (json.data?.status === 'failed' || attempts > 20) {
        clearInterval(interval)
        setPollStatus(s => ({ ...s, [tier]: 'failed' }))
        if (attempts > 20) toast.error('Payment timed out. Please try again.')
      }
    }, 5000)
  }

  // Determine seat type from user's candidate data (simplified)
  const seatType: SeatType = 'mca' // In reality, fetch from candidateSeats

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Subscription Plans</h1>
        <p className="text-sm text-gray-500 mt-1">
          Current plan: <strong className="text-baraza-green capitalize">{user?.subscriptionTier ?? 'Free'}</strong>
          {user?.subscriptionExpiry && ` · Expires ${new Date(user.subscriptionExpiry).toLocaleDateString()}`}
        </p>
      </div>

      {/* Phone for payment */}
      <div className="baraza-card p-4">
        <label className="block text-sm font-medium text-gray-700 mb-1">M-Pesa phone number</label>
        <input value={phone} onChange={e => setPhone(e.target.value)}
          placeholder="0712 345 678" className="baraza-input" />
        <p className="text-xs text-gray-400 mt-1">STK Push will be sent to this number</p>
      </div>

      {/* Plan cards */}
      <div className="space-y-3">
        {(Object.keys(FEATURES) as Exclude<SubscriptionTier,'free'>[]).map(tier => {
          const price      = SUBSCRIPTION_PRICES[seatType]?.[tier] ?? 0
          const isCurrent  = user?.subscriptionTier === tier
          const status     = pollStatus[tier]

          return (
            <div key={tier} className={`baraza-card p-5 border-2 ${TIER_COLORS[tier]}`}>
              <div className="flex items-start justify-between mb-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className={`text-xs font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wide ${TIER_BADGE[tier]}`}>
                      {tier}
                    </span>
                    {isCurrent && <span className="text-xs text-baraza-green font-semibold">✓ Current plan</span>}
                  </div>
                  <p className="text-2xl font-bold mt-1">{formatKES(price)}<span className="text-sm font-normal text-gray-500">/month</span></p>
                </div>
                {!isCurrent && (
                  <button onClick={() => subscribe(tier)} disabled={!!loading || !phone}
                    className={`baraza-btn-primary text-sm px-4 py-2 ${loading === tier ? 'opacity-70' : ''}`}
                  >
                    {loading === tier ? 'Sending…' : status === 'pending' ? <span className="flex items-center gap-1"><Zap size={14} /> Awaiting payment</span> : `Subscribe`}
                  </button>
                )}
              </div>

              <ul className="space-y-1.5">
                {FEATURES[tier].map(f => (
                  <li key={f} className="flex items-center gap-2 text-sm text-gray-700">
                    <Check size={14} className="text-baraza-green flex-shrink-0" />
                    {f}
                  </li>
                ))}
              </ul>

              {status === 'completed' && (
                <div className="mt-3 text-sm text-green-700 bg-green-100 rounded-lg px-3 py-2 font-medium">
                  ✓ Payment confirmed! Your plan has been activated.
                </div>
              )}
              {status === 'failed' && (
                <div className="mt-3 text-sm text-red-700 bg-red-100 rounded-lg px-3 py-2">
                  Payment failed or cancelled. Please try again.
                </div>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}
