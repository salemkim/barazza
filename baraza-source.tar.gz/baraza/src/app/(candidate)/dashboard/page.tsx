'use client'

import { useEffect, useState }  from 'react'
import Link                     from 'next/link'
import { useAuth }              from '@/hooks/useAuth'
import { Eye, Users, Heart, TrendingUp, AlertCircle, CheckCircle, Clock } from 'lucide-react'
import { TIER_LABELS, SEAT_TYPE_LABELS, formatKES } from '@/lib/utils'

interface Stats { totalPosts: number; totalLikes: number; totalComments: number; followerCount: number }

export default function CandidateDashboard() {
  const { user }   = useAuth()
  const [stats,    setStats]    = useState<Stats | null>(null)
  const [payments, setPayments] = useState<any[]>([])
  const [loading,  setLoading]  = useState(true)

  useEffect(() => {
    Promise.all([
      fetch('/api/candidate/stats').then(r => r.json()),
      fetch('/api/payments/history').then(r => r.json()),
    ]).then(([s, p]) => {
      setStats(s.data)
      setPayments(p.data?.slice(0, 3) ?? [])
      setLoading(false)
    })
  }, [])

  const verificationBadge = () => {
    if (!user) return null
    if (user.verificationStatus === 'approved') return (
      <div className="flex items-center gap-2 text-sm text-green-700 bg-green-50 border border-green-200 rounded-xl px-3 py-2">
        <CheckCircle size={16} className="text-green-600" />
        <span className="font-medium">Verified Candidate</span>
      </div>
    )
    if (user.verificationStatus === 'pending') return (
      <div className="flex items-center gap-2 text-sm text-amber-700 bg-amber-50 border border-amber-200 rounded-xl px-3 py-2">
        <Clock size={16} className="text-amber-600" />
        <span className="font-medium">Verification pending — we'll SMS you when approved</span>
      </div>
    )
    return (
      <div className="flex items-center gap-2 text-sm text-red-700 bg-red-50 border border-red-200 rounded-xl px-3 py-2">
        <AlertCircle size={16} className="text-baraza-red" />
        <span className="font-medium">Not yet verified — <Link href="/candidate/subscription" className="underline">complete verification</Link></span>
      </div>
    )
  }

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-bold">Welcome back, {user?.fullName?.split(' ')[0] ?? user?.username}</h1>
        <p className="text-sm text-gray-500 mt-0.5">{user?.party} · {user?.subscriptionTier && TIER_LABELS[user.subscriptionTier]} Plan</p>
      </div>

      {verificationBadge()}

      {/* Stat cards */}
      <div className="grid grid-cols-2 gap-3">
        {[
          { label: 'Posts',    value: stats?.totalPosts    ?? 0, icon: Eye,        color: 'text-blue-500'   },
          { label: 'Likes',    value: stats?.totalLikes    ?? 0, icon: Heart,      color: 'text-baraza-red' },
          { label: 'Comments', value: stats?.totalComments ?? 0, icon: TrendingUp, color: 'text-baraza-green'},
          { label: 'Followers',value: stats?.followerCount ?? 0, icon: Users,      color: 'text-purple-500' },
        ].map(({ label, value, icon: Icon, color }) => (
          <div key={label} className="baraza-card p-4">
            <div className="flex items-center justify-between mb-2">
              <p className="text-xs text-gray-500 font-medium">{label}</p>
              <Icon size={16} className={color} />
            </div>
            {loading
              ? <div className="h-7 w-12 bg-gray-200 rounded animate-pulse" />
              : <p className="text-2xl font-bold">{value.toLocaleString()}</p>
            }
          </div>
        ))}
      </div>

      {/* Quick actions */}
      <div className="baraza-card p-4">
        <h3 className="font-semibold mb-3">Quick Actions</h3>
        <div className="grid grid-cols-2 gap-2">
          <Link href="/candidate/posts/new" className="baraza-btn-primary text-center text-sm py-2.5">New Post</Link>
          <Link href="/candidate/subscription" className="baraza-btn-outline text-center text-sm py-2.5">
            {user?.subscriptionTier === 'free' ? 'Upgrade Plan' : 'Manage Plan'}
          </Link>
          <Link href="/candidate/analytics" className="baraza-btn-outline text-center text-sm py-2.5">Analytics</Link>
          <Link href="/candidate/messages" className="baraza-btn-outline text-center text-sm py-2.5">Messages</Link>
        </div>
      </div>

      {/* Recent payments */}
      {payments.length > 0 && (
        <div className="baraza-card p-4">
          <h3 className="font-semibold mb-3">Recent Payments</h3>
          <div className="space-y-2">
            {payments.map((p: any) => (
              <div key={p.id} className="flex items-center justify-between py-2 border-b last:border-0 border-gray-50">
                <div>
                  <p className="text-sm font-medium capitalize">{p.type} — {p.packageTier ?? 'boost'}</p>
                  <p className="text-xs text-gray-400">{new Date(p.createdAt).toLocaleDateString()}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-semibold">{formatKES(Number(p.amount))}</p>
                  <span className={`text-xs font-medium ${p.status === 'completed' ? 'text-green-600' : p.status === 'failed' ? 'text-baraza-red' : 'text-amber-600'}`}>
                    {p.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
