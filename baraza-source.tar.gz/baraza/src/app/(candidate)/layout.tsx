import Link            from 'next/link'
import { getSession }  from '@/lib/auth/session'
import { redirect }    from 'next/navigation'
import { LayoutDashboard, FileText, BarChart2, MessageCircle, CreditCard, LogOut } from 'lucide-react'

const NAV = [
  { href: '/candidate/dashboard',    icon: LayoutDashboard, label: 'Dashboard'    },
  { href: '/candidate/posts',        icon: FileText,         label: 'Posts'        },
  { href: '/candidate/analytics',    icon: BarChart2,        label: 'Analytics'    },
  { href: '/candidate/messages',     icon: MessageCircle,    label: 'Messages'     },
  { href: '/candidate/subscription', icon: CreditCard,       label: 'Subscription' },
]

export default async function CandidateLayout({ children }: { children: React.ReactNode }) {
  const session = await getSession()
  if (!session || session.role !== 'candidate') redirect('/login')

  return (
    <div className="flex min-h-screen bg-gray-50">
      {/* Sidebar */}
      <aside className="hidden md:flex flex-col w-56 bg-white border-r border-gray-100 p-4 fixed h-full z-20">
        <div className="mb-6 px-2">
          <h1 className="text-xl font-bold text-baraza-green">Baraza</h1>
          <p className="text-xs text-gray-400 mt-0.5">Candidate Portal</p>
        </div>
        <nav className="flex-1 space-y-1">
          {NAV.map(({ href, icon: Icon, label }) => (
            <Link key={href} href={href}
              className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-gray-600 hover:bg-baraza-green-muted hover:text-baraza-green transition-colors"
            >
              <Icon size={18} /> {label}
            </Link>
          ))}
        </nav>
        <form action="/api/auth/session" method="DELETE">
          <Link href="/api/auth/session"
            className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-gray-400 hover:text-baraza-red hover:bg-baraza-red-light transition-colors w-full"
          >
            <LogOut size={18} /> Sign Out
          </Link>
        </form>
      </aside>

      {/* Main */}
      <main className="flex-1 md:ml-56 min-h-screen">
        {/* Mobile top nav */}
        <div className="md:hidden sticky top-0 z-10 bg-white border-b px-4 py-3 flex items-center justify-between">
          <h1 className="font-bold text-baraza-green">Baraza</h1>
          <div className="flex gap-3">
            {NAV.map(({ href, icon: Icon }) => (
              <Link key={href} href={href} className="text-gray-500 hover:text-baraza-green">
                <Icon size={20} />
              </Link>
            ))}
          </div>
        </div>
        <div className="p-4 md:p-6 max-w-4xl mx-auto">
          {children}
        </div>
      </main>
    </div>
  )
}
