'use client'

import { useEffect, useState } from 'react'
import { toast }    from 'sonner'
import { CheckCircle, XCircle, ExternalLink } from 'lucide-react'

interface Candidate {
  id: string; username: string; fullName: string | null
  phone: string; email: string | null; party: string | null
  verificationStatus: string; verificationDocUrl: string | null
  seatType: string | null; seatLabel: string | null; createdAt: string
}

export default function AdminVerificationsPage() {
  const [candidates, setCandidates] = useState<Candidate[]>([])
  const [status,     setStatus]     = useState<'pending'|'approved'|'rejected'>('pending')
  const [loading,    setLoading]    = useState(true)
  const [notes,      setNotes]      = useState<Record<string,string>>({})
  const [acting,     setActing]     = useState<string | null>(null)

  const load = async (s: typeof status) => {
    setLoading(true)
    const res  = await fetch(`/api/admin/candidates?status=${s}`)
    const json = await res.json()
    setCandidates(json.data?.candidates ?? [])
    setLoading(false)
  }

  useEffect(() => { load(status) }, [status])

  const act = async (id: string, action: 'approve' | 'reject') => {
    setActing(id)
    const res  = await fetch('/api/admin/verify-candidate', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body:   JSON.stringify({ candidateId: id, action, notes: notes[id] }),
    })
    const json = await res.json()
    if (json.success) {
      toast.success(`Candidate ${action}d`)
      setCandidates(c => c.filter(x => x.id !== id))
    } else {
      toast.error(json.error)
    }
    setActing(null)
  }

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-bold">Candidate Verifications</h1>
        <div className="flex gap-2 mt-3">
          {(['pending','approved','rejected'] as const).map(s => (
            <button key={s} onClick={() => setStatus(s)}
              className={`px-4 py-1.5 rounded-full text-sm font-medium capitalize transition-colors ${status === s ? 'bg-baraza-green text-white' : 'bg-white border border-gray-200 text-gray-600 hover:border-baraza-green'}`}
            >{s}</button>
          ))}
        </div>
      </div>

      {loading && <div className="text-gray-400 text-sm">Loading…</div>}

      {!loading && candidates.length === 0 && (
        <div className="text-center py-16 text-gray-400">
          <p className="font-semibold">No {status} verifications</p>
        </div>
      )}

      <div className="space-y-4">
        {candidates.map(c => (
          <div key={c.id} className="baraza-card p-5">
            <div className="flex items-start justify-between flex-wrap gap-3">
              <div>
                <div className="flex items-center gap-2">
                  <p className="font-bold">{c.fullName ?? c.username}</p>
                  <span className="text-xs text-gray-500">@{c.username}</span>
                </div>
                <p className="text-sm text-gray-600 mt-0.5">{c.phone} · {c.email ?? 'No email'}</p>
                <p className="text-sm text-gray-600">{c.party ?? 'No party'}</p>
                {c.seatLabel && <p className="text-sm font-medium text-baraza-green mt-1">{c.seatLabel}</p>}
                <p className="text-xs text-gray-400 mt-1">Registered {new Date(c.createdAt).toLocaleDateString()}</p>
              </div>

              {c.verificationDocUrl && (
                <a href={c.verificationDocUrl} target="_blank" rel="noopener noreferrer"
                  className="flex items-center gap-1.5 text-sm text-baraza-green border border-baraza-green px-3 py-1.5 rounded-lg hover:bg-baraza-green-muted transition-colors"
                >
                  <ExternalLink size={14} /> View Document
                </a>
              )}
            </div>

            {status === 'pending' && (
              <div className="mt-4 space-y-2">
                <textarea value={notes[c.id] ?? ''} onChange={e => setNotes(n => ({ ...n, [c.id]: e.target.value }))}
                  placeholder="Notes (optional, sent to candidate by SMS)…"
                  rows={2} className="baraza-input text-sm resize-none"
                />
                <div className="flex gap-2">
                  <button onClick={() => act(c.id, 'approve')} disabled={acting === c.id}
                    className="flex items-center gap-1.5 px-4 py-2 bg-green-600 text-white rounded-lg text-sm font-medium hover:bg-green-700 transition-colors"
                  >
                    <CheckCircle size={15} /> Approve
                  </button>
                  <button onClick={() => act(c.id, 'reject')} disabled={acting === c.id}
                    className="flex items-center gap-1.5 px-4 py-2 bg-baraza-red text-white rounded-lg text-sm font-medium hover:bg-red-700 transition-colors"
                  >
                    <XCircle size={15} /> Reject
                  </button>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  )
}
