import Link           from 'next/link'
import { getSession } from '@/lib/auth/session'
import { redirect }   from 'next/navigation'
import { LayoutDashboard, UserCheck, Flag } from 'lucide-react'

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const session = await getSession()
  if (!session || session.role !== 'admin') redirect('/login')

  return (
    <div className="flex min-h-screen bg-gray-50">
      <aside className="w-52 bg-baraza-black text-white fixed h-full flex flex-col p-4">
        <div className="mb-6">
          <h1 className="text-lg font-bold text-baraza-green-light">Baraza Admin</h1>
        </div>
        <nav className="space-y-1">
          {[
            { href: '/admin/dashboard',     icon: LayoutDashboard, label: 'Dashboard'     },
            { href: '/admin/verifications', icon: UserCheck,        label: 'Verifications' },
            { href: '/admin/moderation',    icon: Flag,             label: 'Moderation'    },
          ].map(({ href, icon: Icon, label }) => (
            <Link key={href} href={href}
              className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-gray-300 hover:bg-white/10 hover:text-white transition-colors"
            >
              <Icon size={17} /> {label}
            </Link>
          ))}
        </nav>
        <div className="mt-auto text-xs text-gray-600 px-2">Logged in as admin</div>
      </aside>
      <main className="ml-52 flex-1 p-6 max-w-5xl">{children}</main>
    </div>
  )
}
