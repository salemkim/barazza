'use client'

import { useEffect, useState } from 'react'
import { toast }               from 'sonner'
import { timeAgo }             from '@/lib/utils'

interface Report {
  report:            { id: string; contentType: string; contentId: string; reason: string; createdAt: string }
  reporterUsername:  string
}

const ACTIONS = [
  { value: 'dismiss',        label: 'Dismiss'             },
  { value: 'delete_content', label: 'Delete Content'      },
  { value: 'suspend_user',   label: 'Suspend User'        },
]

export default function AdminModerationPage() {
  const [reports,  setReports]  = useState<Report[]>([])
  const [loading,  setLoading]  = useState(true)
  const [resolved, setResolved] = useState(false)
  const [acting,   setActing]   = useState<string | null>(null)
  const [form,     setForm]     = useState<Record<string, { action: string; notes: string; days: number }>>({})

  useEffect(() => {
    setLoading(true)
    fetch(`/api/admin/reports?resolved=${resolved}`)
      .then(r => r.json())
      .then(j => { setReports(j.data?.reports ?? []); setLoading(false) })
  }, [resolved])

  const getForm = (id: string) => form[id] ?? { action: 'dismiss', notes: '', days: 7 }
  const setF = (id: string, key: string, val: string | number) =>
    setForm(f => ({ ...f, [id]: { ...getForm(id), [key]: val } }))

  const resolve = async (reportId: string) => {
    const f = getForm(reportId)
    setActing(reportId)
    const res  = await fetch('/api/admin/reports', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body:   JSON.stringify({ reportId, action: f.action, actionNotes: f.notes, suspendDays: f.action === 'suspend_user' ? f.days : undefined }),
    })
    const json = await res.json()
    if (json.success) {
      toast.success('Report resolved')
      setReports(r => r.filter(x => x.report.id !== reportId))
    } else {
      toast.error(json.error)
    }
    setActing(null)
  }

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <h1 className="text-2xl font-bold">Content Moderation</h1>
        <div className="flex gap-2">
          {[false, true].map(r => (
            <button key={String(r)} onClick={() => setResolved(r)}
              className={`px-4 py-1.5 rounded-full text-sm font-medium transition-colors ${resolved === r ? 'bg-baraza-green text-white' : 'bg-white border border-gray-200 text-gray-600 hover:border-baraza-green'}`}
            >{r ? 'Resolved' : 'Open'}</button>
          ))}
        </div>
      </div>

      {loading && <p className="text-gray-400 text-sm">Loading…</p>}
      {!loading && reports.length === 0 && (
        <div className="text-center py-16 text-gray-400">
          <p className="font-semibold">No {resolved ? 'resolved' : 'open'} reports</p>
        </div>
      )}

      <div className="space-y-4">
        {reports.map(({ report, reporterUsername }) => {
          const f = getForm(report.id)
          return (
            <div key={report.id} className="baraza-card p-5">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <p className="text-sm font-semibold capitalize">{report.contentType} Report</p>
                  <p className="text-xs text-gray-500 mt-0.5">by @{reporterUsername} · {timeAgo(report.createdAt)}</p>
                  <p className="text-xs text-gray-400 mt-0.5">Content ID: {report.contentId}</p>
                </div>
              </div>

              <div className="bg-gray-50 rounded-lg px-3 py-2 mb-3">
                <p className="text-sm text-gray-700">{report.reason}</p>
              </div>

              {!resolved && (
                <div className="space-y-2">
                  <select value={f.action} onChange={e => setF(report.id, 'action', e.target.value)}
                    className="baraza-input text-sm"
                  >
                    {ACTIONS.map(a => <option key={a.value} value={a.value}>{a.label}</option>)}
                  </select>

                  {f.action === 'suspend_user' && (
                    <div className="flex items-center gap-2">
                      <label className="text-xs text-gray-600">Suspend for</label>
                      <select value={f.days} onChange={e => setF(report.id, 'days', Number(e.target.value))}
                        className="text-xs border border-gray-200 rounded px-2 py-1"
                      >
                        {[1,3,7,14,30,90,365].map(d => <option key={d} value={d}>{d} days</option>)}
                      </select>
                    </div>
                  )}

                  <textarea value={f.notes} onChange={e => setF(report.id, 'notes', e.target.value)}
                    placeholder="Action notes (optional)…" rows={2}
                    className="baraza-input text-sm resize-none"
                  />

                  <button onClick={() => resolve(report.id)} disabled={acting === report.id}
                    className="baraza-btn-primary text-sm px-4 py-2"
                  >
                    {acting === report.id ? 'Resolving…' : 'Resolve Report'}
                  </button>
                </div>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}
