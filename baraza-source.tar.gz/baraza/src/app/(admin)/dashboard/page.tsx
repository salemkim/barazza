'use client'

import { useEffect, useState } from 'react'
import { Users, FileText, CreditCard, Flag, UserCheck } from 'lucide-react'

interface Stats {
  totalUsers: number; totalCandidates: number; verifiedCandidates: number
  pendingVerifications: number; totalPosts: number; openReports: number
  totalRevenue: number; activeSubscriptions: number
}

export default function AdminDashboard() {
  const [stats, setStats]   = useState<Stats | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch('/api/admin/stats').then(r => r.json()).then(j => {
      setStats(j.data)
      setLoading(false)
    })
  }, [])

  const cards = [
    { label: 'Total Users',            value: stats?.totalUsers,            icon: Users,      color: 'text-blue-500',   bg: 'bg-blue-50'   },
    { label: 'Verified Candidates',    value: stats?.verifiedCandidates,    icon: UserCheck,  color: 'text-green-600',  bg: 'bg-green-50'  },
    { label: 'Pending Verifications',  value: stats?.pendingVerifications,  icon: UserCheck,  color: 'text-amber-500',  bg: 'bg-amber-50'  },
    { label: 'Total Posts',            value: stats?.totalPosts,            icon: FileText,   color: 'text-purple-500', bg: 'bg-purple-50' },
    { label: 'Active Subscriptions',   value: stats?.activeSubscriptions,   icon: CreditCard, color: 'text-baraza-green', bg: 'bg-green-50' },
    { label: 'Open Reports',           value: stats?.openReports,           icon: Flag,       color: 'text-baraza-red', bg: 'bg-red-50'    },
  ]

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Admin Dashboard</h1>
        <p className="text-sm text-gray-500 mt-0.5">Baraza platform overview</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
        {cards.map(({ label, value, icon: Icon, color, bg }) => (
          <div key={label} className="baraza-card p-4">
            <div className={`w-9 h-9 rounded-xl ${bg} flex items-center justify-center mb-3`}>
              <Icon size={18} className={color} />
            </div>
            {loading
              ? <div className="h-8 w-16 bg-gray-200 rounded animate-pulse mb-1" />
              : <p className="text-3xl font-bold">{(value ?? 0).toLocaleString()}</p>
            }
            <p className="text-xs text-gray-500 mt-0.5">{label}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="baraza-card p-4">
          <h3 className="font-semibold mb-3">Quick Actions</h3>
          <div className="space-y-2">
            <a href="/admin/verifications" className="block w-full baraza-btn-primary text-center text-sm py-2.5">
              Review Pending Verifications
            </a>
            <a href="/admin/moderation" className="block w-full baraza-btn-outline text-center text-sm py-2.5">
              Moderate Reports
            </a>
          </div>
        </div>

        <div className="baraza-card p-4">
          <h3 className="font-semibold mb-1">Revenue</h3>
          {loading
            ? <div className="h-10 w-32 bg-gray-200 rounded animate-pulse mt-2" />
            : <p className="text-3xl font-bold text-baraza-green mt-2">
                KES {(stats?.totalRevenue ?? 0).toLocaleString()}
              </p>
          }
          <p className="text-xs text-gray-500 mt-1">Total completed payments</p>
        </div>
      </div>
    </div>
  )
}
