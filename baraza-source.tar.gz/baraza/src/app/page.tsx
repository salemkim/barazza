import { redirect } from 'next/navigation'
import { getSession } from '@/lib/auth/session'

export default async function RootPage() {
  const session = await getSession()
  if (!session)                      redirect('/login')
  if (session.role === 'admin')      redirect('/admin/dashboard')
  if (session.role === 'candidate')  redirect('/candidate/dashboard')
  redirect('/voter/feed')
}
