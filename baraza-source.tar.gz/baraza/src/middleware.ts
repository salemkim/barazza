import { NextRequest, NextResponse } from 'next/server'
import { jwtVerify } from 'jose'
import type { SessionUser } from '@/types'

const secret      = new TextEncoder().encode(process.env.JWT_SECRET!)
const COOKIE      = process.env.SESSION_COOKIE_NAME ?? 'baraza_session'

// Route prefix → minimum required role (null = public)
const PROTECTED: Array<[string, 'voter' | 'candidate' | 'admin' | null]> = [
  ['/admin',      'admin'],
  ['/candidate',  'candidate'],
  ['/voter',      'voter'],
  ['/api/admin',  'admin'],
  ['/api/posts',  'voter'],       // POST/PATCH/DELETE only — GET is public
  ['/api/messages','voter'],
  ['/api/polls',  'voter'],
  ['/api/moderation','voter'],
]

async function getSessionUser(req: NextRequest): Promise<SessionUser | null> {
  const token = req.cookies.get(COOKIE)?.value
  if (!token) return null
  try {
    const { payload } = await jwtVerify(token, secret)
    return (payload as { user: SessionUser }).user
  } catch { return null }
}

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl

  // Find matching protected route
  const match = PROTECTED.find(([prefix]) => pathname.startsWith(prefix))
  if (!match) return NextResponse.next()

  const [, requiredRole] = match

  // Skip GET requests to API routes that are just reads
  if (req.method === 'GET' && pathname.startsWith('/api/') && !pathname.startsWith('/api/admin')) {
    return NextResponse.next()
  }

  const user = await getSessionUser(req)

  // Not logged in
  if (!user) {
    if (pathname.startsWith('/api/')) {
      return NextResponse.json({ success: false, error: 'Unauthorised' }, { status: 401 })
    }
    const url = req.nextUrl.clone()
    url.pathname = '/login'
    url.searchParams.set('redirect', pathname)
    return NextResponse.redirect(url)
  }

  // Suspended
  if (user.isSuspended) {
    if (pathname.startsWith('/api/')) {
      return NextResponse.json({ success: false, error: 'Account suspended' }, { status: 403 })
    }
    const url = req.nextUrl.clone()
    url.pathname = '/suspended'
    return NextResponse.redirect(url)
  }

  // Role check
  if (requiredRole) {
    const roleRank: Record<string, number> = { voter: 1, candidate: 2, admin: 3 }
    const userRank = roleRank[user.role] ?? 0
    const reqRank  = roleRank[requiredRole] ?? 0

    if (userRank < reqRank) {
      if (pathname.startsWith('/api/')) {
        return NextResponse.json({ success: false, error: 'Forbidden' }, { status: 403 })
      }
      return NextResponse.redirect(new URL('/', req.url))
    }
  }

  // Attach user info to request headers for route handlers
  const res = NextResponse.next()
  res.headers.set('x-user-id',   user.id)
  res.headers.set('x-user-role', user.role)
  return res
}

export const config = {
  matcher: [
    '/admin/:path*',
    '/candidate/:path*',
    '/voter/:path*',
    '/api/admin/:path*',
    '/api/posts/:path*',
    '/api/messages/:path*',
    '/api/polls/:path*',
    '/api/moderation/:path*',
    '/api/candidates/:path*',
    '/api/payments/:path*',
  ],
}
