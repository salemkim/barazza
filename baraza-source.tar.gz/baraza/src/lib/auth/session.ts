import { cookies } from 'next/headers'
import { SignJWT, jwtVerify } from 'jose'
import type { SessionUser } from '@/types'

const secret  = new TextEncoder().encode(process.env.JWT_SECRET!)
const COOKIE  = process.env.SESSION_COOKIE_NAME ?? 'baraza_session'
const MAX_AGE = 60 * 60 * 24 * 7 // 7 days

// ── Sign ──────────────────────────────────────────────────────────────────────
export async function createSession(user: SessionUser): Promise<string> {
  return new SignJWT({ user })
    .setProtectedHeader({ alg: 'HS256' })
    .setExpirationTime('7d')
    .setIssuedAt()
    .sign(secret)
}

// ── Verify ────────────────────────────────────────────────────────────────────
export async function verifySession(token: string): Promise<SessionUser | null> {
  try {
    const { payload } = await jwtVerify(token, secret)
    return (payload as { user: SessionUser }).user
  } catch { return null }
}

// ── Get current session from cookies ──────────────────────────────────────────
export async function getSession(): Promise<SessionUser | null> {
  const cookieStore = await cookies()
  const token = cookieStore.get(COOKIE)?.value
  if (!token) return null
  return verifySession(token)
}

// ── Set session cookie ────────────────────────────────────────────────────────
export async function setSessionCookie(token: string) {
  const cookieStore = await cookies()
  cookieStore.set(COOKIE, token, {
    httpOnly: true,
    secure:   process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    maxAge:   MAX_AGE,
    path:     '/',
  })
}

// ── Clear session ─────────────────────────────────────────────────────────────
export async function clearSession() {
  const cookieStore = await cookies()
  cookieStore.delete(COOKIE)
}
