const AT_BASE = 'https://api.africastalking.com/version1'

interface SMSResult {
  success: boolean
  messageId?: string
  error?: string
}

// ── Send OTP via Africa's Talking ─────────────────────────────────────────────
export async function sendOTPSMS(phone: string, otp: string): Promise<SMSResult> {
  try {
    const res = await fetch(`${AT_BASE}/messaging`, {
      method: 'POST',
      headers: {
        apiKey:         process.env.AT_API_KEY!,
        'Content-Type': 'application/x-www-form-urlencoded',
        Accept:         'application/json',
      },
      body: new URLSearchParams({
        username: process.env.AT_USERNAME!,
        to:       phone,
        message:  `Your Baraza verification code is: ${otp}. Valid for 10 minutes. Do not share this code.`,
        ...(process.env.AT_SENDER_ID && { from: process.env.AT_SENDER_ID }),
      }),
    })

    if (!res.ok) {
      const text = await res.text()
      console.error('[AT SMS] HTTP error:', res.status, text)
      return { success: false, error: `HTTP ${res.status}` }
    }

    const data = await res.json()
    const recipient = data?.SMSMessageData?.Recipients?.[0]

    if (recipient?.status === 'Success') {
      return { success: true, messageId: recipient.messageId }
    }

    const err = recipient?.status ?? 'Unknown error'
    console.error('[AT SMS] Delivery failed:', err)
    return { success: false, error: err }
  } catch (e) {
    console.error('[AT SMS] Exception:', e)
    return { success: false, error: String(e) }
  }
}

// ── Send generic SMS ──────────────────────────────────────────────────────────
export async function sendSMS(phone: string, message: string): Promise<SMSResult> {
  try {
    const res = await fetch(`${AT_BASE}/messaging`, {
      method: 'POST',
      headers: {
        apiKey:         process.env.AT_API_KEY!,
        'Content-Type': 'application/x-www-form-urlencoded',
        Accept:         'application/json',
      },
      body: new URLSearchParams({
        username: process.env.AT_USERNAME!,
        to:       phone,
        message,
        ...(process.env.AT_SENDER_ID && { from: process.env.AT_SENDER_ID }),
      }),
    })

    const data = await res.json()
    const recipient = data?.SMSMessageData?.Recipients?.[0]
    if (recipient?.status === 'Success') return { success: true }
    return { success: false, error: recipient?.status }
  } catch (e) {
    return { success: false, error: String(e) }
  }
}
