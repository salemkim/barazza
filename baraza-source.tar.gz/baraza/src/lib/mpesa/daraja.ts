const BASE = process.env.MPESA_BASE_URL ?? 'https://sandbox.safaricom.co.ke'

// ── Token cache (in-memory, valid 1 hour) ────────────────────────────────────
let cachedToken:   string | null = null
let tokenExpiry:   number        = 0

async function getAccessToken(): Promise<string> {
  if (cachedToken && Date.now() < tokenExpiry - 30_000) return cachedToken

  const creds  = Buffer.from(
    `${process.env.MPESA_CONSUMER_KEY}:${process.env.MPESA_CONSUMER_SECRET}`
  ).toString('base64')

  const res  = await fetch(`${BASE}/oauth/v1/generate?grant_type=client_credentials`, {
    headers: { Authorization: `Basic ${creds}` },
    cache:   'no-store',
  })

  if (!res.ok) throw new Error(`[MPesa] Token fetch failed: ${res.status}`)
  const json = await res.json()

  cachedToken = json.access_token as string
  tokenExpiry = Date.now() + (json.expires_in ?? 3600) * 1000
  return cachedToken
}

// ── Timestamp in YYYYMMDDHHmmss ──────────────────────────────────────────────
function mpesaTimestamp(): string {
  return new Date().toISOString().replace(/[^0-9]/g, '').slice(0, 14)
}

// ── STK Push password ─────────────────────────────────────────────────────────
function mpesaPassword(timestamp: string): string {
  return Buffer.from(
    `${process.env.MPESA_SHORTCODE}${process.env.MPESA_PASSKEY}${timestamp}`
  ).toString('base64')
}

// ── Initiate STK Push ─────────────────────────────────────────────────────────
export interface STKPushParams {
  phone:            string  // 2547XXXXXXXX format (no +)
  amount:           number
  accountReference: string  // max 12 chars
  transactionDesc:  string  // max 13 chars
}

export interface STKPushResult {
  success:              boolean
  checkoutRequestId?:   string
  merchantRequestId?:   string
  responseCode?:        string
  customerMessage?:     string
  error?:               string
}

export async function initiateSTKPush(params: STKPushParams): Promise<STKPushResult> {
  try {
    const token     = await getAccessToken()
    const timestamp = mpesaTimestamp()
    const password  = mpesaPassword(timestamp)
    const phone     = params.phone.replace(/^\+/, '').replace(/^0/, '254')

    const body = {
      BusinessShortCode: process.env.MPESA_SHORTCODE,
      Password:          password,
      Timestamp:         timestamp,
      TransactionType:   'CustomerPayBillOnline',
      Amount:            Math.ceil(params.amount), // must be integer
      PartyA:            phone,
      PartyB:            process.env.MPESA_SHORTCODE,
      PhoneNumber:       phone,
      CallBackURL:       process.env.MPESA_CALLBACK_URL,
      AccountReference:  params.accountReference.slice(0, 12),
      TransactionDesc:   params.transactionDesc.slice(0, 13),
    }

    const res = await fetch(`${BASE}/mpesa/stkpush/v1/processrequest`, {
      method:  'POST',
      headers: {
        Authorization:  `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(body),
    })

    const json = await res.json()

    if (json.ResponseCode === '0') {
      return {
        success:            true,
        checkoutRequestId:  json.CheckoutRequestID,
        merchantRequestId:  json.MerchantRequestID,
        responseCode:       json.ResponseCode,
        customerMessage:    json.CustomerMessage,
      }
    }

    console.error('[MPesa] STK Push failed:', json)
    return { success: false, error: json.errorMessage ?? json.ResponseDescription ?? 'STK Push failed' }
  } catch (e) {
    console.error('[MPesa] Exception in STK Push:', e)
    return { success: false, error: String(e) }
  }
}

// ── Parse M-Pesa callback body ────────────────────────────────────────────────
export interface MpesaCallbackBody {
  Body: {
    stkCallback: {
      MerchantRequestID: string
      CheckoutRequestID: string
      ResultCode:        number
      ResultDesc:        string
      CallbackMetadata?: {
        Item: Array<{ Name: string; Value?: string | number }>
      }
    }
  }
}

export interface ParsedMpesaCallback {
  checkoutRequestId: string
  merchantRequestId: string
  resultCode:        number
  resultDesc:        string
  success:           boolean
  receiptNumber?:    string
  amount?:           number
  phone?:            string
  transactionDate?:  string
}

export function parseMpesaCallback(body: MpesaCallbackBody): ParsedMpesaCallback {
  const cb   = body.Body.stkCallback
  const meta = cb.CallbackMetadata?.Item ?? []
  const get  = (name: string) => meta.find(i => i.Name === name)?.Value

  return {
    checkoutRequestId: cb.CheckoutRequestID,
    merchantRequestId: cb.MerchantRequestID,
    resultCode:        cb.ResultCode,
    resultDesc:        cb.ResultDesc,
    success:           cb.ResultCode === 0,
    receiptNumber:     String(get('MpesaReceiptNumber') ?? ''),
    amount:            Number(get('Amount') ?? 0),
    phone:             String(get('PhoneNumber') ?? ''),
    transactionDate:   String(get('TransactionDate') ?? ''),
  }
}

// ── Query STK Push status ─────────────────────────────────────────────────────
export async function querySTKStatus(checkoutRequestId: string) {
  const token     = await getAccessToken()
  const timestamp = mpesaTimestamp()
  const password  = mpesaPassword(timestamp)

  const res = await fetch(`${BASE}/mpesa/stkpushquery/v1/query`, {
    method:  'POST',
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    body:    JSON.stringify({
      BusinessShortCode: process.env.MPESA_SHORTCODE,
      Password:          password,
      Timestamp:         timestamp,
      CheckoutRequestID: checkoutRequestId,
    }),
  })

  return res.json()
}
