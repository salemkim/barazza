import { createAdminSupabaseClient } from '@/lib/auth/supabase'

const BUCKET = process.env.SUPABASE_STORAGE_BUCKET ?? 'baraza-uploads'

export type UploadFolder = 'profiles' | 'posts' | 'verifications'

export interface UploadResult {
  success:  boolean
  url?:     string
  path?:    string
  error?:   string
}

// ── Upload a file from a Buffer / Blob ────────────────────────────────────────
export async function uploadFile(
  file:      Buffer | Blob,
  folder:    UploadFolder,
  filename:  string,
  mimeType:  string,
): Promise<UploadResult> {
  try {
    const supabase  = createAdminSupabaseClient()
    const path      = `${folder}/${Date.now()}_${filename}`

    const { data, error } = await supabase.storage
      .from(BUCKET)
      .upload(path, file, { contentType: mimeType, upsert: true })

    if (error) return { success: false, error: error.message }

    const { data: { publicUrl } } = supabase.storage.from(BUCKET).getPublicUrl(data.path)
    return { success: true, url: publicUrl, path: data.path }
  } catch (e) {
    return { success: false, error: String(e) }
  }
}

// ── Upload from a Next.js FormData File ──────────────────────────────────────
export async function uploadFormFile(
  file:   File,
  folder: UploadFolder,
): Promise<UploadResult> {
  const bytes    = await file.arrayBuffer()
  const buffer   = Buffer.from(bytes)
  const ext      = file.name.split('.').pop() ?? 'bin'
  const safeName = `${Date.now()}.${ext}`
  return uploadFile(buffer, folder, safeName, file.type)
}

// ── Delete a file by path ─────────────────────────────────────────────────────
export async function deleteFile(path: string): Promise<boolean> {
  try {
    const supabase = createAdminSupabaseClient()
    const { error } = await supabase.storage.from(BUCKET).remove([path])
    return !error
  } catch { return false }
}

// ── Get a signed URL (for private assets) ────────────────────────────────────
export async function getSignedUrl(path: string, expiresIn = 3600): Promise<string | null> {
  try {
    const supabase = createAdminSupabaseClient()
    const { data, error } = await supabase.storage
      .from(BUCKET)
      .createSignedUrl(path, expiresIn)
    if (error) return null
    return data.signedUrl
  } catch { return null }
}
