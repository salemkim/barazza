import {
  pgTable, pgEnum, uuid, varchar, text, boolean, integer,
  timestamp, jsonb, numeric, serial, primaryKey, index,
} from 'drizzle-orm/pg-core'
import { relations } from 'drizzle-orm'

// ── Enums ─────────────────────────────────────────────────────────────────────
export const userRoleEnum          = pgEnum('user_role',           ['voter', 'candidate', 'admin'])
export const verificationStatusEnum= pgEnum('verification_status', ['none', 'pending', 'approved', 'rejected'])
export const subscriptionTierEnum  = pgEnum('subscription_tier',   ['free', 'silver', 'gold', 'platinum'])
export const seatTypeEnum          = pgEnum('seat_type',           ['president', 'governor', 'senator', 'women_rep', 'mp', 'mca'])
export const paymentTypeEnum       = pgEnum('payment_type',        ['subscription', 'boost'])
export const paymentStatusEnum     = pgEnum('payment_status',      ['pending', 'completed', 'failed', 'cancelled'])
export const reportContentTypeEnum = pgEnum('report_content_type', ['post', 'comment', 'message'])

// ── Location Tables ───────────────────────────────────────────────────────────

export const counties = pgTable('counties', {
  id:   serial('id').primaryKey(),
  code: integer('code').unique().notNull(),
  name: varchar('name', { length: 100 }).notNull(),
}, (t) => ({ nameIdx: index('counties_name_idx').on(t.name) }))

export const constituencies = pgTable('constituencies', {
  id:       serial('id').primaryKey(),
  code:     integer('code').unique().notNull(),
  name:     varchar('name', { length: 100 }).notNull(),
  countyId: integer('county_id').references(() => counties.id, { onDelete: 'cascade' }).notNull(),
}, (t) => ({
  countyIdx: index('constituencies_county_idx').on(t.countyId),
  nameIdx:   index('constituencies_name_idx').on(t.name),
}))

export const wards = pgTable('wards', {
  id:               serial('id').primaryKey(),
  code:             integer('code').unique().notNull(),
  name:             varchar('name', { length: 100 }).notNull(),
  constituencyId:   integer('constituency_id').references(() => constituencies.id, { onDelete: 'cascade' }).notNull(),
}, (t) => ({
  constituencyIdx: index('wards_constituency_idx').on(t.constituencyId),
}))

// ── Users ─────────────────────────────────────────────────────────────────────

export const users = pgTable('users', {
  id:         uuid('id').primaryKey().defaultRandom(),
  supabaseId: uuid('supabase_id').unique(),
  phone:      varchar('phone', { length: 20 }).unique().notNull(),
  email:      varchar('email', { length: 255 }).unique(),
  username:   varchar('username', { length: 50 }).unique().notNull(),
  fullName:   varchar('full_name', { length: 200 }),
  role:       userRoleEnum('role').notNull().default('voter'),

  // Candidate-specific
  isVerifiedCandidate:  boolean('is_verified_candidate').default(false).notNull(),
  verificationStatus:   verificationStatusEnum('verification_status').default('none').notNull(),
  verificationDocUrl:   text('verification_doc_url'),
  verificationNotes:    text('verification_notes'),
  verifiedAt:           timestamp('verified_at'),
  verifiedBy:           uuid('verified_by'),
  party:                varchar('party', { length: 100 }),

  // Location (for feed personalisation)
  countyId:        integer('county_id').references(() => counties.id),
  constituencyId:  integer('constituency_id').references(() => constituencies.id),
  wardId:          integer('ward_id').references(() => wards.id),

  // Profile
  profileImageUrl: text('profile_image_url'),
  bio:             text('bio'),
  website:         varchar('website', { length: 255 }),

  // Subscription
  subscriptionTier:   subscriptionTierEnum('subscription_tier').default('free').notNull(),
  subscriptionExpiry: timestamp('subscription_expiry'),

  // Safety
  isSuspended:   boolean('is_suspended').default(false).notNull(),
  suspendedUntil: timestamp('suspended_until'),
  suspendReason:  text('suspend_reason'),

  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (t) => ({
  phoneIdx:    index('users_phone_idx').on(t.phone),
  roleIdx:     index('users_role_idx').on(t.role),
  countyIdx:   index('users_county_idx').on(t.countyId),
}))

// ── OTP Store ─────────────────────────────────────────────────────────────────

export const otpStore = pgTable('otp_store', {
  id:        uuid('id').primaryKey().defaultRandom(),
  phone:     varchar('phone', { length: 20 }).notNull(),
  otp:       varchar('otp', { length: 10 }).notNull(),
  expiresAt: timestamp('expires_at').notNull(),
  verified:  boolean('verified').default(false).notNull(),
  attempts:  integer('attempts').default(0).notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
}, (t) => ({ phoneIdx: index('otp_phone_idx').on(t.phone) }))

// ── Seats ─────────────────────────────────────────────────────────────────────

export const seats = pgTable('seats', {
  id:              serial('id').primaryKey(),
  type:            seatTypeEnum('type').notNull(),
  countyId:        integer('county_id').references(() => counties.id),
  constituencyId:  integer('constituency_id').references(() => constituencies.id),
  wardId:          integer('ward_id').references(() => wards.id),
  displayLabel:    varchar('display_label', { length: 300 }).notNull(),
}, (t) => ({
  typeIdx:   index('seats_type_idx').on(t.type),
  countyIdx: index('seats_county_idx').on(t.countyId),
}))

export const candidateSeats = pgTable('candidate_seats', {
  candidateId: uuid('candidate_id').references(() => users.id, { onDelete: 'cascade' }).notNull(),
  seatId:      integer('seat_id').references(() => seats.id, { onDelete: 'cascade' }).notNull(),
  createdAt:   timestamp('created_at').defaultNow().notNull(),
}, (t) => ({ pk: primaryKey({ columns: [t.candidateId, t.seatId] }) }))

// ── Posts ─────────────────────────────────────────────────────────────────────

export const posts = pgTable('posts', {
  id:             uuid('id').primaryKey().defaultRandom(),
  authorId:       uuid('author_id').references(() => users.id, { onDelete: 'cascade' }).notNull(),
  seatId:         integer('seat_id').references(() => seats.id),
  contentText:    text('content_text').notNull(),
  imageUrl:       text('image_url'),
  videoUrl:       text('video_url'),
  isBoosted:      boolean('is_boosted').default(false).notNull(),
  boostExpiresAt: timestamp('boost_expires_at'),
  isDeleted:      boolean('is_deleted').default(false).notNull(),
  deletedAt:      timestamp('deleted_at'),
  likesCount:     integer('likes_count').default(0).notNull(),
  commentsCount:  integer('comments_count').default(0).notNull(),
  createdAt:      timestamp('created_at').defaultNow().notNull(),
  updatedAt:      timestamp('updated_at').defaultNow().notNull(),
}, (t) => ({
  authorIdx:  index('posts_author_idx').on(t.authorId),
  seatIdx:    index('posts_seat_idx').on(t.seatId),
  boostIdx:   index('posts_boost_idx').on(t.isBoosted, t.boostExpiresAt),
  createdIdx: index('posts_created_idx').on(t.createdAt),
}))

// ── Comments ──────────────────────────────────────────────────────────────────

export const comments = pgTable('comments', {
  id:              uuid('id').primaryKey().defaultRandom(),
  postId:          uuid('post_id').references(() => posts.id, { onDelete: 'cascade' }).notNull(),
  authorId:        uuid('author_id').references(() => users.id, { onDelete: 'cascade' }).notNull(),
  parentCommentId: uuid('parent_comment_id'),
  text:            text('text').notNull(),
  isDeleted:       boolean('is_deleted').default(false).notNull(),
  createdAt:       timestamp('created_at').defaultNow().notNull(),
}, (t) => ({
  postIdx:   index('comments_post_idx').on(t.postId),
  authorIdx: index('comments_author_idx').on(t.authorId),
}))

// ── Likes ─────────────────────────────────────────────────────────────────────

export const postLikes = pgTable('post_likes', {
  postId:    uuid('post_id').references(() => posts.id, { onDelete: 'cascade' }).notNull(),
  userId:    uuid('user_id').references(() => users.id, { onDelete: 'cascade' }).notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
}, (t) => ({
  pk:      primaryKey({ columns: [t.postId, t.userId] }),
  userIdx: index('likes_user_idx').on(t.userId),
}))

// ── Polls ─────────────────────────────────────────────────────────────────────

export const polls = pgTable('polls', {
  id:        uuid('id').primaryKey().defaultRandom(),
  postId:    uuid('post_id').references(() => posts.id, { onDelete: 'cascade' }).notNull().unique(),
  question:  text('question').notNull(),
  options:   jsonb('options').notNull().$type<{ text: string; votes: number }[]>(),
  endsAt:    timestamp('ends_at').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
})

export const pollVotes = pgTable('poll_votes', {
  pollId:      uuid('poll_id').references(() => polls.id, { onDelete: 'cascade' }).notNull(),
  userId:      uuid('user_id').references(() => users.id, { onDelete: 'cascade' }).notNull(),
  optionIndex: integer('option_index').notNull(),
  createdAt:   timestamp('created_at').defaultNow().notNull(),
}, (t) => ({ pk: primaryKey({ columns: [t.pollId, t.userId] }) }))

// ── Direct Messages ───────────────────────────────────────────────────────────

export const directMessages = pgTable('direct_messages', {
  id:         uuid('id').primaryKey().defaultRandom(),
  senderId:   uuid('sender_id').references(() => users.id, { onDelete: 'cascade' }).notNull(),
  receiverId: uuid('receiver_id').references(() => users.id, { onDelete: 'cascade' }).notNull(),
  text:       text('text').notNull(),
  isRead:     boolean('is_read').default(false).notNull(),
  isDeleted:  boolean('is_deleted').default(false).notNull(),
  createdAt:  timestamp('created_at').defaultNow().notNull(),
}, (t) => ({
  senderIdx:   index('dm_sender_idx').on(t.senderId),
  receiverIdx: index('dm_receiver_idx').on(t.receiverId),
  convoIdx:    index('dm_convo_idx').on(t.senderId, t.receiverId),
}))

// ── Payments ──────────────────────────────────────────────────────────────────

export const payments = pgTable('payments', {
  id:                      uuid('id').primaryKey().defaultRandom(),
  userId:                  uuid('user_id').references(() => users.id, { onDelete: 'cascade' }).notNull(),
  amount:                  numeric('amount', { precision: 10, scale: 2 }).notNull(),
  type:                    paymentTypeEnum('type').notNull(),
  packageTier:             varchar('package_tier', { length: 50 }),
  mpesaReceiptNumber:      varchar('mpesa_receipt_number', { length: 50 }),
  mpesaCheckoutRequestId:  varchar('mpesa_checkout_request_id', { length: 200 }).unique(),
  mpesaMerchantRequestId:  varchar('mpesa_merchant_request_id', { length: 200 }),
  phoneUsed:               varchar('phone_used', { length: 20 }),
  status:                  paymentStatusEnum('status').default('pending').notNull(),
  metadata:                jsonb('metadata').$type<Record<string, unknown>>(),
  failureReason:           text('failure_reason'),
  createdAt:               timestamp('created_at').defaultNow().notNull(),
  completedAt:             timestamp('completed_at'),
}, (t) => ({
  userIdx:    index('payments_user_idx').on(t.userId),
  statusIdx:  index('payments_status_idx').on(t.status),
  checkoutIdx:index('payments_checkout_idx').on(t.mpesaCheckoutRequestId),
}))

// ── Subscriptions ─────────────────────────────────────────────────────────────

export const subscriptions = pgTable('subscriptions', {
  id:        uuid('id').primaryKey().defaultRandom(),
  userId:    uuid('user_id').references(() => users.id, { onDelete: 'cascade' }).notNull().unique(),
  tier:      subscriptionTierEnum('tier').notNull(),
  startDate: timestamp('start_date').defaultNow().notNull(),
  endDate:   timestamp('end_date').notNull(),
  autoRenew: boolean('auto_renew').default(true).notNull(),
  paymentId: uuid('payment_id').references(() => payments.id),
  createdAt: timestamp('created_at').defaultNow().notNull(),
})

// ── Boost Purchases ───────────────────────────────────────────────────────────

export const boostPurchases = pgTable('boost_purchases', {
  id:            uuid('id').primaryKey().defaultRandom(),
  userId:        uuid('user_id').references(() => users.id, { onDelete: 'cascade' }).notNull(),
  postId:        uuid('post_id').references(() => posts.id, { onDelete: 'cascade' }).notNull(),
  purchaseDate:  timestamp('purchase_date').defaultNow().notNull(),
  durationHours: integer('duration_hours').default(24).notNull(),
  expiresAt:     timestamp('expires_at').notNull(),
  paymentId:     uuid('payment_id').references(() => payments.id),
})

// ── Reports ───────────────────────────────────────────────────────────────────

export const reports = pgTable('reports', {
  id:          uuid('id').primaryKey().defaultRandom(),
  reportedBy:  uuid('reported_by').references(() => users.id, { onDelete: 'cascade' }).notNull(),
  contentType: reportContentTypeEnum('content_type').notNull(),
  contentId:   uuid('content_id').notNull(),
  reason:      text('reason').notNull(),
  resolved:    boolean('resolved').default(false).notNull(),
  resolvedBy:  uuid('resolved_by').references(() => users.id),
  resolvedAt:  timestamp('resolved_at'),
  actionTaken: text('action_taken'),
  createdAt:   timestamp('created_at').defaultNow().notNull(),
}, (t) => ({
  contentIdx:   index('reports_content_idx').on(t.contentType, t.contentId),
  resolvedIdx:  index('reports_resolved_idx').on(t.resolved),
}))

// ── Promise Tracker (Post-election) ──────────────────────────────────────────

export const promises = pgTable('promises', {
  id:          uuid('id').primaryKey().defaultRandom(),
  candidateId: uuid('candidate_id').references(() => users.id, { onDelete: 'cascade' }).notNull(),
  title:       varchar('title', { length: 300 }).notNull(),
  description: text('description').notNull(),
  category:    varchar('category', { length: 100 }),
  status:      varchar('status', { length: 50 }).default('pending').notNull(),
  sourceUrl:   text('source_url'),
  dueDate:     timestamp('due_date'),
  createdAt:   timestamp('created_at').defaultNow().notNull(),
  updatedAt:   timestamp('updated_at').defaultNow().notNull(),
})

export const promiseUpdates = pgTable('promise_updates', {
  id:          uuid('id').primaryKey().defaultRandom(),
  promiseId:   uuid('promise_id').references(() => promises.id, { onDelete: 'cascade' }).notNull(),
  authorId:    uuid('author_id').references(() => users.id).notNull(),
  text:        text('text').notNull(),
  evidence:    text('evidence'),
  newStatus:   varchar('new_status', { length: 50 }),
  createdAt:   timestamp('created_at').defaultNow().notNull(),
})

// ── Relations ─────────────────────────────────────────────────────────────────

export const usersRelations = relations(users, ({ one, many }) => ({
  county:         one(counties,       { fields: [users.countyId],       references: [counties.id] }),
  constituency:   one(constituencies, { fields: [users.constituencyId], references: [constituencies.id] }),
  ward:           one(wards,          { fields: [users.wardId],          references: [wards.id] }),
  candidateSeat:  one(candidateSeats, { fields: [users.id], references: [candidateSeats.candidateId] }),
  posts:          many(posts),
  subscription:   one(subscriptions,  { fields: [users.id], references: [subscriptions.userId] }),
  payments:       many(payments),
  sentMessages:   many(directMessages, { relationName: 'sender' }),
  receivedMessages: many(directMessages, { relationName: 'receiver' }),
}))

export const postsRelations = relations(posts, ({ one, many }) => ({
  author:   one(users,    { fields: [posts.authorId], references: [users.id] }),
  seat:     one(seats,    { fields: [posts.seatId],   references: [seats.id] }),
  comments: many(comments),
  likes:    many(postLikes),
  poll:     one(polls,    { fields: [posts.id], references: [polls.postId] }),
}))

export const countiesRelations = relations(counties, ({ many }) => ({
  constituencies: many(constituencies),
  seats:          many(seats),
}))

export const constituenciesRelations = relations(constituencies, ({ one, many }) => ({
  county: one(counties, { fields: [constituencies.countyId], references: [counties.id] }),
  wards:  many(wards),
  seats:  many(seats),
}))

export const wardsRelations = relations(wards, ({ one, many }) => ({
  constituency: one(constituencies, { fields: [wards.constituencyId], references: [constituencies.id] }),
  seats:        many(seats),
}))

export const seatsRelations = relations(seats, ({ one, many }) => ({
  county:        one(counties,        { fields: [seats.countyId],       references: [counties.id] }),
  constituency:  one(constituencies,  { fields: [seats.constituencyId], references: [constituencies.id] }),
  ward:          one(wards,           { fields: [seats.wardId],          references: [wards.id] }),
  candidateSeat: one(candidateSeats,  { fields: [seats.id], references: [candidateSeats.seatId] }),
  posts:         many(posts),
}))

export const directMessagesRelations = relations(directMessages, ({ one }) => ({
  sender:   one(users, { fields: [directMessages.senderId],   references: [users.id], relationName: 'sender' }),
  receiver: one(users, { fields: [directMessages.receiverId], references: [users.id], relationName: 'receiver' }),
}))

// ── Type Exports ──────────────────────────────────────────────────────────────

export type User             = typeof users.$inferSelect
export type NewUser          = typeof users.$inferInsert
export type County           = typeof counties.$inferSelect
export type Constituency     = typeof constituencies.$inferSelect
export type Ward             = typeof wards.$inferSelect
export type Seat             = typeof seats.$inferSelect
export type Post             = typeof posts.$inferSelect
export type NewPost          = typeof posts.$inferInsert
export type Comment          = typeof comments.$inferSelect
export type Poll             = typeof polls.$inferSelect
export type DirectMessage    = typeof directMessages.$inferSelect
export type Payment          = typeof payments.$inferSelect
export type Subscription     = typeof subscriptions.$inferSelect
export type Report           = typeof reports.$inferSelect
export type Promise_         = typeof promises.$inferSelect
