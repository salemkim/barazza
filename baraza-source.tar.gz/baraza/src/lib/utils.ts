import { clsx, type ClassValue } from 'clsx'
import { twMerge } from 'tailwind-merge'
import Filter from 'bad-words'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// ── Phone normalisation ───────────────────────────────────────────────────────
export function normalisePhone(phone: string): string {
  const digits = phone.replace(/\D/g, '')
  if (digits.startsWith('254') && digits.length === 12) return `+${digits}`
  if (digits.startsWith('0')   && digits.length === 10) return `+254${digits.slice(1)}`
  if (digits.length === 9)                               return `+254${digits}`
  return `+${digits}`
}

export function isValidKenyanPhone(phone: string): boolean {
  return /^\+254[17]\d{8}$/.test(normalisePhone(phone))
}

// ── OTP generation ────────────────────────────────────────────────────────────
export function generateOTP(length = 6): string {
  const digits = '0123456789'
  let otp = ''
  for (let i = 0; i < length; i++) {
    otp += digits[Math.floor(Math.random() * digits.length)]
  }
  return otp
}

// ── Profanity filter ──────────────────────────────────────────────────────────
const filter = new Filter()

export function containsProfanity(text: string): boolean {
  try { return filter.isProfane(text) }
  catch { return false }
}

export function cleanText(text: string): string {
  try { return filter.clean(text) }
  catch { return text }
}

// ── Date helpers ──────────────────────────────────────────────────────────────
export function timeAgo(date: Date | string): string {
  const now     = new Date()
  const past    = new Date(date)
  const seconds = Math.floor((now.getTime() - past.getTime()) / 1000)

  if (seconds < 60)     return 'just now'
  if (seconds < 3600)   return `${Math.floor(seconds / 60)}m ago`
  if (seconds < 86400)  return `${Math.floor(seconds / 3600)}h ago`
  if (seconds < 604800) return `${Math.floor(seconds / 86400)}d ago`
  return past.toLocaleDateString('en-KE', { day: 'numeric', month: 'short', year: 'numeric' })
}

export function addDays(date: Date, days: number): Date {
  const result = new Date(date)
  result.setDate(result.getDate() + days)
  return result
}

export function addMonths(date: Date, months: number): Date {
  const result = new Date(date)
  result.setMonth(result.getMonth() + months)
  return result
}

// ── Formatting ────────────────────────────────────────────────────────────────
export function formatKES(amount: number): string {
  return `KES ${amount.toLocaleString('en-KE')}`
}

export function truncate(str: string, length: number): string {
  return str.length > length ? `${str.slice(0, length)}…` : str
}

export function slugify(str: string): string {
  return str.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '')
}

// ── Seat type display ─────────────────────────────────────────────────────────
export const SEAT_TYPE_LABELS: Record<string, string> = {
  president: 'President',
  governor:  'Governor',
  senator:   'Senator',
  women_rep: 'Women Representative',
  mp:        'Member of Parliament',
  mca:       'MCA',
}

// ── Tier display ──────────────────────────────────────────────────────────────
export const TIER_LABELS: Record<string, string> = {
  free:     'Free',
  silver:   'Silver',
  gold:     'Gold',
  platinum: 'Platinum',
}

export const TIER_COLORS: Record<string, string> = {
  free:     'text-gray-500',
  silver:   'text-gray-400',
  gold:     'text-yellow-500',
  platinum: 'text-purple-500',
}

// ── API helpers ───────────────────────────────────────────────────────────────
export function apiSuccess<T>(data: T, message?: string) {
  return Response.json({ success: true, data, message }, { status: 200 })
}

export function apiError(error: string, status = 400) {
  return Response.json({ success: false, error }, { status })
}

export function apiCreated<T>(data: T) {
  return Response.json({ success: true, data }, { status: 201 })
}

// ── Sanitisation ──────────────────────────────────────────────────────────────
export function sanitiseText(text: string): string {
  return text
    .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
    .replace(/<[^>]+>/g, '')
    .trim()
}

// Re-export pricing constants for convenience
export { BOOST_PRICES, SUBSCRIPTION_PRICES } from '@/types'
