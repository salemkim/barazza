export type UserRole           = 'voter' | 'candidate' | 'admin'
export type VerificationStatus = 'none' | 'pending' | 'approved' | 'rejected'
export type SubscriptionTier   = 'free' | 'silver' | 'gold' | 'platinum'
export type SeatType           = 'president' | 'governor' | 'senator' | 'women_rep' | 'mp' | 'mca'
export type PaymentType        = 'subscription' | 'boost'
export type PaymentStatus      = 'pending' | 'completed' | 'failed' | 'cancelled'

export interface SessionUser {
  id:                  string
  phone:               string
  username:            string
  fullName:            string | null
  role:                UserRole
  isVerifiedCandidate: boolean
  verificationStatus:  VerificationStatus
  subscriptionTier:    SubscriptionTier
  profileImageUrl:     string | null
  countyId:            number | null
  constituencyId:      number | null
  wardId:              number | null
  isSuspended:         boolean
}

export interface ApiResponse<T = unknown> {
  success: boolean
  data?:   T
  error?:  string
  message?: string
}

export interface PaginatedResponse<T> extends ApiResponse<T[]> {
  total:    number
  page:     number
  pageSize: number
  hasMore:  boolean
}

export interface FeedPost {
  id:             string
  contentText:    string
  imageUrl:       string | null
  videoUrl:       string | null
  isBoosted:      boolean
  boostExpiresAt: string | null
  likesCount:     number
  commentsCount:  number
  createdAt:      string
  hasLiked:       boolean
  author: {
    id:                  string
    username:            string
    fullName:            string | null
    profileImageUrl:     string | null
    party:               string | null
    isVerifiedCandidate: boolean
    subscriptionTier:    SubscriptionTier
  }
  seat?: {
    id:           number
    type:         SeatType
    displayLabel: string
  } | null
  poll?: {
    id:      string
    question: string
    options: { text: string; votes: number }[]
    endsAt:  string
    hasVoted: boolean
    userVote: number | null
  } | null
}

export interface ConversationPreview {
  userId:         string
  username:       string
  fullName:       string | null
  profileImageUrl: string | null
  lastMessage:    string
  lastMessageAt:  string
  unreadCount:    number
}

// Pricing constants
export const SUBSCRIPTION_PRICES: Record<SeatType, Record<Exclude<SubscriptionTier, 'free'>, number>> = {
  president: { silver: 10000, gold: 25000, platinum: 50000 },
  governor:  { silver: 5000,  gold: 12000, platinum: 25000 },
  senator:   { silver: 5000,  gold: 12000, platinum: 25000 },
  women_rep: { silver: 5000,  gold: 12000, platinum: 25000 },
  mp:        { silver: 3000,  gold: 8000,  platinum: 15000 },
  mca:       { silver: 2000,  gold: 5000,  platinum: 10000 },
}

export const BOOST_PRICES: Record<SeatType, number> = {
  president: 5000,
  governor:  3000,
  senator:   3000,
  women_rep: 3000,
  mp:        1500,
  mca:       500,
}

export const FREE_POST_LIMIT_PER_WEEK = 3
