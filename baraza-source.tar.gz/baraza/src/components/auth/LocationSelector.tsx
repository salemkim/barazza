'use client'

import { useLocation } from '@/hooks/useLocation'

interface Props {
  onChange: (data: { countyId: number | null; constituencyId: number | null; wardId: number | null }) => void
  required?: boolean
  showWard?: boolean
}

export default function LocationSelector({ onChange, required = true, showWard = true }: Props) {
  const {
    counties, constituencies, wards,
    selectedCounty, setSelectedCounty,
    selectedConstituency, setSelectedConstituency,
    selectedWard, setSelectedWard,
    loadingC, loadingK, loadingW,
  } = useLocation()

  const handleCounty = (id: number) => {
    setSelectedCounty(id)
    onChange({ countyId: id, constituencyId: null, wardId: null })
  }

  const handleConstituency = (id: number) => {
    setSelectedConstituency(id)
    onChange({ countyId: selectedCounty, constituencyId: id, wardId: null })
  }

  const handleWard = (id: number) => {
    setSelectedWard(id)
    onChange({ countyId: selectedCounty, constituencyId: selectedConstituency, wardId: id })
  }

  return (
    <div className="space-y-3">
      {/* County */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          County {required && <span className="text-baraza-red">*</span>}
        </label>
        <select
          className="baraza-input"
          value={selectedCounty ?? ''}
          onChange={e => handleCounty(Number(e.target.value))}
          required={required}
          disabled={loadingC}
        >
          <option value="">{loadingC ? 'Loading counties…' : 'Select county'}</option>
          {counties.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
      </div>

      {/* Constituency */}
      {selectedCounty && (
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Constituency {required && <span className="text-baraza-red">*</span>}
          </label>
          <select
            className="baraza-input"
            value={selectedConstituency ?? ''}
            onChange={e => handleConstituency(Number(e.target.value))}
            required={required}
            disabled={loadingK}
          >
            <option value="">{loadingK ? 'Loading…' : 'Select constituency'}</option>
            {constituencies.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        </div>
      )}

      {/* Ward */}
      {showWard && selectedConstituency && (
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Ward <span className="text-gray-400 font-normal">(optional)</span>
          </label>
          <select
            className="baraza-input"
            value={selectedWard ?? ''}
            onChange={e => handleWard(Number(e.target.value))}
            disabled={loadingW}
          >
            <option value="">{loadingW ? 'Loading…' : 'Select ward (optional)'}</option>
            {wards.map(w => <option key={w.id} value={w.id}>{w.name}</option>)}
          </select>
        </div>
      )}
    </div>
  )
}
