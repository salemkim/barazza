'use client'

import { useRef, KeyboardEvent, ClipboardEvent } from 'react'
import { cn } from '@/lib/utils'

interface Props {
  value:    string
  onChange: (val: string) => void
  length?:  number
}

export default function OTPInput({ value, onChange, length = 6 }: Props) {
  const refs = useRef<(HTMLInputElement | null)[]>([])
  const digits = value.padEnd(length, '').split('').slice(0, length)

  const update = (idx: number, char: string) => {
    const next = digits.map((d, i) => i === idx ? char : d).join('')
    onChange(next.slice(0, length))
    if (char && idx < length - 1) refs.current[idx + 1]?.focus()
  }

  const onKey = (idx: number, e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace') {
      if (digits[idx]) { update(idx, ''); }
      else if (idx > 0) { refs.current[idx - 1]?.focus() }
    }
    if (e.key === 'ArrowLeft'  && idx > 0)           refs.current[idx - 1]?.focus()
    if (e.key === 'ArrowRight' && idx < length - 1)  refs.current[idx + 1]?.focus()
  }

  const onPaste = (e: ClipboardEvent) => {
    e.preventDefault()
    const pasted = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, length)
    onChange(pasted.padEnd(length, '').slice(0, length))
    refs.current[Math.min(pasted.length, length - 1)]?.focus()
  }

  return (
    <div className="flex gap-2 justify-center">
      {digits.map((d, i) => (
        <input
          key={i}
          ref={el => { refs.current[i] = el }}
          type="text" inputMode="numeric" maxLength={1}
          value={d} onPaste={onPaste}
          onChange={e => update(i, e.target.value.replace(/\D/g, '').slice(-1))}
          onKeyDown={e => onKey(i, e)}
          onFocus={e => e.target.select()}
          className={cn(
            'w-11 h-12 text-center text-lg font-bold border-2 rounded-xl transition-all',
            'focus:outline-none focus:ring-2 focus:ring-baraza-green/30',
            d ? 'border-baraza-green bg-baraza-green-muted text-baraza-green' : 'border-gray-200',
          )}
        />
      ))}
    </div>
  )
}
