'use client'

import Link           from 'next/link'
import { usePathname } from 'next/navigation'
import { Home, Search, MessageCircle, User } from 'lucide-react'
import { cn } from '@/lib/utils'

const NAV = [
  { href: '/voter/feed',     icon: Home,          label: 'Home' },
  { href: '/voter/explore',  icon: Search,         label: 'Explore' },
  { href: '/voter/messages', icon: MessageCircle,  label: 'Messages' },
  { href: '/voter/profile',  icon: User,           label: 'Profile' },
]

export default function BottomNav() {
  const pathname = usePathname()
  return (
    <nav className="fixed bottom-0 inset-x-0 z-50 bg-white border-t border-gray-100 flex items-center justify-around pb-safe">
      {NAV.map(({ href, icon: Icon, label }) => {
        const active = pathname.startsWith(href)
        return (
          <Link key={href} href={href}
            className={cn(
              'flex flex-col items-center gap-0.5 px-4 py-2.5 text-xs font-medium transition-colors',
              active ? 'text-baraza-green' : 'text-gray-400 hover:text-baraza-green',
            )}
          >
            <Icon size={22} strokeWidth={active ? 2.5 : 1.8} />
            <span>{label}</span>
          </Link>
        )
      })}
    </nav>
  )
}
