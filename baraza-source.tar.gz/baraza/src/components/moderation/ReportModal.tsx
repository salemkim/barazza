'use client'

import { useState } from 'react'
import { toast }    from 'sonner'
import { X }        from 'lucide-react'

interface Props {
  contentType: 'post' | 'comment' | 'message'
  contentId:   string
  onClose:     () => void
}

const REASONS = [
  'Hate speech or discrimination',
  'Misinformation or false claims',
  'Harassment or bullying',
  'Spam or unsolicited content',
  'Inappropriate content',
  'Other',
]

export default function ReportModal({ contentType, contentId, onClose }: Props) {
  const [reason,     setReason]     = useState('')
  const [custom,     setCustom]     = useState('')
  const [submitting, setSubmitting] = useState(false)

  const submit = async () => {
    const text = reason === 'Other' ? custom.trim() : reason
    if (!text) { toast.error('Please select a reason'); return }
    setSubmitting(true)
    const res  = await fetch('/api/moderation/report', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body:   JSON.stringify({ contentType, contentId, reason: text }),
    })
    const json = await res.json()
    if (json.success) { toast.success('Report submitted. Thank you.'); onClose() }
    else toast.error(json.error)
    setSubmitting(false)
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/50 flex items-end sm:items-center justify-center p-4">
      <div className="w-full max-w-md bg-white rounded-2xl p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold">Report Content</h3>
          <button onClick={onClose}><X size={18} className="text-gray-400" /></button>
        </div>

        <div className="space-y-2 mb-4">
          {REASONS.map(r => (
            <label key={r} className="flex items-center gap-3 p-2.5 rounded-lg border border-gray-100 cursor-pointer hover:border-baraza-green transition-colors">
              <input type="radio" name="reason" value={r} checked={reason === r} onChange={() => setReason(r)} className="accent-baraza-green" />
              <span className="text-sm">{r}</span>
            </label>
          ))}
        </div>

        {reason === 'Other' && (
          <textarea
            value={custom} onChange={e => setCustom(e.target.value)}
            placeholder="Describe the issue…"
            rows={3}
            className="baraza-input text-sm mb-4 resize-none"
          />
        )}

        <button onClick={submit} disabled={submitting || !reason} className="baraza-btn-primary w-full">
          {submitting ? 'Submitting…' : 'Submit Report'}
        </button>
      </div>
    </div>
  )
}
