export default function FeedSkeleton({ count = 3 }: { count?: number }) {
  return (
    <>
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} className="baraza-card mb-3 p-4 animate-pulse">
          <div className="flex gap-3 mb-3">
            <div className="w-10 h-10 rounded-full bg-gray-200 flex-shrink-0" />
            <div className="flex-1 space-y-1.5">
              <div className="h-3.5 bg-gray-200 rounded w-1/3" />
              <div className="h-3 bg-gray-100 rounded w-1/4" />
            </div>
          </div>
          <div className="space-y-2">
            <div className="h-3 bg-gray-200 rounded w-full" />
            <div className="h-3 bg-gray-200 rounded w-5/6" />
            <div className="h-3 bg-gray-100 rounded w-2/3" />
          </div>
          <div className="flex gap-6 mt-4 pt-3 border-t border-gray-50">
            <div className="h-3 bg-gray-100 rounded w-10" />
            <div className="h-3 bg-gray-100 rounded w-10" />
            <div className="h-3 bg-gray-100 rounded w-10" />
          </div>
        </div>
      ))}
    </>
  )
}
