'use client'

import { useState }   from 'react'
import { toast }      from 'sonner'
import { useAuthStore } from '@/store/auth-store'

interface PollOption { text: string; votes: number }
interface PollData {
  id: string; question: string; options: PollOption[]
  endsAt: string; hasVoted: boolean; userVote: number | null
}

export default function PollBlock({ poll, postId }: { poll: PollData; postId: string }) {
  const { user }   = useAuthStore()
  const [data,     setData]     = useState(poll)
  const [voting,   setVoting]   = useState(false)
  const expired = new Date() > new Date(data.endsAt)
  const totalVotes = data.options.reduce((s, o) => s + o.votes, 0)

  const vote = async (idx: number) => {
    if (!user)        { toast.error('Login to vote'); return }
    if (data.hasVoted) return
    if (expired)       { toast.error('Poll has ended'); return }
    setVoting(true)

    const res  = await fetch('/api/polls/vote', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body:   JSON.stringify({ pollId: data.id, optionIndex: idx }),
    })
    const json = await res.json()
    if (json.success) {
      setData(d => ({ ...d, hasVoted: true, userVote: idx, options: json.data.options }))
    } else {
      toast.error(json.error)
    }
    setVoting(false)
  }

  return (
    <div className="px-4 pb-3">
      <p className="text-sm font-semibold mb-2">{data.question}</p>
      <div className="space-y-2">
        {data.options.map((opt, i) => {
          const pct      = totalVotes === 0 ? 0 : Math.round((opt.votes / totalVotes) * 100)
          const isVoted  = data.hasVoted && data.userVote === i
          const showBar  = data.hasVoted || expired

          return (
            <button key={i} onClick={() => vote(i)} disabled={data.hasVoted || expired || voting}
              className="w-full text-left relative overflow-hidden rounded-lg border border-gray-200 px-3 py-2 text-sm font-medium transition-all hover:border-baraza-green disabled:cursor-default"
            >
              {showBar && (
                <div
                  className={`absolute inset-y-0 left-0 ${isVoted ? 'bg-baraza-green' : 'bg-gray-100'} transition-all`}
                  style={{ width: `${pct}%` }}
                />
              )}
              <span className="relative flex justify-between">
                <span>{opt.text}</span>
                {showBar && <span className="text-xs text-gray-500">{pct}%</span>}
              </span>
            </button>
          )
        })}
      </div>
      <p className="text-xs text-gray-400 mt-2">
        {totalVotes} vote{totalVotes !== 1 ? 's' : ''} ·{' '}
        {expired ? 'Poll ended' : `Ends ${new Date(data.endsAt).toLocaleDateString()}`}
      </p>
    </div>
  )
}
