'use client'

import { useState }     from 'react'
import Image            from 'next/image'
import { toast }        from 'sonner'
import { Heart, MessageCircle, Share2, Flag, Zap } from 'lucide-react'
import { cn, timeAgo, SEAT_TYPE_LABELS } from '@/lib/utils'
import type { FeedPost } from '@/types'
import { useAuthStore } from '@/store/auth-store'
import PollBlock        from './PollBlock'
import ReportModal      from '../moderation/ReportModal'

interface Props { post: FeedPost; onUpdate?: (post: FeedPost) => void }

export default function PostCard({ post, onUpdate }: Props) {
  const { user }      = useAuthStore()
  const [liked,       setLiked]       = useState(post.hasLiked)
  const [likesCount,  setLikesCount]  = useState(post.likesCount)
  const [showReport,  setShowReport]  = useState(false)
  const [showComments,setShowComments]= useState(false)

  const handleLike = async () => {
    if (!user) { toast.error('Login to like posts'); return }
    const next = !liked
    setLiked(next)
    setLikesCount(c => next ? c + 1 : Math.max(0, c - 1))
    const res = await fetch(`/api/posts/${post.id}/like`, { method: 'POST' })
    if (!res.ok) { setLiked(!next); setLikesCount(c => next ? Math.max(0, c - 1) : c + 1) }
  }

  const handleShare = async () => {
    const url = `${window.location.origin}/post/${post.id}`
    if (navigator.share) {
      await navigator.share({ title: post.author.fullName ?? post.author.username, text: post.contentText, url })
    } else {
      await navigator.clipboard.writeText(url)
      toast.success('Link copied!')
    }
  }

  return (
    <article className="baraza-card mb-3">
      {/* Boosted badge */}
      {post.isBoosted && (
        <div className="flex items-center gap-1.5 px-4 pt-3 pb-0 text-xs font-semibold text-baraza-gold">
          <Zap size={12} fill="currentColor" /> Promoted
        </div>
      )}

      {/* Header */}
      <div className="flex items-start gap-3 p-4 pb-3">
        <div className="relative h-10 w-10 rounded-full overflow-hidden bg-baraza-green-muted flex-shrink-0">
          {post.author.profileImageUrl
            ? <Image src={post.author.profileImageUrl} alt={post.author.username} fill className="object-cover" />
            : <div className="w-full h-full flex items-center justify-center text-baraza-green font-bold text-lg">
                {(post.author.fullName ?? post.author.username)[0].toUpperCase()}
              </div>
          }
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="font-semibold text-sm truncate">{post.author.fullName ?? post.author.username}</span>
            {post.author.isVerifiedCandidate && (
              <span className="verified-badge">✓ Verified</span>
            )}
          </div>
          <div className="flex items-center gap-2 mt-0.5">
            {post.author.party && (
              <span className="text-xs text-gray-500">{post.author.party}</span>
            )}
            {post.seat && (
              <>
                <span className="text-gray-300 text-xs">·</span>
                <span className="text-xs text-baraza-green font-medium">
                  {SEAT_TYPE_LABELS[post.seat.type]}
                </span>
              </>
            )}
          </div>
          <p className="text-xs text-gray-400 mt-0.5">{timeAgo(post.createdAt)}</p>
        </div>
      </div>

      {/* Content */}
      <div className="px-4 pb-3">
        <p className="text-sm leading-relaxed whitespace-pre-wrap text-gray-800">{post.contentText}</p>
      </div>

      {/* Image */}
      {post.imageUrl && (
        <div className="relative w-full aspect-video bg-gray-100">
          <Image src={post.imageUrl} alt="Post image" fill className="object-cover" />
        </div>
      )}

      {/* Poll */}
      {post.poll && <PollBlock poll={post.poll} postId={post.id} />}

      {/* Actions */}
      <div className="flex items-center justify-between px-4 py-2.5 border-t border-gray-50">
        <button onClick={handleLike}
          className={cn('flex items-center gap-1.5 text-xs font-medium transition-colors',
            liked ? 'text-baraza-red' : 'text-gray-400 hover:text-baraza-red')}
        >
          <Heart size={16} fill={liked ? 'currentColor' : 'none'} />
          {likesCount > 0 && <span>{likesCount}</span>}
        </button>

        <button onClick={() => setShowComments(v => !v)}
          className="flex items-center gap-1.5 text-xs font-medium text-gray-400 hover:text-baraza-green transition-colors"
        >
          <MessageCircle size={16} />
          {post.commentsCount > 0 && <span>{post.commentsCount}</span>}
        </button>

        <button onClick={handleShare}
          className="flex items-center gap-1.5 text-xs font-medium text-gray-400 hover:text-baraza-green transition-colors"
        >
          <Share2 size={16} />
        </button>

        <button onClick={() => setShowReport(true)}
          className="flex items-center gap-1 text-xs text-gray-300 hover:text-baraza-red transition-colors"
        >
          <Flag size={14} />
        </button>
      </div>

      {/* Comments section */}
      {showComments && <CommentsSection postId={post.id} />}

      {/* Report modal */}
      {showReport && (
        <ReportModal
          contentType="post"
          contentId={post.id}
          onClose={() => setShowReport(false)}
        />
      )}
    </article>
  )
}

// ── Inline comments section ───────────────────────────────────────────────────
function CommentsSection({ postId }: { postId: string }) {
  const { user }     = useAuthStore()
  const [comments,   setComments]  = useState<any[]>([])
  const [text,       setText]      = useState('')
  const [loading,    setLoading]   = useState(false)
  const [submitting, setSubmitting]= useState(false)

  useState(() => {
    setLoading(true)
    fetch(`/api/comments?postId=${postId}`)
      .then(r => r.json())
      .then(j => setComments(j.data ?? []))
      .finally(() => setLoading(false))
  })

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!text.trim() || !user) return
    setSubmitting(true)
    const res  = await fetch('/api/comments', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ postId, text }) })
    const json = await res.json()
    if (json.success) { setComments(c => [...c, json.data]); setText('') }
    else toast.error(json.error)
    setSubmitting(false)
  }

  return (
    <div className="border-t border-gray-50 px-4 py-3 space-y-3">
      {loading && <p className="text-xs text-gray-400">Loading comments…</p>}
      {comments.map((c) => (
        <div key={c.id} className="flex gap-2">
          <div className="w-6 h-6 rounded-full bg-baraza-green-muted flex-shrink-0 flex items-center justify-center text-baraza-green text-xs font-bold">
            {c.authorId?.[0]?.toUpperCase() ?? '?'}
          </div>
          <div className="flex-1 bg-gray-50 rounded-lg px-3 py-1.5">
            <p className="text-xs text-gray-800">{c.text}</p>
            <p className="text-[10px] text-gray-400 mt-0.5">{timeAgo(c.createdAt)}</p>
          </div>
        </div>
      ))}
      {user && (
        <form onSubmit={submit} className="flex gap-2 mt-2">
          <input
            value={text} onChange={e => setText(e.target.value)}
            placeholder="Add a comment…"
            className="flex-1 baraza-input text-xs py-1.5"
          />
          <button disabled={submitting || !text.trim()} className="baraza-btn-primary text-xs px-3 py-1.5">
            Send
          </button>
        </form>
      )}
    </div>
  )
}
