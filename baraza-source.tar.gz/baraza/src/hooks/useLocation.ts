'use client'

import { useState, useEffect } from 'react'

export interface LocationOption { id: number; name: string; code: number }

export function useLocation() {
  const [counties,       setCounties]       = useState<LocationOption[]>([])
  const [constituencies, setConstituencies] = useState<LocationOption[]>([])
  const [wards,          setWards]          = useState<LocationOption[]>([])
  const [selectedCounty,        setSelectedCounty]        = useState<number | null>(null)
  const [selectedConstituency,  setSelectedConstituency]  = useState<number | null>(null)
  const [selectedWard,          setSelectedWard]          = useState<number | null>(null)
  const [loadingC, setLoadingC] = useState(false)
  const [loadingK, setLoadingK] = useState(false)
  const [loadingW, setLoadingW] = useState(false)

  // Load counties on mount
  useEffect(() => {
    setLoadingC(true)
    fetch('/api/locations/counties')
      .then(r => r.json())
      .then(j => setCounties(j.data ?? []))
      .finally(() => setLoadingC(false))
  }, [])

  // Load constituencies when county changes
  useEffect(() => {
    if (!selectedCounty) { setConstituencies([]); setWards([]); return }
    setLoadingK(true)
    setSelectedConstituency(null)
    setSelectedWard(null)
    setConstituencies([])
    setWards([])
    fetch(`/api/locations/constituencies?county=${selectedCounty}`)
      .then(r => r.json())
      .then(j => setConstituencies(j.data ?? []))
      .finally(() => setLoadingK(false))
  }, [selectedCounty])

  // Load wards when constituency changes
  useEffect(() => {
    if (!selectedConstituency) { setWards([]); return }
    setLoadingW(true)
    setSelectedWard(null)
    setWards([])
    fetch(`/api/locations/wards?constituency=${selectedConstituency}`)
      .then(r => r.json())
      .then(j => setWards(j.data ?? []))
      .finally(() => setLoadingW(false))
  }, [selectedConstituency])

  return {
    counties, constituencies, wards,
    selectedCounty, setSelectedCounty,
    selectedConstituency, setSelectedConstituency,
    selectedWard, setSelectedWard,
    loadingC, loadingK, loadingW,
  }
}
