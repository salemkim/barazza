'use client'

import { useEffect, useCallback } from 'react'
import { useRouter }  from 'next/navigation'
import { useAuthStore } from '@/store/auth-store'
import type { SessionUser } from '@/types'

export function useAuth() {
  const { user, loading, setUser, setLoading, logout: storeLogout } = useAuthStore()
  const router = useRouter()

  const fetchSession = useCallback(async () => {
    try {
      setLoading(true)
      const res  = await fetch('/api/auth/session')
      const json = await res.json()
      if (json.success) setUser(json.data as SessionUser)
      else              setUser(null)
    } catch {
      setUser(null)
    }
  }, [setUser, setLoading])

  useEffect(() => {
    fetchSession()
  }, [fetchSession])

  const logout = useCallback(async () => {
    await fetch('/api/auth/session', { method: 'DELETE' })
    storeLogout()
    router.push('/login')
  }, [storeLogout, router])

  return { user, loading, refetch: fetchSession, logout }
}
