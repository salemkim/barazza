import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import type { SessionUser } from '@/types'

interface AuthState {
  user:       SessionUser | null
  loading:    boolean
  setUser:    (user: SessionUser | null) => void
  setLoading: (loading: boolean) => void
  logout:     () => void
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user:       null,
      loading:    true,
      setUser:    (user)    => set({ user, loading: false }),
      setLoading: (loading) => set({ loading }),
      logout:     ()        => set({ user: null, loading: false }),
    }),
    {
      name:    'baraza-auth',
      partialize: (state) => ({ user: state.user }),
    },
  ),
)
