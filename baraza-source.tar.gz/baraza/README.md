# Baraza — Kenya Civic Engagement Platform

**Baraza** (Swahili: *public forum/meeting*) is a two-sided civic platform connecting verified political candidates with voters through location-personalised feeds, direct messaging and M-Pesa powered subscriptions — built for Kenya's 2027 general elections and beyond.

---

## Features

### Voters (Free)
- Personalised feed: see only candidates running in your ward, constituency and county
- Like, comment and share candidate posts
- Direct message verified candidates (Gold/Platinum tier)
- Vote in candidate polls
- Explore candidates anywhere in Kenya

### Candidates (Paid subscription)
- Verified profile with IEBC document upload
- Post manifestos and policy updates (3/week free, unlimited on paid)
- Analytics: views, likes, comments
- Boost posts to top of local feed for 24 hours (via M-Pesa)
- Direct inbox from voters (Gold+)
- Three subscription tiers: Silver, Gold, Platinum — priced by seat level

### Admin
- Approve/reject candidate verifications (SMS notification on decision)
- Content moderation queue — dismiss, delete content, or suspend users
- Platform stats dashboard

---

## Tech Stack

| Layer         | Technology                        |
|---------------|-----------------------------------|
| Frontend      | Next.js 14 (App Router), TypeScript, Tailwind CSS |
| State         | Zustand (client), React Query (server) |
| Database      | PostgreSQL via Supabase (Drizzle ORM) |
| Auth          | Custom JWT sessions + phone OTP    |
| SMS / OTP     | Africa's Talking                   |
| Payments      | M-Pesa Daraja API (STK Push)       |
| File Storage  | Supabase Storage                   |
| Hosting       | Vercel                             |

---

## Getting Started

### 1. Clone and install

```bash
git clone https://github.com/your-org/baraza.git
cd baraza
npm install
```

### 2. Environment variables

```bash
cp .env.example .env.local
```

Fill in all values in `.env.local`:

| Variable | Where to get it |
|----------|----------------|
| `DATABASE_URL` | Supabase → Settings → Database → Connection String |
| `NEXT_PUBLIC_SUPABASE_URL` | Supabase → Settings → API |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Supabase → Settings → API |
| `SUPABASE_SERVICE_ROLE_KEY` | Supabase → Settings → API (keep secret) |
| `AT_API_KEY` | [Africa's Talking console](https://africastalking.com) |
| `AT_USERNAME` | Africa's Talking → Apps |
| `MPESA_CONSUMER_KEY` | [Safaricom Developer Portal](https://developer.safaricom.co.ke) |
| `MPESA_CONSUMER_SECRET` | Safaricom Developer Portal |
| `MPESA_SHORTCODE` | Your M-Pesa business shortcode |
| `MPESA_PASSKEY` | Safaricom Developer Portal → Lipa na M-Pesa |
| `MPESA_CALLBACK_URL` | Your public domain + `/api/mpesa/callback` |
| `JWT_SECRET` | Any 32+ character random string |

### 3. Database setup

```bash
# Push schema to your Supabase PostgreSQL
npm run db:push

# Seed Kenya's 47 counties and sample constituencies/wards
npm run db:seed
```

> **Full IEBC Data**: The seed script includes all 47 counties and representative sample data. For full production coverage (290 constituencies, ~1,450 wards), download the complete IEBC electoral boundaries dataset from [iebc.or.ke](https://www.iebc.or.ke) and extend `scripts/seed-locations.ts`.

### 4. Create Supabase Storage bucket

In your Supabase dashboard:
- Go to **Storage** → **New bucket**
- Name it `baraza-uploads`
- Set to **Public** (or configure RLS policies for private)

### 5. Run development server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

### 6. Create first admin user

After registering normally, update your user's role in the database:

```sql
UPDATE users SET role = 'admin' WHERE phone = '+254XXXXXXXXX';
```

---

## M-Pesa Integration

The platform uses **Daraja STK Push** (Lipa na M-Pesa Online):

1. Candidate selects a subscription tier or clicks "Boost Post"
2. Backend calls `initiateSTKPush()` — a payment prompt appears on their phone
3. Candidate enters M-Pesa PIN
4. Safaricom calls back `POST /api/mpesa/callback`
5. Callback handler verifies the payment and activates subscription or boost

**For development**: Use the [Safaricom Sandbox](https://sandbox.safaricom.co.ke) with test credentials. The callback URL must be publicly accessible — use [ngrok](https://ngrok.com) or Vercel preview deployments.

```bash
# Expose local server for M-Pesa callbacks
npx ngrok http 3000
# Then set MPESA_CALLBACK_URL=https://your-ngrok-url.ngrok.io/api/mpesa/callback
```

---

## Key Routes

| Path | Description |
|------|-------------|
| `/login` | Phone OTP login |
| `/register/voter` | Voter registration |
| `/register/candidate` | Candidate application |
| `/voter/feed` | Personalised voter feed |
| `/voter/explore` | Browse candidates by area |
| `/voter/messages` | DM conversations |
| `/voter/profile` | Location settings |
| `/candidate/dashboard` | Candidate home |
| `/candidate/posts/new` | Create post |
| `/candidate/subscription` | Upgrade plan |
| `/candidate/analytics` | Post stats |
| `/candidate/messages` | Voter inbox |
| `/admin/dashboard` | Platform overview |
| `/admin/verifications` | Approve candidates |
| `/admin/moderation` | Content reports |

---

## API Reference

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| POST | `/api/auth/send-otp` | None | Send OTP to phone |
| POST | `/api/auth/register-voter` | None | Create voter account |
| POST | `/api/auth/register-candidate` | None | Apply as candidate |
| POST | `/api/auth/login` | None | Verify OTP, issue session |
| GET | `/api/auth/session` | Session | Get current user |
| DELETE | `/api/auth/session` | Session | Logout |
| GET | `/api/locations/counties` | None | All 47 counties |
| GET | `/api/locations/constituencies?county=N` | None | Constituencies in county |
| GET | `/api/locations/wards?constituency=N` | None | Wards in constituency |
| GET | `/api/feed` | Optional | Personalised feed |
| GET/POST | `/api/posts` | Candidate | List/create posts |
| POST | `/api/posts/[id]/like` | Voter | Toggle like |
| DELETE | `/api/posts/[id]` | Author/Admin | Soft-delete post |
| POST | `/api/posts/boost` | Candidate | Initiate boost payment |
| GET/POST | `/api/comments` | Voter | List/add comments |
| GET/POST | `/api/messages` | Voter | Conversations + send |
| POST | `/api/polls/vote` | Voter | Cast poll vote |
| POST | `/api/payments/subscribe` | Candidate | Initiate subscription |
| GET | `/api/payments/history` | Candidate | Payment history |
| GET | `/api/payments/[id]/status` | Candidate | Poll payment status |
| POST | `/api/mpesa/callback` | M-Pesa | Payment confirmation |
| POST | `/api/moderation/report` | Voter | Report content |
| GET/POST | `/api/admin/reports` | Admin | View/resolve reports |
| GET | `/api/admin/candidates` | Admin | List by verification status |
| POST | `/api/admin/verify-candidate` | Admin | Approve or reject |
| GET | `/api/admin/stats` | Admin | Platform stats |
| PATCH | `/api/user/location` | Voter | Update location |

---

## Deployment

### Vercel (recommended)

```bash
npm install -g vercel
vercel --prod
```

Set all environment variables in the Vercel dashboard under **Settings → Environment Variables**.

**Important**: Set `MPESA_CALLBACK_URL` to your production domain:
```
MPESA_CALLBACK_URL=https://baraza.ke/api/mpesa/callback
```

### Database migrations

After schema changes:

```bash
npm run db:generate   # generate migration files
npm run db:migrate    # apply to production DB
```

---

## Post-Election: Accountability Hub

After the August 2027 election, Baraza transitions elected candidates to **Leaders**. The `promises` and `promise_updates` tables (already in the schema) power the manifesto tracking feature:

- Voters view promises made during campaigns
- Crowdsourced progress updates from the community
- Discussion threads per promise
- Leaders can post verified updates

This turns Baraza from an election tool into a permanent civic accountability platform, sustaining revenue through NGO and media analytics subscriptions between election cycles.

---

## Contributing

Pull requests welcome. For major changes, open an issue first.

**Priority backlog**:
- [ ] Real-time notifications (Supabase Realtime)
- [ ] Full IEBC location data seed (290 constituencies, 1,450 wards)
- [ ] Push notifications (PWA)
- [ ] Candidate profile photo upload on registration
- [ ] BCLB-licensed prediction markets (Phase 4)
- [ ] Offline support (service worker)

---

## License

MIT © 2025 Baraza

---

*Built for Kenya's democracy. Siasa safi — clean politics.*
