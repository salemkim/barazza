---
name: Baraza Civic System
colors:
  surface: '#f6fbf4'
  surface-dim: '#d7dbd5'
  surface-bright: '#f6fbf4'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f1f5ee'
  surface-container: '#ebefe8'
  surface-container-high: '#e5e9e2'
  surface-container-highest: '#dfe4dd'
  on-surface: '#181d19'
  on-surface-variant: '#3f4941'
  inverse-surface: '#2d322d'
  inverse-on-surface: '#eef2eb'
  outline: '#6f7a70'
  outline-variant: '#bec9be'
  surface-tint: '#046d3e'
  primary: '#00502c'
  on-primary: '#ffffff'
  primary-container: '#006b3c'
  on-primary-container: '#90e9ad'
  inverse-primary: '#81d99f'
  secondary: '#5f5e5e'
  on-secondary: '#ffffff'
  secondary-container: '#e5e2e1'
  on-secondary-container: '#656464'
  tertiary: '#735c00'
  on-tertiary: '#ffffff'
  tertiary-container: '#cca830'
  on-tertiary-container: '#4f3e00'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#9df6b9'
  primary-fixed-dim: '#81d99f'
  on-primary-fixed: '#00210f'
  on-primary-fixed-variant: '#00522d'
  secondary-fixed: '#e5e2e1'
  secondary-fixed-dim: '#c8c6c5'
  on-secondary-fixed: '#1c1b1b'
  on-secondary-fixed-variant: '#474646'
  tertiary-fixed: '#ffe088'
  tertiary-fixed-dim: '#e9c349'
  on-tertiary-fixed: '#241a00'
  on-tertiary-fixed-variant: '#574500'
  background: '#f6fbf4'
  on-background: '#181d19'
  surface-variant: '#dfe4dd'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  caption:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  xxl: 48px
  container-margin: 16px
  gutter: 12px
---

## Brand & Style
The design system is built to facilitate democratic participation and civic transparency. The brand personality is **authoritative yet accessible**, bridging the gap between high-level policy making and grassroots community action. It avoids the bureaucratic heaviness of traditional government portals and the frantic energy of betting platforms, opting instead for a **Corporate Modern** aesthetic influenced by high-end fintech.

The style leverages high-contrast typography, generous whitespace, and a precise grid to evoke a sense of stability and reliability. Interaction patterns are mobile-first, prioritizing speed and clarity to mimic the real-time nature of modern social discourse while maintaining the professional polish of an enterprise tool.

## Colors
The palette is rooted in Kenyan national identity but applied with a premium, minimalist lens. 

- **Primary Deep Green (#006B3C):** Used for primary actions, success states, and key brand touchpoints. It represents growth and institutional trust.
- **Neutral Black & White:** These form the core of the interface, ensuring content remains the priority. In Dark Mode, pure black (#000000) is used for backgrounds to maximize contrast on OLED mobile screens.
- **Gold Accent (#D4AF37):** Reserved exclusively for "Verified" statuses, high-level civic badges, and premium membership indicators.
- **Red Accent (#BB0000):** Used sparingly for critical alerts, error states, and "Live" indicators.

Color application should follow a 60-30-10 rule to ensure the "Deep Green" remains an accent that guides the eye rather than overwhelming the content.

## Typography
The typography system uses a dual-font strategy to balance character with utility. 

**Plus Jakarta Sans** is used for headlines and titles. Its soft yet geometric curves provide a modern, welcoming feel that differentiates the platform from legacy institutional sites. 

**Inter** is the workhorse for body copy and data-heavy views. It is chosen for its exceptional legibility on mobile screens and its neutral, "systematic" tone which lends an air of objectivity to civic data and user comments. 

Large display type should utilize tighter letter-spacing to appear more cohesive and "editorial."

## Layout & Spacing
The layout follows a **Fluid Grid** model optimized for mobile-first consumption. 

- **Mobile:** A 4-column grid with 16px side margins and 12px gutters. This ensures tight content density suitable for real-time feeds.
- **Tablet/Desktop:** A 12-column centered grid with a maximum width of 1200px. Content should reflow into sidebars for navigation and secondary analytics.

Spacing is based on a **4px baseline scale**. Components should predominantly use `md (16px)` for internal padding and `lg (24px)` for vertical section breathing room.

## Elevation & Depth
This design system uses **Tonal Layers** and **Low-Contrast Outlines** rather than heavy shadows to define hierarchy. This creates a clean, "flat-plus" aesthetic that feels modern and high-performance.

- **Level 0 (Background):** Pure white (light) or Pure black (dark).
- **Level 1 (Cards/Surface):** A subtle off-white or dark-grey surface with a 1px border (`#E5E7EB` in light mode).
- **Level 2 (Modals/Pop-overs):** Elevated with a soft, highly diffused ambient shadow (10% opacity) to signify temporary focus.
- **Glassmorphism:** Used exclusively for **Bottom Navigation** bars and **Fixed Headers**, employing a 20px backdrop blur to maintain context of the scrolling content behind them.

## Shapes
The shape language is **Rounded (0.5rem / 8px)**. This radius strikes a balance between the "serious" square corners of traditional finance and the "friendly" hyper-roundedness of social apps.

- **Standard Buttons & Cards:** 8px (0.5rem).
- **Large Containers/Input Fields:** 8px (0.5rem).
- **Chips & Tags:** Fully rounded (Pill-shaped) to distinguish them from actionable buttons.
- **Search Bars:** 12px for a softer, more inviting entry point.

## Components

- **Buttons:** Primary buttons use the Deep Green background with White text. Secondary buttons use a ghost style (border only). Button height should be 48px on mobile to ensure a comfortable tap target.
- **Cards:** Used for feed items and bill tracking. Cards should have a 1px border and no shadow. The header of the card should use `title-md`.
- **Bottom Navigation:** A mobile-essential component. Icons should be 24px, accompanied by `caption` labels. Active state is indicated by a Primary Green tint on the icon and label.
- **Analytics Charts:** Use a palette of Green, Gold, and Slate Gray. Avoid "traffic light" colors (Red/Yellow/Green) unless specifically indicating performance or safety. Line charts should be simplified (sparklines) for mobile views.
- **Data Tables:** On mobile, tables should transfigure into "List Cards." On desktop, use a condensed Inter font for data rows with a slight zebra-striping on hover.
- **Toasts:** Positioned at the top of the screen on mobile to avoid clashing with the Bottom Navigation. Use a solid black background with white text for high visibility.
- **Tabs:** Use a "Segmented Control" style for toggling between "Trending" and "Latest" feeds, providing a tactile, app-like feel.